---
name: tdd
description: >-
  Ciclo RED → GREEN → REFACTOR → VERIFICAR con el mínimo coste y al nivel de test adecuado, sin
  dobles de prueba que oculten el contrato real. Úsala al escribir o corregir código con tests,
  dentro o fuera de un flujo SDD.
---

# tdd — Desarrollo guiado por tests

Objetivo: la máxima confianza por token y por ejecución, sin ceremonia.

## Ciclo

1. **ENTENDER.** Comportamiento observable, código y tests existentes y convenciones del proyecto (`docs/agent-runbook.md` si existe). Contexto mínimo.
2. **ELEGIR NIVEL.** El que exige la tarea o, fuera de un flujo SDD, el más barato que demuestre el comportamiento: lógica pura → unitario; persistencia (columnas, restricciones, transacciones) → almacenamiento real; sistema externo → contrato con respuestas documentadas o grabadas; flujo de usuario → E2E.
3. **RED.** El test significativo más pequeño. Confirma que falla por la razón esperada: el comportamiento ausente. Si el símbolo que se va a crear aún no existe, vale el error de importación o de símbolo inexistente de ese símbolo; cualquier otro error de compilación o de import no es un RED válido. Si el test cubre un comportamiento ya existente, demuestra que puede fallar con una mutación temporal del código (y deshazla). Si pasa cuando debía fallar, el test no prueba lo que dice: corrígelo antes de tocar producción.
4. **REPRODUCIR Y CAUSA RAÍZ** (en bugs). Reproduce antes de tocar producción; corrige la causa, no el síntoma.
5. **GREEN.** El cambio de producción mínimo y correcto, sin refactors ajenos, abstracciones especulativas, dependencias nuevas ni requisitos futuros. Lo que una dependencia externa no devolvió nunca se rellena con un valor inventado.
6. **REFACTOR.** Solo en verde y solo si mejora de verdad; los tests siguen en verde.
7. **VERIFICAR.** Comprobaciones proporcionales al riesgo, con los comandos del proyecto (no interactivos, sin modo watch). Revisa el diff: cada línea se traza a la tarea. Nunca declares como superado algo que no se ha ejecutado.

**Límite de intentos:** si el mismo fallo sigue tras 3 intentos con hipótesis distintas, detente e informa de las hipótesis descartadas y la evidencia; no sigas probando variantes. Un test intermitente es un fallo que se investiga, no se reintenta hasta que pase.

## Dobles de prueba

- Solo en las fronteras que no son objeto del test. Un doble reproduce la interfaz real: atributos y métodos que existen y errores que el real lanza; nunca «acepta cualquier cosa».
- Si el comportamiento depende del almacenamiento (unicidad, nulos, tipos, transacciones) o del protocolo externo (firma, paginación, formato de error), un doble no lo demuestra: sube de nivel.
- Si el requisito habla de concurrencia, el test la provoca (operaciones simultáneas, transición condicionada); no la supone.

## Cuándo no aplicar el ciclo completo

Documentación, recursos generados, configuración trivial o refactors mecánicos ya cubiertos por tests: basta con verificar. En un flujo SDD debe constar en la tarea como `Tests requeridos: N/A — <motivo>`; no lo decide quien implementa.

## Prohibido

Declarar como superado un test que no se ha ejecutado; tests que no pueden fallar; dobles que aceptan cualquier llamada; rebajar el nivel exigido; arreglar el síntoma en lugar de la causa; desactivar, saltar, enfocar (`.only`) o debilitar tests (aserciones, umbrales, timeouts) para pasar; cambiar un test existente cuyo comportamiento esperado no cambió.

## Calidad de los tests

Deterministas, centrados en el comportamiento, legibles y resistentes a cambios internos irrelevantes. El nivel más barato que dé confianza suficiente, nunca uno inferior al exigido.
