# Skills SDD + TDD

Conjunto de 18 skills para desarrollar software con agentes de IA mediante **Spec-Driven Development**
(la especificación aprobada manda sobre el código) y **TDD**. Son independientes del proyecto, del
lenguaje, del entorno de ejecución y del harness.

## Compatibilidad

- **Formato:** cada skill es una carpeta con un `SKILL.md` y frontmatter `name` / `description`
  (formato abierto de *Agent Skills*). Algunas incluyen recursos (`scripts/`, `assets/`).
- **Harness:** cualquiera que cargue skills con ese formato. Si el tuyo no las admite, copia las carpetas a
  un directorio del proyecto o del usuario: `AGENTS.md` registra ese directorio y define «usar la skill X»
  como leer `<directorio>/X/SKILL.md` (sus `scripts/` y `assets/` se resuelven desde la carpeta de la skill).
- **Instrucciones del proyecto:** las reglas se generan en `AGENTS.md`. Si tu harness lee otro fichero,
  `sdd-agents` crea uno puente que remite a `AGENTS.md`.
- **Capacidades opcionales:** si el harness ofrece subagentes, las fases sin aprobación humana y cada tarea
  se delegan en uno nuevo (las preguntas al usuario las hace siempre el agente principal); si ofrece objetivos persistentes, se usan en cadenas largas. Sin ellas, el flujo funciona en un
  único agente.
- **Requisitos del proyecto:** git (recomendado) y, para el verificador, Node ≥ 18 **o** Python ≥ 3.8
  (opcional: sin ellos, las comprobaciones se hacen a mano).

## Flujo

```text
sdd-init → sdd-constitution → sdd-agents
   └→ por funcionalidad: sdd-spec → sdd-clarify (aprobación) → sdd-plan (aprobación si hay decisiones)
        → [sdd-migration] → sdd-tasks → sdd-implement (TDD, una tarea y un commit cada vez)
        → [sdd-review] → sdd-validate → sdd-release
Mantenimiento: sdd-bug · sdd-change · sdd-refactor · sdd-review · sdd-retro
Router: sdd-orchestrator (diagnostica y ejecuta el siguiente paso hasta el próximo gate humano)
```

La forma habitual de trabajar es pedir **«usa sdd-orchestrator»**: diagnostica el estado y encadena las
fases (en subagentes si el harness los ofrece, o en el propio agente). Se detiene solo en las decisiones que corresponden al usuario (aprobaciones, aclaraciones,
riesgos), ante un bloqueo o al terminar.

## Skills

| Skill | Produce / hace |
|---|---|
| `sdd-init` | `docs/brief.md` |
| `sdd-constitution` | `docs/constitution.md` (principios) y sus enmiendas |
| `sdd-agents` | `AGENTS.md` (reglas), `docs/sdd-conventions.md` (Convenciones SDD), `docs/agent-runbook.md`, verificador `sdd-check` |
| `sdd-spec` | `specs/NNN-slug/spec.md` (QUÉ y POR QUÉ, en EARS) |
| `sdd-clarify` | `clarify.md` y aprobación de la spec |
| `sdd-plan` | `plan.md` (CÓMO: contratos, módulos canónicos, niveles de test) |
| `sdd-migration` | `migration-review.md` |
| `sdd-tasks` | `tasks.md` (trazabilidad y tareas) |
| `sdd-implement` | Código y tests por tarea, evidencia y commit |
| `sdd-validate` | `validation.md` (SPEC CUMPLIDA) |
| `sdd-release` | `release.md` (READY/BLOCKED) y archivado del ciclo |
| `sdd-bug` | Arreglo con test de regresión y `bugs/BUG-NNN.md` |
| `sdd-change` | Nueva versión de la spec |
| `sdd-refactor` | Mejora interna sin cambio observable |
| `sdd-review` | Auditoría y `reviews/backlog.md` |
| `sdd-retro` | Spec RETRO de código existente y tests de caracterización |
| `sdd-orchestrator` | Diagnóstico y encadenamiento del flujo |
| `tdd` | Ciclo RED → GREEN → REFACTOR → VERIFICAR (también fuera de SDD) |

## Principios del diseño

- **Una sola fuente de reglas:** lo que todo agente necesita vive en `AGENTS.md` (corto, porque el harness lo carga
  siempre); las Convenciones SDD, en `docs/sdd-conventions.md`, que las skills citan y leen por secciones.
- **Estado en el repositorio:** artefactos versionados y commits; nunca la conversación.
- **Evidencia real:** cada requisito tiene un nivel de test mínimo (persistencia ≥ integración, sistema
  externo ≥ contrato, interfaz con referencia ≥ visual), y la validación lo comprueba.
- **Sin bucles desatendidos:** cada veredicto negativo declara su siguiente paso; una skill no se relanza
  sin trabajo nuevo; los reintentos automáticos se limitan a uno, un fallo que se repite con los mismos
  huecos se lleva al usuario, y dentro de una tarea, tres hipótesis fallidas sobre el mismo fallo detienen el trabajo.
- **Tests íntegros:** ningún test se desactiva, enfoca o debilita para avanzar; un test existente solo cambia
  si su comportamiento esperado cambió en la spec (el verificador bloquea `.only` y avisa de los `skip`).
- **Diagnóstico barato:** el verificador `sdd-check` lee cabeceras y veredictos en lugar de artefactos
  completos.

## Verificador `sdd-check`

`sdd-agents/scripts/` contiene dos implementaciones equivalentes, `sdd-check.mjs` (Node) y `sdd_check.py`
(Python); `sdd-agents` copia al proyecto la que pueda ejecutarse (con Node, el pre-commit es unas 8 veces más rápido en diffs grandes).

```text
sdd-check [--spec NNN-slug] [--json]                 estado, caducidad, siguiente paso, problemas
sdd-check pre-commit --task T-XXX --spec NNN-slug    evidencia en el mismo commit y secretos
sdd-check pre-commit --bug BUG-NNN                   registro del bug y secretos
sdd-check pre-commit                                 resto de commits: secretos y tests enfocados/desactivados
sdd-check pre-commit --range <base>...HEAD          CI: los mismos detectores sobre una rama
sdd-check allow-hash <fichero>:<línea>               clave para aprobar un falso positivo en .sdd-allowed-secrets
sdd-check --version
```

Salida: 0 correcto · 1 problemas que bloquean · 2 error de uso o de entorno.

Secretos en `pre-commit`: bloquea los hallazgos de alta confianza (formatos de proveedor, claves privadas, credenciales
con estructura como URLs con contraseña o `curl -u`, `.env` reales) y avisa de los heurísticos por nombre
(`password=`, `*_KEY=`…), para que un falso positivo nunca bloquee un commit legítimo. Es una primera barrera rápida:
en proyectos entregados a clientes, la CI añade un escáner dedicado (p. ej. gitleaks).

## Instalación

```bash
./install.sh <directorio-de-skills-de-tu-harness>            # instala (con copia de seguridad)
./install.sh <directorio> --backup-dir <dir>                 # copia de seguridad en otro directorio
./install.sh <directorio> --dry-run                          # muestra qué cambiaría
./install.sh <directorio> --rollback <copia.tar.gz>          # vuelve atrás
```

También puedes copiar a mano las 18 carpetas `sdd-*` y `tdd` en ese directorio. Si el harness recarga
las skills en caliente, no las sustituyas con una cadena de tareas en curso.

## Adopción en un proyecto con trabajo previo

1. Usa `sdd-orchestrator`: si falta `AGENTS.md` o el verificador, propondrá `sdd-agents`.
2. Las carpetas de `specs/` deben llamarse `NNN-slug` (el verificador avisa de las que no lo cumplen y las ignora).
   Si `AGENTS.md` o `docs/sdd-conventions.md` no tienen el marcador actual (`sdd-conventions: 3`), el verificador manda a
   `sdd-agents` para actualizarlo (también el verificador del proyecto: `sdd-check --version`).
3. Los artefactos sin las cabeceras actuales se re-sellan: la skill dueña actualiza la cabecera sin repetir
   auditorías ni aprobaciones, siempre que aquello de lo que dependen no haya cambiado desde su último commit
   (si no puede comprobarse, se pregunta al usuario). Las tareas cerradas sin evidencia se re-sellan re-ejecutando
   sus tests.
4. Una spec heredada que ya está terminada y en producción puede marcarse como completada con `sdd-release`
   en modo adopción (con confirmación explícita del usuario), sin volver a validarla.
5. Las nuevas exigencias (niveles de test, tablas de estados y de sistemas externos) se aplican desde el
   siguiente cambio o plan de cada spec.

## Verificación del paquete

```bash
bash sdd-agents/scripts/test-sdd-check.sh    # requiere git y Python 3; con Node, comprueba además la paridad
```

## Estructura

```text
README.md · CHANGELOG.md · install.sh
sdd-*/SKILL.md · tdd/SKILL.md
sdd-agents/scripts/   sdd-check.mjs · sdd_check.py · test-sdd-check.sh
sdd-agents/assets/    AGENTS.template.md · sdd-conventions.md · agent-runbook.md · remote-run.sh (plantilla SSH + rsync)
```
