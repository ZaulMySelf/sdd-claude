---
name: sdd-orchestrator
description: >-
  Router del flujo SDD: diagnostica el estado (con el verificador sdd-check si existe), ejecuta el
  siguiente paso y encadena fases hasta el próximo gate humano; clasifica bugs, cambios,
  funcionalidades nuevas, refactors, auditorías y releases. Úsala para avanzar una spec o para ver
  su estado («sdd-orchestrator estado» solo diagnostica).
---

# sdd-orchestrator — Router del flujo

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill) (si aún no existe, diagnostica igualmente).

Determina el **único** siguiente paso permitido y lo ejecuta usando su skill: delegándolo en un subagente cuando corresponda (Ejecución) o, si no, ejecutándolo en su propio contexto, donde actúa como esa skill con sus reglas. El diagnóstico en sí no edita artefactos. Mantiene su contexto pequeño durante toda la cadena.

## Diagnóstico

1. **Con verificador** (fila `SDD` de la tabla de comandos): ejecuta `sdd-check` y usa su `SIGUIENTE PASO` (el de `PROYECTO`, si lo hay, antes que el de cualquier spec), sus `PROBLEMA` y sus avisos. No leas artefactos para diagnosticar.
2. **Sin verificador:** lee de cada artefacto solo la cabecera y la línea de veredicto (de `tasks.md`, solo las líneas `- [ ]` / `- [x]` y las dependencias de la primera pendiente) y aplica el orden de abajo. Con la constitución ya aprobada, recomienda `sdd-agents` una vez.
3. **PROBLEMA:** se corrige en el orden que marca el `SIGUIENTE PASO` del verificador (que antes re-sella spec, plan y tasks si hace falta), con la skill que indique (tarea `[x]` sin evidencia → `sdd-implement T-XXX` en modo re-sellado; IDs duplicados o tarea archivada reabierta → `sdd-tasks` en modo reparación; fila del backlog mal formada → la skill que la escribió, o `sdd-review` en modo formato). Una tarea con `Bloqueada: … → <skill>` se enruta a esa skill.

### Orden

1. Falta `docs/brief.md` → `sdd-init`.
2. Constitución no `APROBADA` → `sdd-constitution`.
3. Falta `AGENTS.md`, su marcador `sdd-conventions` es menor que 3, falta `docs/sdd-conventions.md`, o el verificador del proyecto es **más antiguo** que el del paquete instalado (`sdd-check --version` frente a `<skills>/sdd-agents/scripts/sdd-check.mjs --version`, o `sdd_check.py --version` sin Node; un verificador sin `--version` es anterior a 2.1.0) → `sdd-agents`. Uno más nuevo no se toca (otra persona del equipo tiene un paquete posterior: actualiza el tuyo). Este paso del proyecto va antes que cualquier paso de una spec (un verificador antiguo puede no saberlo).
4. **Spec activa.** Con ramas por spec, la de la rama actual (manda sobre el aviso «SPEC A AVANZAR» del verificador, que no conoce las ramas). Si no, la única no completada (completada = `release.md` vigente con `RELEASE: READY`, o RETRO v1 `APROBADA` sin RF `(defecto)` ni pedido `Pendiente:`). Con varias: primero la que tenga tareas en curso; después, la que no dependa de otra sin completar (`Depende de`); pregunta solo si sigue habiendo empate. RETRO con RF `(defecto)` → `sdd-bug`; RETRO con `Pendiente: sdd-retro | sdd-bug | sdd-change` → esa skill (la primera línea `Pendiente:`).
   Una spec con `Depende de` puede avanzar hasta `sdd-tasks` mientras su dependencia no esté completada; no se implementa hasta que lo esté. Una spec heredada (Convenciones › Fuentes y artefactos) sin derivados vigentes: pregunta una vez «¿adoptarla como terminada (sdd-release en modo adopción) o rehacer su ciclo?».
   Sin spec activa: filas CRÍTICO/ALTO globales o ilegibles en el backlog → la skill que indica el verificador; si no, con una funcionalidad nueva descrita → `sdd-spec`; sin pedido: pregunta y DETENTE.
5. Spec no `APROBADA`, con `[NECESITA ACLARACIÓN:`, o `clarify.md` ausente, caducado o `NO` → `sdd-clarify`.
6. `plan.md` ausente, caducado o `PENDIENTE` → `sdd-plan`.
7. `Migración requerida: SÍ`: revisión ausente o caducada → `sdd-migration`; vigente con `INCOMPLETA` → `sdd-plan`.
8. `tasks.md` ausente o caducado → `sdd-tasks`; `TRAZABILIDAD: FAIL` vigente → el `Siguiente paso` que declara (`sdd-plan` o `sdd-change`).
9. Tareas pendientes → `sdd-implement`.
10. Todas completas: filas CRÍTICO o ALTO `ABIERTO` de esta spec en el backlog → la skill de su columna Ruta. Después, `validation.md` ausente o caducado → `sdd-validate`.
11. `SPEC CUMPLIDA: SÍ` y `release.md` ausente o caducado → `sdd-release`; antes, si hay filas CRÍTICO/ALTO `ABIERTO` globales (Spec `—`) en el backlog, la skill de su Ruta (bloquean cualquier release).
12. **Veredicto negativo vigente** (`SPEC CUMPLIDA: NO`, `RELEASE: BLOCKED`): con trabajo commiteado posterior al último commit del artefacto, repite esa skill; si no, sigue el `Siguiente paso` que declara, salvo que esa skill ya esté satisfecha; si no queda ruta, DETENTE e informa («requiere acción»): el usuario puede aceptar el riesgo (Convenciones › Riesgos y vulnerabilidades) y pedir de nuevo la skill que emitió el veredicto.
13. `RELEASE: READY` vigente y sin filas CRÍTICO/ALTO abiertas de la spec en el backlog → spec completada. Con alguna, la spec vuelve a estar activa: la skill de su Ruta y, si su resolución toca la spec o sus bugs, un nuevo ciclo validate → release.

## Mantenimiento (se clasifica antes que el flujo lineal)

| Pedido | Skill |
|---|---|
| Funcionalidad nueva (Convenciones › Tamaño de spec) | `sdd-spec` (spec nueva; la relación se cita en su Contexto) |
| Bug o cambio en código que ninguna spec cubre | `sdd-retro`, después `sdd-bug` o `sdd-change` |
| Defecto o fallo de causa incierta | `sdd-bug` |
| Comportamiento distinto dentro de una funcionalidad existente | `sdd-change` |
| Pedido mixto (parte cambio, parte funcionalidad nueva) | Se parte: `sdd-spec` para lo nuevo (dueña de su propia interfaz, aunque se muestre en una página de otra spec) y `sdd-change` de la existente solo para el punto de enlace. |
| Mejora interna sin cambio observable | `sdd-refactor` |
| Auditoría | `sdd-review` |
| Dependencia nueva | `sdd-plan` delta (D-NNN) de la spec que la necesita (contrastada con la constitución); si ninguna la necesita, pide el requisito (`sdd-change` o `sdd-spec`) |
| Dependencias: parche o menor sin cambio observable | `sdd-refactor` |
| Dependencias: versión mayor | `sdd-plan` delta (nueva D-NNN) de la spec activa que la use; si afecta a todo el proyecto y no hay spec activa, `sdd-refactor` con aprobación explícita |
| Vulnerabilidad sin parche fuera de una skill de implementación | `sdd-refactor` (aplica Convenciones › Riesgos y vulnerabilidades) |
| Dependencias con cambio de comportamiento | `sdd-change` |
| Gate previo a merge o despliegue | `sdd-release` |

**Muchos hallazgos a la vez** (p. ej. tras una auditoría): no improvises un plan paralelo. `sdd-review` los registra en el backlog; presenta al usuario en un solo mensaje las decisiones CRÍTICO/ALTO que requieren `sdd-change` (los MEDIO y BAJO solo se listan); procesa el resto por severidad: bugs, después un único `sdd-change` que agrupe los cambios de comportamiento, después refactors. MEDIO y BAJO, solo a petición del usuario.

## Ejecución

- **Modo continuo (por defecto).** Tras cada skill, vuelve a diagnosticar y ejecuta el siguiente paso sin preguntar «¿sigo?». Las rutas del orden anterior se siguen sin preguntar. DETENTE solo ante: un gate o una pregunta al usuario · una acción `BLOQUEADA` · «requiere acción» del verificador · una condición de parada de `sdd-implement` · una skill que terminó sin commit (p. ej. `DEBUG: INCONCLUSO`) cuando el diagnóstico vuelve a ella · varias specs activas sin orden · `RELEASE: READY` · petición del usuario. `sdd-orchestrator estado` solo diagnostica.
- **Cambios sin commitear ajenos** (BLOQUEADA de implement, bug, validate o release, o «requiere acción: código o tareas sin commitear»): lista los ficheros y pregunta al usuario, en una sola pregunta, si commitearlos con la skill que corresponda, aparcarlos (`git stash push -u -m …`) o descartarlos; nunca lo decide solo. Si el diff es una mutación de falsación de sdd-validate que quedó a medias, dilo: esa opción es descartarla (`git checkout HEAD -- <fichero>`), nunca commitearla.
- **Delegación:** si el harness permite subagentes y el usuario no ha pedido trabajar en un único agente, según la sección Delegación de abajo.
- **Tras cada subagente:** comprueba los ficheros del commit y `sdd-check`. Si el informe y el repositorio no coinciden (sin commit, tarea sin sellar, ficheros ajenos), relanza **una vez** la misma tarea indicando que continúe su trabajo parcial; si vuelve a fallar, DETENTE e informa. Una skill que termina sin commit ni cambio no se relanza. Si un veredicto negativo (`FAIL`, `INCOMPLETA`, `NO`, `BLOCKED`) reaparece con los mismos huecos o el mismo requisito tras el ciclo que debía resolverlo, DETENTE y lleva los huecos al usuario (evita bucles validate ↔ implement o plan ↔ tasks).
- **Verificación completa periódica:** si `sdd-check` indica que conviene, pide en el prompt de la siguiente tarea «ejecuta además la fila Todo». Si esa corrida (o cualquier verificación compartida: suite, build, Todo) falla por algo ajeno a la tarea, la tarea queda `Bloqueada: fallo compartido (<qué>) → sdd-bug` y el verificador lleva a `sdd-bug` antes que a cualquier otra tarea (Convenciones › Tareas y evidencia).
- **Tareas con `Requiere usuario: SÍ`:** no se lanzan en una cadena desatendida; cuando solo queden ellas, DETENTE y pide al usuario lo necesario para todas a la vez.
- **Cadenas largas:** si el harness ofrece objetivos persistentes, crea uno («tareas pendientes de NNN hasta SPEC CUMPLIDA o parada»).
- **Aprobaciones de un mismo paso**: en una sola pregunta.
- **Tamaño:** ante el aviso de más de 40 tareas abiertas o de un `tasks.md` muy grande, propone una sola vez partir la spec y DETENTE; si el usuario la rechaza, el propio orquestador anota la decisión en el registro de cambios de la spec (sin subir versión; Convenciones › Versiones) con un commit `docs(NNN-slug): decisión de tamaño`, y no la vuelve a proponer mientras el número de tareas abiertas no crezca.

## Delegación

- Cada fase, tarea o bug se ejecuta en un subagente nuevo, en secuencia; nunca dos que escriban a la vez sobre el mismo árbol o entorno. Los subagentes de solo lectura (auditorías por área) pueden ir en paralelo; consolida el agente principal.
- **En el agente principal** (entrevistan o piden aprobación): init, constitution, agents, spec, clarify, change y plan. Un subagente que necesita una decisión del usuario (aprobación, aclaración, aceptación de un riesgo, confirmación) se detiene y devuelve la pregunta exacta; el principal la hace y lo relanza con la respuesta literal y su fecha («El usuario respondió el AAAA-MM-DD: «sí»»), que el subagente registra en el artefacto.
- **Prompt mínimo:** `Usa la skill <skill> [--spec NNN-slug] [T-XXX | BUG-NNN | modo] (y tdd si implementa). Pedido: <texto literal del usuario o fila R-NNN, si lo hay>. Decisión del usuario: <respuesta literal y fecha, si la hay>. Trabajo aparcado: <WIP …, si lo hay>. [Ejecuta además la fila Todo.] Aplica AGENTS.md y docs/agent-runbook.md; de docs/sdd-conventions.md lee solo las secciones que cite la skill; del runbook, lo que necesite la tarea. Eres un subagente: no lances subagentes que escriban; al terminar o detenerte, informa en ≤10 líneas con el identificador del commit y no continúes con otras skills.` El resto del estado vive en los artefactos y en el control de versiones; lo operativo que falte lo añade al runbook la tarea que lo descubre, en su propio commit.
- Un subagente que debe ejecutar algo delegado (p. ej. la revisión de ciclo de sdd-validate) lo hace en línea.
- Sin subagentes, el agente principal aplica las mismas reglas tarea a tarea.

## Salida

```text
ESTADO: <spec> v<N> · <fase> · tareas <hechas>/<total>
SIGUIENTE PASO: <skill> [T-XXX]
MOTIVO: <precondición que lo determina>
```

## Prohibido

Editar artefactos durante el diagnóstico; ejecutar en su contexto una fase que debía delegarse; lanzar en paralelo subagentes que escriben sobre el mismo árbol o entorno; reintentar más de una vez; desviar una cadena de tareas hacia el backlog; encadenar tras una parada; saltarse gates; aceptar derivados caducados o la conversación como evidencia; meter una funcionalidad nueva en una spec existente mediante `sdd-change`.
