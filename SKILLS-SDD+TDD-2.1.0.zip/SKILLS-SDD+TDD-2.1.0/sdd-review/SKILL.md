---
name: sdd-review
description: >-
  Auditoría sin corregir: quality (calidad, seguridad, tests, patrones de defecto conocidos),
  implementation (código frente a spec, plan y tareas) o completa; cada hallazgo con evidencia, y
  registro con ID en reviews/backlog.md para su triaje. Úsala para auditar o antes de validar specs L.
---

# sdd-review — Auditoría

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

## Precondiciones

Código y, para `implementation`, una spec con plan y tareas. Solo lectura: no requiere árbol limpio.

## Modos

| Modo | Revisa |
|---|---|
| `quality` | Corrección y manejo de errores · complejidad y duplicación · acoplamiento · seguridad · tests (utilidad, fragilidad, dobles, casos límite) · dependencias y código muerto · rendimiento con riesgo concreto. |
| `implementation` | RF, RNF y UI frente a la spec · interfaz frente a lo declarado y sus referencias · plan frente a implementación · tareas `[x]` sin evidencia suficiente o por debajo del nivel de §9 · comportamiento sin requisito · deriva entre spec, plan, tareas, código y tests. |
| `formato` | Solo corrige filas del backlog que `sdd-check` señala (columnas, Severidad, Spec o Ruta no válidas): la Ruta se deduce del Tipo, y la Spec es la dueña del código citado (o `—` si ninguna; si el Tipo exige una spec, como TAREA INCOMPLETA, la suya). Si no puede deducirse (la spec ya no existe), pregunta al usuario en una sola pregunta: reasignarla o `DESCARTADO (motivo)`. Sin auditoría ni línea en Revisiones. |
| `completa` | Ambos, por áreas, sin límite de hallazgos. Puede repartirse en subagentes de solo lectura (uno por área) que devuelven hallazgos sin escribir ficheros; el agente principal deduplica y es el único que escribe el backlog. |

## Patrones de defecto que se buscan siempre

- Éxito falso: valores por defecto inventados ante respuestas externas incompletas; errores tragados que devuelven un vacío «correcto».
- Dobles de prueba permisivos que ocultan atributos, columnas o restricciones inexistentes; tests de «integración» sin almacenamiento ni sistema real.
- Lógica transversal duplicada (catálogos, estados, permisos, formatos, firmas) en lugar del módulo canónico del plan.
- Escrituras de estado no condicionadas (leer → comprobar en memoria → escribir) y trabajos que pueden ejecutarse dos veces.
- Llamadas salientes sin timeout; entradas sin límites de tamaño ni validación.
- Lo que la interfaz o el cliente ofrecen y lo que el servidor autoriza, con criterios distintos.
- Conceptos nuevos (entidades, tipos, permisos, estados) sin propagar a todos sus consumidores.
- Seguridad: inyección (SQL, comandos, plantillas), autorización por objeto (acceso a recursos ajenos cambiando un ID), SSRF y rutas de fichero controladas por el usuario, XSS/CSRF en interfaces web, deserialización insegura, secretos o datos personales en logs, errores o respuestas, criptografía o aleatoriedad débil, dependencias con nombre sospechoso.
- Tests que no pueden fallar, desactivados o enfocados, o modificados para aceptar un comportamiento que la spec no cambió.

## Reglas

- Solo audita; no corrige.
- Cada hallazgo cita evidencia concreta (fichero:línea, símbolo, test o comando). Ejecuta los comandos de verificación cuando aporten evidencia.
- Por defecto, CRÍTICO, ALTO y MEDIO, como máximo 10 (en `completa`, sin máximo). BAJO, solo si se pide.
- **Severidad:** CRÍTICO = pérdida de datos, seguridad explotable o éxito falso en la operación principal; ALTO = requisito incumplido o fallo probable en uso normal; MEDIO = robustez o deuda con riesgo concreto. Ante la duda, la menor (CRÍTICO y ALTO bloquean la validación).
- Las preferencias de estilo no son defectos.
- **Tipo → Ruta:** `BUG` (código ≠ spec, incluido lo que viola un RNF o un principio de seguridad de la constitución aunque ningún RF lo diga explícitamente) → `sdd-bug` · `CAMBIO FUNCIONAL` o comportamiento no definido por la spec → `sdd-change` · `DEUDA` → `sdd-refactor` · `PLAN OBSOLETO` → `sdd-plan` · `TAREA INCOMPLETA` → `sdd-implement T-XXX` (si la tarea está archivada, `sdd-tasks`). Ninguna otra Ruta es válida.
- **Spec:** `NNN [Req]`; si el hallazgo está en código que ninguna spec cubre (librería común, infraestructura), `—` (global, con Ruta `sdd-bug`, `sdd-change`, `sdd-refactor` o, si ninguna spec cubre el código y hay que cambiarlo, `sdd-retro`): un CRÍTICO/ALTO global bloquea el release de todas las specs, así que úsalo solo cuando no exista una spec dueña.

## Registro (siempre)

1. Añade los hallazgos a `reviews/backlog.md` (lo crea si no existe) con el formato de Convenciones › Backlog, continuando la numeración global `R-NNN` y sin duplicar filas (actualiza la existente).
2. Añade siempre, aunque no haya hallazgos, una línea en `## Revisiones`.
3. Si `sdd-check` señala filas mal formadas, corrígelas (solo el formato).
4. Commit `docs: review <modo> AAAA-MM-DD` (con `sdd-check pre-commit` genérico).

```markdown
# Backlog

| ID | Fecha | Severidad | Tipo | Hallazgo (evidencia) | Spec | Ruta | Estado |
|---|---|---|---|---|---|---|---|
| R-001 | AAAA-MM-DD | ALTO | BUG | … (`ruta/fichero:42`) | 001 RF-010 | sdd-bug | ABIERTO |
| R-002 | AAAA-MM-DD | MEDIO | TAREA INCOMPLETA | … | 001 RF-003 | sdd-implement T-012 | ABIERTO |
| R-003 | AAAA-MM-DD | ALTO | BUG | … (`lib/http.ts:17`, sin timeout) | — | sdd-bug | ABIERTO |

## Revisiones
- AAAA-MM-DD · completa · spec 001 v3/p4 · commit abc1234 · 2 hallazgos
```

## Salida

```text
REVISIÓN: QUALITY | IMPLEMENTATION | COMPLETA · RESULTADO: PASS | WARN | FAIL
- [ALTO] R-NNN fichero:línea — problema — impacto — ruta
DECISIONES PARA EL USUARIO: <hallazgos que requieren sdd-change, en una sola pregunta | ninguna>
VERIFICACIONES: <resumen>
```

## Prohibido

Corregir código, tests o artefactos (salvo el backlog); hallazgos sin evidencia; preferencias de estilo como defectos; escribir el backlog desde subagentes de solo lectura.
