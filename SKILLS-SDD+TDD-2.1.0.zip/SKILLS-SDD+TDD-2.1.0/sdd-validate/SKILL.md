---
name: sdd-validate
description: >-
  Validación final de una spec: suite completa y verificaciones en una sola corrida, cadena de
  evidencia por requisito al nivel de test exigido, conformidad visual, sistemas externos y backlog
  sin bloqueantes → SPEC CUMPLIDA: SÍ/NO. Úsala con todas las tareas completas.
---

# sdd-validate — Validación final

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

## Precondiciones

- Spec `APROBADA`; `tasks.md` vigente con `TRAZABILIDAD: PASS` y todas las tareas `- [x]` con evidencia; `sdd-check --spec NNN-slug` sin `PROBLEMA`; árbol limpio (`AGENTS.md` › Commits), para que la evidencia corresponda a un commit (con cambios ajenos: `Siguiente paso: sdd-orchestrator`, que pregunta al usuario). Si no: `VALIDACIÓN BLOQUEADA — Motivo: … — Falta: … — Siguiente paso: <skill según la causa (sdd-implement T-XXX, sdd-tasks…)>`.
- **Revisión de ciclo** (specs `L`, o si el usuario la pide): en `## Revisiones` del backlog debe constar, para esta spec, una revisión `implementation` + `quality` o `completa` del ciclo actual: posterior a la última tarea cerrada del ciclo (su commit es ancestro del de la revisión). Solo se exige en ciclos con tareas nuevas; un ciclo abierto únicamente por bugs corregidos no la necesita. Si falta, ejecuta antes `sdd-review` (en subagentes de solo lectura por áreas si el harness lo permite y no eres ya un subagente; si no, en línea). Es una por ciclo: lo que resuelve sus hallazgos no exige otra revisión, solo cerrar sus filas.

## Re-sellado

Si `validation.md` está caducado o sin versión, con `SPEC CUMPLIDA: SÍ`, y desde su último commit no han cambiado la spec, el plan ni el código (Convenciones › Versiones), actualiza la cabecera y conserva el veredicto. En cualquier otro caso, validación completa.

## Procedimiento

1. Registra el commit actual.
2. **Corrida completa única:** la fila «Todo» de la tabla de comandos (tests de todos los paquetes, integración, E2E, build, lint, typecheck y seguridad). Cada comando se ejecuta y se registra por separado (uno que falla no impide ejecutar los demás). Las categorías que no existan se marcan «no disponible». La validación de esta spec cubre también las regresiones en otras specs, porque la corrida es completa. Una vulnerabilidad sin parche se trata según Convenciones › Riesgos y vulnerabilidades.
3. **Cadena por requisito.** Para cada RF, RNF y UI vigente (los marcados `eliminado` o `movido a …` se omiten; los heredados por partición citan su test existente y cuentan si pasa en esta corrida): tarea(s) → test → **nivel real** → resultado en esta corrida. El nivel real debe alcanzar el exigido en plan §9 (si el plan no lo fija, los mínimos de `AGENTS.md` › Niveles de test). Los niveles reducidos y los «Huecos aceptados» del plan cuentan como riesgos aceptados: se listan, no son huecos. Un test que sustituye el almacenamiento o el sistema externo por un doble escrito a mano cuenta como UNIT aunque se llame «integración». En RETRO o specs adoptadas, los RF no tocados citan su test de caracterización y cuentan si pasa en esta corrida.
4. **Sistemas externos:** cada uno en alcance tiene evidencia CONTRATO y, si la spec declara un entorno real, evidencia REAL (fecha, entorno, resultado). Si falta y ya consta como nivel reducido aceptado en plan §9, se lista como riesgo aceptado sin preguntar; si no consta, es un hueco salvo que el usuario lo acepte ahora (con un sí explícito se registra en «Riesgos aceptados»).
5. **Interfaz:** cada UI-NNN con referencia visual tiene una captura vigente comparada según Convenciones › Interfaz; las confirmaciones del usuario se citan.
5b. **Prueba de falsación** (barata, contra tests verdes que no prueban nada). Elige 1-3 requisitos de mayor riesgo (seguridad, persistencia, sistema externo o los de evidencia más escueta). Para cada uno, introduce una **mutación mínima** en la línea de producción que implementa la regla (invertir la condición, devolver vacío, omitir la comprobación), sin crear ni borrar ficheros; ejecuta el test citado, comprueba que **falla** y restaura en el acto con `git checkout HEAD -- <fichero>` (después, `git status` limpio). Si el comportamiento se produce en más de un sitio, la mutación va donde lo indica plan §4b; que siga pasando por otra copia es lógica duplicada (`sdd-bug`, clase FUENTE-DUPLICADA). Un test que sigue pasando con la regla rota es un hueco: `SPEC CUMPLIDA: NO` → `sdd-implement T-XXX`, que lo refuerza (`AGENTS.md` › regla 14 d). Se registra en la cadena de evidencia («falsado: sí» o la mutación que sobrevivió).
6. **Modo incremental** (tras un cambio `LOCAL` o un bug corregido, con validación previa): se rehacen solo las filas afectadas y se re-sella el resto. La corrida completa del paso 2 es siempre obligatoria.
7. Comprueba que ninguna «Excepción aceptada» contradice un RNF de seguridad (si lo hace, `SPEC CUMPLIDA: NO` → `sdd-change`); permisos denegados (test negativo en verde), transiciones de la tabla de estados, casos límite, criterios de finalización y principios de la constitución (una línea cada uno).
8. **Backlog:** ninguna fila CRÍTICO o ALTO `ABIERTO` de esta spec.
9. Escribe `validation.md` con el veredicto:
   - todo con evidencia al nivel exigido → `SPEC CUMPLIDA: SÍ`, `Siguiente paso: sdd-release`;
   - cualquier hueco → `SPEC CUMPLIDA: NO` con un `Siguiente paso` concreto: `sdd-implement T-XXX` (tarea incompleta; si está archivada, `sdd-tasks`, que crea su sustituta), `sdd-plan` (nivel de test inalcanzable: nivel reducido con el usuario), `sdd-tasks` (falta una tarea, p. ej. de nivel), `sdd-bug`, `sdd-change` o la ruta de dependencias.
10. Antes del commit, comprueba que el árbol está limpio salvo `validation.md` (ninguna mutación de falsación pendiente); si no, restaura o DETENTE. Commit `docs(NNN-slug): validation`. DETENTE. No arregles nada.

## Plantilla de `validation.md`

```markdown
# Validación — NNN-slug

| Campo | Valor |
|---|---|
| Spec-Version | N |
| Plan-Version | M |
| Commit | <sha> |

## Cadena de evidencia
| Req | Tarea | Test | Nivel exigido | Nivel real | Resultado |
|---|---|---|---|---|---|

## Verificaciones del proyecto
| Categoría | Comando | Resultado |
|---|---|---|

## Sistemas externos e interfaz
## Estados, casos límite y criterios de finalización
## Constitución
| Principio | Cumple / evidencia |
## Riesgos aceptados (qué · fecha · motivo)
## Backlog (CRÍTICO/ALTO abiertos): ninguno | R-NNN…

Siguiente paso: <sdd-release | skill [T-XXX]>

SPEC CUMPLIDA: SÍ | NO
```

## Prohibido

Modificar código o tests (salvo la mutación temporal de la prueba de falsación, restaurada antes de escribir nada); emitir SÍ con algún requisito sin evidencia o con un nivel inferior al exigido; aceptar resultados no producidos en esta ejecución o la palabra de la conversación; ignorar el backlog bloqueante.
