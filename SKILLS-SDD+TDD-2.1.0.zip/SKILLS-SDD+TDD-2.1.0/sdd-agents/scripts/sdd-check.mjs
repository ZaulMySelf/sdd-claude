#!/usr/bin/env node
// sdd-check — verificador determinista de artefactos SDD (sin dependencias; Node >= 18).
// Port equivalente: sdd_check.py (Python >= 3.8). Mantén ambos en paridad (test-sdd-check.sh).
// Uso (desde cualquier carpeta del repositorio):
//   node <ruta>/sdd-check.mjs [status] [--spec NNN-slug] [--json]
//   node <ruta>/sdd-check.mjs pre-commit [--task T-XXX | --bug BUG-NNN] [--spec NNN-slug]
//   node <ruta>/sdd-check.mjs pre-commit --range <base>..<head>   (CI: los mismos detectores sobre una rama)
//     (sin --task/--bug: commit genérico → solo lista staged y busca secretos)
// Salida: 0 = OK · 1 = problemas que bloquean · 2 = error de uso o de entorno.
// Lee solo cabeceras, veredictos, líneas de estado y el backlog; nunca modifica nada.
// Se asume git para pre-commit y para detectar trabajo posterior a validation/release.

import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, basename } from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const KNOWN = new Set(['spec.md', 'clarify.md', 'plan.md', 'migration-review.md', 'tasks.md',
  'tasks-archive.md', 'validation.md', 'release.md', 'bugs', 'assets', 'archive']);
const VERDICTS = {
  'clarify.md': 'SPEC CLARIFICADA', 'migration-review.md': 'MIGRACIÓN', 'tasks.md': 'TRAZABILIDAD',
  'validation.md': 'SPEC CUMPLIDA', 'release.md': 'RELEASE',
};
// Skill → artefacto que produce y veredictos positivos (para no enrutar a una skill ya satisfecha).
const OWN = { 'sdd-validate': ['validation.md', ['SÍ', 'SI']], 'sdd-release': ['release.md', ['READY']] };
const DERIVED = ['clarify.md', 'plan.md', 'migration-review.md', 'tasks.md', 'validation.md', 'release.md'];
const LIMITS = { tasksBytes: 120_000, openTasks: 40, evidenceLines: 6, fullVerifyEvery: 5 };
const VERSION = '2.1.0';
const CONVENTIONS = 3; // marcador mínimo «sdd-conventions: N» en AGENTS.md y docs/sdd-conventions.md
const ROUTES = ['sdd-bug', 'sdd-change', 'sdd-refactor', 'sdd-plan', 'sdd-tasks', 'sdd-implement'];
const GLOBAL_ROUTES = ['sdd-bug', 'sdd-change', 'sdd-refactor', 'sdd-retro'];
// Skills que pueden figurar como «Siguiente paso» de un artefacto (el orquestador no: se enrutaría a sí mismo).
const STEPS = new Set([...ROUTES, 'sdd-migration', 'sdd-validate', 'sdd-release', 'sdd-agents', 'sdd-retro', 'sdd-spec', 'sdd-clarify', 'sdd-constitution']);

const args = process.argv.slice(2);
if (args.includes('-h') || args.includes('--help')) {
  console.log('uso: sdd-check [status] [--spec NNN-slug] [--json] | pre-commit [--task T-XXX | --bug BUG-NNN] [--spec NNN-slug] | pre-commit --range <base>..<head> | allow-hash <fichero>:<línea> | --version');
  process.exit(0);
}
if (args.includes('--version')) { console.log(`sdd-check ${VERSION}`); process.exit(0); }
const cmd = args[0] && !args[0].startsWith('--') ? args.shift() : 'status';
const opt = (name) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : undefined; };
const flag = (name) => args.includes(name);
let gitCwd = process.cwd();
const git = (...a) => execFileSync('git', ['-c', 'core.quotePath=false', ...a], { cwd: gitCwd, encoding: 'utf8', maxBuffer: 1 << 30, stdio: ['ignore', 'pipe', 'ignore'] });
const tryGit = (...a) => { try { return git(...a); } catch { return null; } };
const root = (tryGit('rev-parse', '--show-toplevel') ?? '').trim() || process.cwd();
gitCwd = root; // todas las rutas y pathspecs de git, relativas a la raíz del repo
const norm = (t) => (t === null ? null : t.replace(/\r\n?/g, '\n'));
const read = (p) => (existsSync(p) ? norm(readFileSync(p, 'utf8')) : null);
const show = (v) => (v === null || v === undefined || v === '' ? '?' : String(v));
const splitZ = (s) => (s ?? '').split('\0').filter(Boolean);

function header(text) {
  const out = {};
  if (!text) return out;
  for (const line of text.split('\n').slice(0, 40)) {
    const m = line.match(/^\|\s*([^|]+?)\s*\|\s*([^|]*?)\s*\|\s*$/);
    if (m && !/^-+$/.test(m[1]) && m[1] !== 'Campo') out[m[1]] = m[2];
    const q = line.match(/^(?:>\s*)?\**Estado\**:\s*\**\s*(\S+)/); // brief/constitution: «> Estado:» (o «Estado:» en formatos antiguos)
    if (q) out.Estado = q[1];
  }
  return out;
}
const num = (v) => { const m = String(v ?? '').match(/\d+/); return m ? Number(m[0]) : null; };
function verdict(text, key) {
  if (!text) return null;
  const re = new RegExp(`^[>\\-*\\s]*\\**${key}\\**\\s*:\\s*\\**\\s*([A-Za-zÁÉÍÓÚÑáéíóúñ]+)([^\\n]*)`, 'gmi');
  let m, last = null;
  while ((m = re.exec(text))) last = m[2].includes('|') ? null : m[1].toUpperCase(); // la línea de plantilla «SÍ | NO» no es un veredicto
  return last;
}
function declaredNext(text) {
  if (!text) return null;
  const re = /Siguiente paso\**\s*:\**\s*[`*]*(sdd-[a-z]+)[`*]*(?:\s+[`*]*(T-\d+)[`*]*)?/gi;
  let m, last = null;
  while ((m = re.exec(text))) last = { skill: m[1], tarea: m[2] ?? null };
  return last;
}
// ¿Hay trabajo commiteado relevante posterior a la última ejecución? Línea base: el último commit que tocó el artefacto
// (o su campo Commit). Cuenta el código y la carpeta de la propia spec; no cuentan docs/, reviews/, AGENTS.md,
// otras specs ni el propio artefacto. Lo no commiteado no cuenta (evita bucles).
// Modo amplio (scopeId nulo): cuenta cualquier código fuera de specs/ y la carpeta de la spec.
// Modo de spec (scopeId): solo commits con «(<scopeId>)» en el asunto o que tocan la carpeta de la spec
// (el trabajo de otras specs no invalida esta: su propia validación ejecuta la suite completa).
function workSince(sha, ownRel, extraExcl = [], scopeId = null, withRefactor = false) {
  const base = (tryGit('log', '-1', '--format=%H', '--', ownRel) ?? '').trim() || sha;
  if (!base) return null;
  const specDir = ownRel.split('/').slice(0, 2).join('/');
  const out = tryGit('log', '--format=%x01%s', '--name-only', `${base}..HEAD`, '--', '.', `:(exclude)${ownRel}`, ':(exclude)docs', ':(exclude)reviews', ':(exclude)AGENTS.md', ...extraExcl.map((x) => `:(exclude)${x}`));
  if (out === null) return null;
  for (const block of out.split('\x01').slice(1)) {
    const [subject, ...files] = block.split('\n').map((x) => x.trim()).filter(Boolean);
    if (/\bre-?sell(a|ado|os|ar)?\b|decisión de tamaño/i.test(subject)) continue; // los re-sellados solo tocan cabeceras: no son trabajo nuevo
    const inSpec = files.some((f) => f.startsWith(specDir + '/'));
    if (scopeId ? inSpec || subject.includes(`(${scopeId})`) || (withRefactor && /^refactor\b/i.test(subject)) : inSpec || files.some((f) => !f.startsWith('specs/'))) return true;
  }
  return false;
}

const lastCommit = (rel) => (tryGit('log', '-1', '--format=%H', '--', rel) ?? '').trim() || null;
// ¿El commit b es posterior (descendiente) al commit a?
const newer = (a, b) => !!(a && b && a !== b && tryGit('merge-base', '--is-ancestor', a, b) !== null);

function parseTasks(text) {
  const tasks = []; const bad = [];
  let cur = null;
  (text ?? '').split('\n').forEach((line, i) => {
    const m = line.match(/^[-*]\s+\[( |x|X)\]\s+[`*]*(T-\d+)\b/);
    if (m) { cur = { id: m[2], done: m[1] !== ' ', line: i + 1, body: [] }; tasks.push(cur); return; }
    if (/^[-*]\s*\[[ xX]?\]/.test(line) && /T-\d/.test(line)) bad.push(i + 1);
    if (/^#{1,3} /.test(line)) { cur = null; return; }
    if (cur) cur.body.push(line);
  });
  for (const t of tasks) {
    const body = t.body.join('\n');
    const dep = body.match(/Depende de:\s*([^\n]*)/);
    t.deps = dep ? (dep[1].match(/T-\d+/g) ?? []) : [];
    t.requiresUser = /Requiere usuario\**\s*:\**\s*S[IÍ]/i.test(body);
    t.reopened = /^\s*[-*]\s+\**Reabierta\**\s*:/im.test(body);
    const blLine = body.match(/^\s*(?:[-*]\s+)?\**Bloqueada\**:\**\s*(.*)$/m);
    const bl = blLine && blLine[1].match(/^(.*?)\s*(?:→|->)\s*`?(sdd-[a-z]+)`?/);
    const esp = blLine && blLine[1].match(/espera a\s+`?(\d{3}-[\w\u00C0-\uFFFF-]+)/);
    t.blocked = bl ? { motivo: bl[1], skill: bl[2] } : esp ? { motivo: `espera a ${esp[1]}`, skill: null, espera: esp[1] } : blLine ? { motivo: blLine[1], skill: null, invalida: true } : null;
    const evIdx = t.body.findIndex((l) => /^\s*[-*]\s+\**Evidencia\b/i.test(l));
    t.hasEvidenceLine = evIdx >= 0;
    const evHead = evIdx >= 0 ? t.body[evIdx] : '';
    t.evidencePending = /Evidencia(\s*\(T-\d+\))?\s*\**\s*:\s*\**\s*(pendiente|\(la añade sdd-implement\))[\s.*]*$/i.test(evHead.trim());
    t.evidenceMarkerUnique = evHead.includes(t.id);
    const headRest = (evHead.match(/Evidencia[^:]*:\s*(.*)$/) ?? [])[1] ?? '';
    const ev = [];
    if (evIdx >= 0) {
      const indent = evHead.match(/^\s*/)[0].length;
      for (let k = evIdx + 1; k < t.body.length; k++) {
        const l = t.body[k];
        if (!l.trim() || l.match(/^\s*/)[0].length <= indent) break;
        ev.push(l);
      }
    }
    t.evidenceLines = ev.length + (headRest.trim() && !t.evidencePending ? 1 : 0);
    t.fullVerify = /Verificación completa/i.test([headRest, ...ev].join('\n'));
  }
  tasks.bad = bad;
  return tasks;
}

// Backlog: | ID | Fecha | Severidad | Tipo | Hallazgo | Spec | Ruta | Estado |  (el Hallazgo puede contener «|»)
function backlogRows() {
  const t = read(join(root, 'reviews', 'backlog.md'));
  if (!t) return null;
  const rows = [];
  for (const l of t.split('\n')) {
    if (!/^\|\s*R-\d+/.test(l)) continue;
    const c = l.trim().replace(/^\|/, '').replace(/\|$/, '').split(/(?<!\\)\|/).map((x) => x.trim());
    const id = c[0];
    if (c.length < 8) { rows.push({ id, malformada: true }); continue; }
    const ruta = c[c.length - 2];
    const row = { id, severidad: c[2].toUpperCase(), spec: c[c.length - 3], rutaTexto: ruta, ruta: (ruta.match(/sdd-[a-z]+/) ?? [''])[0],
      tarea: (ruta.match(/T-\d+/) ?? [null])[0], estado: c[c.length - 1].toUpperCase() };
    row.global = /^(—|–|-|global)$/i.test(row.spec);
    rows.push(row);
  }
  return rows;
}
// Valida las filas abiertas contra las specs existentes. Una fila que no se puede clasificar nunca deja de bloquear:
// las de Spec o Severidad ilegibles (y las mal formadas) son «sin dueño» y bloquean validate y release de todas las specs.
function classifyBacklog(rows, existing) {
  for (const row of rows ?? []) {
    if (row.malformada || !/^ABIERTO\b/.test(row.estado)) continue;
    const nnns = row.spec.match(/(?<![-\w])\d{3}\b/g) ?? [];
    if (!/^(CR[IÍ]TIC[AO]|ALT[AO]|MEDI[AO]|BAJ[AO])\b/.test(row.severidad)) { row.error = `con Severidad no válida («${row.severidad}»): CRÍTICO, ALTO, MEDIO o BAJO`; row.sinDueno = true; }
    else if (!row.global && (!/^\d{3}\b/.test(row.spec) || nnns.length !== 1 || ![...existing].some((d) => d.startsWith(nnns[0] + '-')))) { row.error = `con Spec no válida («${row.spec}»): NNN [Req] de una spec existente, o — si es global`; row.sinDueno = true; }
    else if (!(row.global ? GLOBAL_ROUTES : ROUTES).includes(row.ruta) || (row.ruta === 'sdd-implement' && !row.tarea) || (row.global && row.tarea))
      row.error = `con Ruta no válida («${row.rutaTexto}»): ${row.global ? 'en una fila global (Spec —) sdd-bug, sdd-change, sdd-refactor o sdd-retro' : 'sdd-bug, sdd-change, sdd-refactor, sdd-plan, sdd-tasks o sdd-implement T-XXX'}`;
  }
}
const isOpen = (x) => !x.malformada && /^ABIERTO\b/.test(x.estado);
const isHigh = (x) => /CR[IÍ]TIC[AO]|ALT[AO]/.test(x.severidad);
// ¿Hay un veredicto negativo vigente de validate o release? (lo que sigue no debe heredar código sin commitear)
const afterNeg = (r) => ['validation.md', 'release.md'].some((f) => { const a = r.artefactos[f]; return a?.estado === 'VIGENTE' && a.veredicto !== null && !['SÍ', 'SI', 'READY'].includes(a.veredicto); });
const unowned = (rows) => (rows ?? []).filter((x) => x.malformada || (isOpen(x) && x.sinDueno));
// Una fila con formato no válido bloquea igual (no se pierde un CRÍTICO), pero enruta a corregir su formato.
const blockStep = (x) => (x.error || x.malformada
  ? { id: x.id, severidad: x.severidad ?? '?', ruta: 'sdd-review', tarea: null, global: !!x.global, formato: true }
  : { id: x.id, severidad: x.severidad, ruta: x.ruta, tarea: x.tarea, global: x.global, formato: false });
const blockMotivo = (b, extra) => `${b.id} ${b.severidad} ABIERTO${extra}${b.formato ? ' (formato no válido → sdd-review modo formato)' : ''}`;

function analyzeSpec(dir, rows, doneSpecs = new Set(), existing = new Set()) {
  const p = (f) => join(dir, f);
  const spec = read(p('spec.md'));
  const sh = header(spec);
  const specV = num(sh['Versión'] ?? sh['Version']);
  const id = basename(dir);
  const body = spec ? spec.split(/^## Registro de cambios/m)[0] : '';
  const r = { spec: id, specVersion: specV, estado: sh.Estado ?? null,
    aprobacion: sh['Aprobación'] ?? null, tamano: sh['Tamaño'] ?? null, origen: sh.Origen ?? null,
    dependeDe: (sh['Depende de'] ?? '').match(/\d{3}-[\w\u00C0-\uFFFF-]+/g) ?? [],
    pendientesAclaracion: (body.match(/\[NECESITA ACLARACIÓN:/g) ?? []).length,
    retroDefecto: /\(defecto\)/.test(body),
    retroPendiente: ((body.match(/^\s*(?:[-*]\s+)?\**Pendiente\**:\**\s*`?(sdd-retro|sdd-bug|sdd-change)\b/m) ?? [])[1]) ?? null,
    artefactos: {}, problemas: [], avisos: [], tareas: null, completada: false };
  if (!spec) { r.problemas.push({ msg: 'falta spec.md', skill: 'sdd-spec' }); r.siguiente = { skill: 'sdd-spec', motivo: 'falta spec.md' }; return r; }
  for (const k of ['Spec-ID', 'Versión', 'Estado', 'Aprobación', 'Tamaño', 'Interfaz', 'Origen'])
    if (!(k in sh)) r.avisos.push(`spec.md: cabecera sin «${k}»`);
  if (specV === null) r.problemas.push({ msg: 'spec.md sin «Versión» en la cabecera', skill: 'sdd-clarify' });
  const ph = header(read(p('plan.md')));
  const planV = num(ph['Plan-Version']);
  r.planVersion = planV;
  r.migracionRequerida = /^S[IÍ]/i.test(ph['Migración requerida'] ?? '');
  r.planAprobacion = ph['Aprobación'] ?? null;
  for (const f of DERIVED) {
    const t = read(p(f));
    if (t === null) { r.artefactos[f] = { estado: 'AUSENTE' }; continue; }
    const h = header(t);
    const sv = num(h['Spec-Version']);
    const pv = f === 'plan.md' || f === 'clarify.md' ? null : num(h['Plan-Version']);
    let estado = 'VIGENTE';
    if (sv === null) { estado = 'SIN-VERSIÓN'; r.avisos.push(`${f}: cabecera sin Spec-Version (se trata como caducado: la skill dueña re-sella)`); }
    else if (specV !== null && sv !== specV) estado = 'CADUCADO';
    const needsPlan = !['plan.md', 'clarify.md'].includes(f) && planV !== null;
    if (estado === 'VIGENTE' && needsPlan && pv === null) { estado = 'SIN-VERSIÓN'; r.avisos.push(`${f}: cabecera sin Plan-Version (se trata como caducado: la skill dueña re-sella)`); }
    if (estado === 'VIGENTE' && pv !== null && planV !== null && pv !== planV) estado = 'CADUCADO';
    r.artefactos[f] = { estado, specVersion: sv, planVersion: pv,
      veredicto: VERDICTS[f] ? verdict(t, VERDICTS[f]) : null, siguienteDeclarado: declaredNext(t),
      commit: (String(h.Commit ?? '').match(/\b[0-9a-f]{7,40}\b/) ?? [])[0] ?? null,
      adopcion: /^ADOPCI[OÓ]N/i.test(String(h.Evidencia ?? '')) || /^\s*(?:[-*]\s+)?\**Evidencia\**:\**\s*ADOPCI[OÓ]N/im.test(t) };
  }
  for (const f of readdirSync(dir).sort()) if (!KNOWN.has(f) && !f.startsWith('.')) r.avisos.push(`artefacto no reconocido por el flujo: ${f} (intégralo con sdd-change o sdd-release lo archiva)`);
  const tt = read(p('tasks.md'));
  for (const mv of body.match(/movido a\s+`?\d{3}-[\w\u00C0-\uFFFF-]+/g) ?? []) {
    const tgt = mv.replace(/movido a\s+`?/, '');
    if (existing.size && !existing.has(tgt)) r.problemas.push({ msg: `RF movido a ${tgt}, que no existe: créala`, skill: 'sdd-spec' });
  }
  const adopted = r.artefactos['release.md']?.estado === 'VIGENTE' && r.artefactos['release.md'].adopcion;
  if (tt && !adopted) {
    const tasks = parseTasks(tt);
    for (const ln of tasks.bad) r.problemas.push({ msg: `tasks.md:${ln}: línea de tarea ilegible (formato: «- [ ] T-NNN — objetivo»)`, skill: 'sdd-tasks' });
    for (const t of tasks) {
      const e = t.blocked?.espera;
      if (e && doneSpecs.has(e)) { r.avisos.push(`${t.id}: ${e} ya está completada; quita la línea «Bloqueada: espera a ${e}»`); t.blocked = null; }
      else if (e && existing.size && !existing.has(e)) r.problemas.push({ msg: `${t.id} espera a ${e}, que no existe: créala`, skill: 'sdd-spec' });
    }
    const archivedT = parseTasks(read(p('tasks-archive.md')));
    const archived = new Set(archivedT.filter((t) => t.done).map((t) => t.id));
    const ids = new Map();
    for (const t of tasks) {
      if (ids.has(t.id)) r.problemas.push({ msg: `${t.id} duplicada (líneas ${ids.get(t.id)} y ${t.line})`, skill: 'sdd-tasks' });
      ids.set(t.id, t.line);
      if (archived.has(t.id)) r.problemas.push({ msg: `${t.id} está también en tasks-archive.md: las archivadas no se reabren, crea una tarea nueva`, skill: 'sdd-tasks' });
      if (t.done && (!t.hasEvidenceLine || t.evidencePending || t.evidenceLines === 0))
        r.problemas.push({ msg: `${t.id} marcada [x] sin evidencia`, skill: 'sdd-implement', tarea: t.id, modo: 're-sellado' });
      if (!t.done && t.hasEvidenceLine && !t.evidencePending)
        r.problemas.push(t.reopened
          ? { msg: `${t.id} reabierta con evidencia antigua: sustituye la evidencia por el marcador pendiente e implementa`, skill: 'sdd-implement', tarea: t.id }
          : { msg: `${t.id} pendiente con evidencia escrita (¿falta marcar [x] o reabrir?)`, skill: 'sdd-implement', tarea: t.id, modo: 're-sellado' });
      if (!t.done && !t.evidenceMarkerUnique)
        r.avisos.push(`${t.id}: marcador de evidencia no único (usa «Evidencia (${t.id}): pendiente»)`);
      if (t.done && t.evidenceLines > LIMITS.evidenceLines)
        r.avisos.push(`${t.id}: evidencia de ${t.evidenceLines} líneas (máx. ${LIMITS.evidenceLines})`);
    }
    r._ids = new Set(tasks.map((t) => t.id)); r._arch = archived;
    const done = new Set([...archived, ...tasks.filter((t) => t.done).map((t) => t.id)]);
    const pending = tasks.filter((t) => !t.done);
    for (const t of pending.filter((x) => x.blocked?.invalida)) r.problemas.push({ msg: `${t.id}: línea Bloqueada sin destino legible (formato: «Bloqueada: <motivo> → <skill>» o «Bloqueada: espera a NNN-slug»)`, skill: 'sdd-tasks' });
    const blockedT = pending.find((t) => t.blocked?.skill && /fallo compartido/i.test(t.blocked.motivo)) ?? pending.find((t) => t.blocked && t.blocked.skill);
    const ready = pending.filter((t) => !t.blocked && t.deps.every((d) => done.has(d)));
    const next = ready.find((t) => !t.requiresUser) ?? ready[0];
    let since = 0;
    for (const t of tasks) { if (t.done) since = t.fullVerify ? 0 : since + 1; }
    r.tareas = { total: tasks.length, hechas: tasks.filter((t) => t.done).length, archivadas: archived.size,
      pendientes: pending.length, siguiente: next?.id ?? null, siguienteRequiereUsuario: !!next?.requiresUser,
      esperanUsuario: ready.filter((t) => t.requiresUser).map((t) => t.id),
      bloqueadas: pending.length && !next ? pending.map((t) => t.id) : [],
      desdeTodo: since, pedirTodo: since >= LIMITS.fullVerifyEvery,
      bloqueada: blockedT ? { tarea: blockedT.id, skill: blockedT.blocked.skill, motivo: blockedT.blocked.motivo } : null,
      esperanSpec: pending.filter((t) => t.blocked?.espera).map((t) => `${t.id}→${t.blocked.espera}`) };
    const bytes = statSync(p('tasks.md')).size;
    if (bytes > LIMITS.tasksBytes) r.avisos.push(`tasks.md ocupa ${Math.round(bytes / 1024)} KB: lo archiva sdd-release al cerrar el ciclo; si no hay ciclo cerrado, valora partir la spec`);
    if (pending.length > LIMITS.openTasks) r.avisos.push(`${pending.length} tareas abiertas (> ${LIMITS.openTasks}): valora partir la spec`);
  }
  const nnn = id.slice(0, 3);
  const mine = (rows ?? []).filter((x) => isOpen(x) && !x.global && !x.sinDueno && x.spec.startsWith(nnn));
  // Ruta hacia una tarea: archivada → sdd-tasks crea la sustituta; inexistente → la Ruta se corrige (formato).
  for (const x of mine.filter((y) => y.ruta === 'sdd-implement' && y.tarea && r._ids)) {
    if (r._arch.has(x.tarea) && !r._ids.has(x.tarea)) { x.ruta = 'sdd-tasks'; x.tarea = null; }
    else if (!r._ids.has(x.tarea)) {
      const msg = `backlog: ${x.id} apunta a ${x.tarea}, que no existe en ${id}: corrige su Ruta`;
      if (isHigh(x)) r.problemas.push({ msg, skill: 'sdd-review' }); else r.avisos.push(msg); // MEDIO/BAJO no interrumpen la cadena
    }
  }
  delete r._ids; delete r._arch;
  r.backlogBloqueante = mine.filter(isHigh).map(blockStep);
  r.siguiente = nextStep(r, dir);
  const gate = ['sdd-validate', 'sdd-release'].includes(r.siguiente.skill);
  const u = unowned(rows)[0];
  // Hallazgos CRÍTICO/ALTO globales (Spec —, p. ej. código compartido): no reabren specs completadas, pero bloquean todo release.
  const g = (rows ?? []).find((x) => isOpen(x) && isHigh(x) && x.global);
  if (u && gate) r.siguiente = { skill: 'sdd-review', tarea: null, motivo: blockMotivo(blockStep(u), ' (sin spec reconocible) bloquea validate y release') };
  else if (g && r.siguiente.skill === 'sdd-release') { const b = blockStep(g); r.siguiente = { skill: b.ruta, tarea: b.tarea, motivo: blockMotivo(b, ' (global) bloquea el release') }; }
  else if ((gate || (afterNeg(r) && r.siguiente.skill)) && DIRTY.length) r.siguiente = { skill: null, motivo: `requiere acción: código o tareas sin commitear (${DIRTY.slice(0, 5).join(', ')}): commitearlos con su skill, aparcarlos o descartarlos` };
  r.completada = r.siguiente.skill === null && /completada/.test(r.siguiente.motivo);
  return r;
}

function afterNegative(r, dir, file, skill, label) {
  // Veredicto negativo vigente: con trabajo posterior a su commit → repetir la skill;
  // si no, el «Siguiente paso» declarado, salvo que esa skill ya esté satisfecha (evita bucles).
  const art = r.artefactos[file];
  const rel = join(dir.slice(root.length + 1) || dir, file).replace(/\\/g, '/');
  const changed = workSince(art.commit, rel, [], file === 'validation.md' ? r.spec : null, true);
  if (changed === true) return { skill, motivo: `${label} y hay trabajo commiteado posterior a la última ejecución: repetir` };
  const d = art.siguienteDeclarado;
  const own = d && OWN[d.skill];
  const satisfied = own && r.artefactos[own[0]]?.estado === 'VIGENTE' && own[1].includes(r.artefactos[own[0]].veredicto);
  if (d && STEPS.has(d.skill) && d.skill !== skill && !satisfied) return { skill: d.skill, tarea: d.tarea, motivo: `${label}: siguiente paso declarado en el artefacto` };
  return { skill: null, motivo: `${label}: requiere acción (sin siguiente paso aplicable ni trabajo posterior a la última ejecución)` };
}

function nextStep(r, dir) {
  const a = r.artefactos;
  const vig = (f) => a[f] && a[f].estado === 'VIGENTE';
  if (r.problemas.some((p) => p.skill === 'sdd-clarify')) return { skill: 'sdd-clarify', motivo: r.problemas.find((p) => p.skill === 'sdd-clarify').msg };
  const rel = (f) => join(dir.slice(root.length + 1) || dir, f).replace(/\\/g, '/');
  const blk = r.backlogBloqueante[0];
  const blkStep = blk ? { skill: blk.ruta, tarea: blk.tarea, motivo: blockMotivo(blk, ' en el backlog') } : null;
  if (/^RETRO/i.test(r.origen ?? '') && r.specVersion === 1 && /^APROBADA\b/.test(r.estado ?? '') && a['plan.md'].estado === 'AUSENTE')
    return r.retroDefecto ? { skill: 'sdd-bug', motivo: 'spec RETRO con RF marcados (defecto)' }
      : r.retroPendiente ? { skill: r.retroPendiente, motivo: 'spec RETRO aprobada con pedido pendiente (Pendiente: en la spec)' }
      : blkStep ?? { skill: null, motivo: 'spec RETRO completada' };
  // Spec adoptada (release en modo adopción, sin validación): completada mientras no haya bugs ni trabajo posteriores.
  const specProb = r.problemas.find((p) => p.skill === 'sdd-spec');
  if (specProb) return { skill: 'sdd-spec', motivo: specProb.msg };
  if (vig('release.md') && a['release.md'].adopcion && a['release.md'].veredicto !== 'READY') {
    if (blkStep) return blkStep;
    if (newer(lastCommit(rel('release.md')), lastCommit(rel('bugs')))) return { skill: 'sdd-release', motivo: 'adopción BLOCKED y bug corregido después: repetir el release de adopción' };
    const dn = a['release.md'].siguienteDeclarado;
    return dn && dn.skill !== 'sdd-release' && STEPS.has(dn.skill) ? { skill: dn.skill, tarea: dn.tarea, motivo: 'RELEASE de adopción BLOCKED: siguiente paso declarado' } : { skill: null, motivo: 'RELEASE de adopción BLOCKED: requiere acción' };
  }
  if (vig('release.md') && a['release.md'].adopcion && a['release.md'].veredicto === 'READY') {
    if (blkStep) return blkStep;
    const relA = lastCommit(rel('release.md'));
    if (newer(relA, lastCommit(rel('bugs')))) return { skill: 'sdd-release', motivo: 'bug corregido en una spec adoptada: nuevo release de adopción (con la fila Todo)' };
    if (workSince(null, rel('release.md'), [], r.spec) !== true)
      return { skill: null, motivo: 'spec completada (adopción, RELEASE: READY vigente)' };
  }
  if (!/^APROBADA\b/.test(r.estado ?? '') || !/APROBADA/.test(r.aprobacion ?? '') || r.pendientesAclaracion > 0 || !vig('clarify.md') || !['SÍ', 'SI'].includes(a['clarify.md'].veredicto))
    return { skill: 'sdd-clarify', motivo: 'spec no aprobada, con dudas o clarify ausente/caducado/sin versión/NO' };
  if (!vig('plan.md') || /PENDIENTE/.test(r.planAprobacion ?? ''))
    return { skill: 'sdd-plan', motivo: 'plan ausente, caducado, sin versión o pendiente de aprobación' };
  if (r.migracionRequerida) {
    if (!vig('migration-review.md')) return { skill: 'sdd-migration', motivo: 'migración requerida sin revisión vigente' };
    if (a['migration-review.md'].veredicto === null) return { skill: 'sdd-migration', motivo: 'migration-review.md sin veredicto (heredado)' };
    if (a['migration-review.md'].veredicto !== 'SUFICIENTE') return { skill: 'sdd-plan', motivo: 'MIGRACIÓN: INCOMPLETA — completar §10 (sube Plan-Version)' };
  }
  if (!vig('tasks.md')) return { skill: 'sdd-tasks', motivo: 'tasks.md ausente, caducado o sin versión' };
  if (a['tasks.md'].veredicto === null) return { skill: 'sdd-tasks', motivo: 'tasks.md sin veredicto TRAZABILIDAD (heredado): auditar la trazabilidad y emitirlo' };
  if (a['tasks.md'].veredicto !== 'PASS') {
    const d = a['tasks.md'].siguienteDeclarado;
    return { skill: d?.skill === 'sdd-change' ? 'sdd-change' : 'sdd-plan', motivo: 'TRAZABILIDAD: FAIL (la skill de destino sube su versión, lo que regenera tasks)' };
  }
  if (r.problemas.length) { const p = r.problemas[0]; return { skill: p.skill, tarea: p.tarea ?? null, motivo: `${p.msg}${p.modo ? ' — modo ' + p.modo + ': re-ejecuta sus tests y sella la evidencia sin cambiar código si pasan' : ''}` }; }
  if (r.tareas?.bloqueada && (/fallo compartido/i.test(r.tareas.bloqueada.motivo) || !(r.tareas.siguiente && !r.tareas.siguienteRequiereUsuario))) {
    const b = r.tareas.bloqueada;
    return { skill: b.skill, tarea: b.skill === 'sdd-implement' ? b.tarea : null, motivo: `${b.tarea} bloqueada: ${b.motivo}` };
  }
  if (r.tareas?.pendientes) {
    if (!r.tareas.siguiente && r.tareas.esperanSpec.length) return { skill: null, motivo: `tareas esperando a otra spec: ${r.tareas.esperanSpec.join(', ')}` };
    if (!r.tareas.siguiente) return { skill: 'sdd-tasks', motivo: `pendientes con dependencias no resolubles: ${r.tareas.bloqueadas.join(', ')}` };
    return { skill: 'sdd-implement', tarea: r.tareas.siguiente,
      motivo: `${r.tareas.pendientes} tareas pendientes${r.tareas.siguienteRequiereUsuario ? ' — REQUIERE USUARIO (no lanzar sin él)' : ''}${r.tareas.pedirTodo ? ' — pedir verificación completa (fila Todo)' : ''}` };
  }
  if (r.backlogBloqueante.length) {
    const b = r.backlogBloqueante[0];
    return { skill: b.ruta, tarea: b.tarea, motivo: blockMotivo(b, ' en el backlog (bloquea validate)') };
  }
  if (!vig('validation.md')) return { skill: 'sdd-validate', motivo: 'validación ausente, caducada o sin versión' };
  const bugC = lastCommit(rel('bugs'));
  const valC = lastCommit(rel('validation.md'));
  const relC = lastCommit(rel('release.md'));
  if (['SÍ', 'SI'].includes(a['validation.md'].veredicto)) {
    if (newer(valC, bugC)) return { skill: 'sdd-validate', motivo: 'bug corregido después de la validación: repetir' };
    // Base: el último entre validación y release (el commit de release archiva tareas y no es trabajo nuevo).
    const afterRel = newer(valC, relC);
    if (workSince(null, afterRel ? rel('release.md') : rel('validation.md'), [afterRel ? rel('validation.md') : rel('release.md')], r.spec) === true) return { skill: 'sdd-validate', motivo: 'trabajo commiteado posterior a la validación: repetir' };
  }
  if (a['validation.md'].veredicto === null) return { skill: 'sdd-validate', motivo: 'validation.md sin veredicto (heredado)' };
  if (!['SÍ', 'SI'].includes(a['validation.md'].veredicto)) return afterNegative(r, dir, 'validation.md', 'sdd-validate', 'SPEC CUMPLIDA: NO');
  if (!vig('release.md')) return { skill: 'sdd-release', motivo: 'release ausente, caducado o sin versión' };
  if (a['release.md'].veredicto === null) return { skill: 'sdd-release', motivo: 'release.md sin veredicto (heredado)' };
  if (a['release.md'].veredicto !== 'READY') return afterNegative(r, dir, 'release.md', 'sdd-release', 'RELEASE: BLOCKED');
  if (newer(relC, bugC)) return { skill: 'sdd-release', motivo: 'bug corregido después del release: nuevo release' };
  if (newer(relC, valC)) return { skill: 'sdd-release', motivo: 'validación posterior al release: nuevo release' };
  return { skill: null, motivo: 'spec completada (RELEASE: READY vigente)' };
}

function project(rows, nSpecs) {
  const res = { problemas: [], avisos: [] };
  if (!existsSync(join(root, 'docs/brief.md'))) res.siguiente = { skill: 'sdd-init', motivo: 'falta docs/brief.md' };
  else if (header(read(join(root, 'docs/constitution.md'))).Estado?.startsWith('APROBADA') !== true)
    res.siguiente = { skill: 'sdd-constitution', motivo: 'constitution ausente o no APROBADA' };
  else if (!existsSync(join(root, 'AGENTS.md'))) res.siguiente = { skill: 'sdd-agents', motivo: 'falta AGENTS.md' };
  else if (!(num((read(join(root, 'AGENTS.md')) ?? '').match(/sdd-conventions:\s*\d+/)?.[0]) >= CONVENTIONS)) res.siguiente = { skill: 'sdd-agents', motivo: `AGENTS.md sin las Convenciones SDD actuales (marcador sdd-conventions: ${CONVENTIONS})` };
  else if (!(num((read(join(root, 'docs/sdd-conventions.md')) ?? '').match(/sdd-conventions:\s*\d+/)?.[0]) >= CONVENTIONS)) res.siguiente = { skill: 'sdd-agents', motivo: `falta docs/sdd-conventions.md o es de otra versión (marcador sdd-conventions: ${CONVENTIONS})` };
  else if (nSpecs === 0) res.siguiente = { skill: 'sdd-spec', motivo: 'no hay specs: describe una funcionalidad' };
  const secRow = (read(join(root, 'AGENTS.md')) ?? '').split('\n').find((l) => /^\|\s*Seguridad/i.test(l));
  const MANIF = ['package.json', 'requirements.txt', 'pyproject.toml', 'Pipfile', 'go.mod', 'Cargo.toml', 'Gemfile', 'pom.xml', 'build.gradle', 'composer.json'];
  const manif = [...new Set([...MANIF.filter((f) => existsSync(join(root, f))), // también en monorepos (versionados, fuera de dependencias instaladas)
    ...splitZ(tryGit('ls-files', '-z')).filter((f) => MANIF.includes(f.split('/').pop()) && !/(^|\/)(node_modules|vendor)\//.test(f))])].slice(0, 5);
  if (existsSync(join(root, 'specs'))) for (const d of readdirSync(join(root, 'specs'))) if (!/^\d{3}-/.test(d) && !d.startsWith('.') && statSync(join(root, 'specs', d)).isDirectory()) res.avisos.push(`specs/${d} no sigue el formato NNN-slug y se ignora (renómbrala para incluirla en el flujo)`);
  if (secRow && /no disponible|pendiente/i.test(secRow) && manif.length) res.avisos.push(`la fila Seguridad de AGENTS.md no tiene comando real pero hay manifiesto de dependencias (${manif.join(', ')}): actívala si hay dependencias de runtime (la tarea que las introduce, o sdd-agents)`);
  if (!existsSync(join(root, 'docs/agent-runbook.md'))) res.avisos.push('falta docs/agent-runbook.md (conocimiento operativo versionado; ver sdd-agents)');
  const lastRel = (tryGit('log', '-1', '--format=%H', '--', 'specs/*/release.md') ?? '').trim();
  if (lastRel) {
    const subj = (tryGit('log', '--format=%s', `${lastRel}..HEAD`, '--', '.', ':(exclude)specs', ':(exclude)docs', ':(exclude)reviews', ':(exclude)AGENTS.md') ?? '').split('\n').filter(Boolean);
    const loose = subj.filter((x) => !/\(\d{3}-[^)]*\)/.test(x) && !/^(refactor|docs|test|chore)\b/.test(x));
    if (loose.length) res.avisos.push(`${loose.length} commit(s) de código posteriores al último release sin spec ni refactor (p. ej. «${loose[0].slice(0, 60)}»): ¿pasan por sdd-bug, sdd-change o sdd-refactor?`);
  }
  for (const x of (rows ?? []).filter((y) => y.malformada)) res.problemas.push(`backlog: fila ${x.id} mal formada (se esperan 8 columnas: ID|Fecha|Severidad|Tipo|Hallazgo|Spec|Ruta|Estado) → corrige su formato (quien la escribió o sdd-review en modo formato)`);
  for (const x of (rows ?? []).filter((y) => y.error)) res.problemas.push(`backlog: fila ${x.id} ${x.error} → corrige su formato (quien la escribió o sdd-review en modo formato)`);
  return res;
}

// «Árbol limpio» de AGENTS.md › Commits: cuentan el código, tasks.md y BUG-NNN.md; el resto de specs/, docs/, reviews/ y AGENTS.md, no.
function dirtyFiles() {
  const changed = [...splitZ(tryGit('diff', '--name-only', '-z', 'HEAD')), ...splitZ(tryGit('ls-files', '--others', '--exclude-standard', '-z'))];
  return [...new Set(changed)].filter((f) => !(/^(specs|docs|reviews)\//.test(f) && !/^specs\/[^/]+\/(tasks\.md|bugs\/BUG-[^/]*\.md)$/.test(f)) && f !== 'AGENTS.md').sort();
}
let DIRTY = [];

function status() {
  const rows = backlogRows();
  const specsDir = join(root, 'specs');
  const only = opt('--spec');
  const all = existsSync(specsDir) ? readdirSync(specsDir).filter((d) => /^\d{3}-/.test(d) && statSync(join(specsDir, d)).isDirectory()).sort() : [];
  const existing = new Set(all);
  classifyBacklog(rows, existing);
  DIRTY = dirtyFiles();
  const proj = project(rows, all.length);
  const first = all.map((d) => analyzeSpec(join(specsDir, d), rows, new Set(), existing));
  const doneSet = new Set(first.filter((r) => r.completada).map((r) => r.spec));
  const results = all.map((d) => analyzeSpec(join(specsDir, d), rows, doneSet, existing));
  const byId = new Map(results.map((r) => [r.spec, r]));
  for (const r of results) {
    const waits = (r.tareas?.esperanSpec ?? []).map((x) => x.split('→')[1]);
    r.esperaA = [...new Set([...r.dependeDe, ...waits])].filter((d) => !byId.get(d)?.completada);
    const plainImpl = r.siguiente.skill === 'sdd-implement' && !r.problemas.length;
    if (r.esperaA.length && plainImpl && !r.tareas?.siguiente) r.siguiente = { skill: null, motivo: `espera a ${r.esperaA.join(', ')}` };
    for (const d of r.esperaA) if (byId.get(d)?.dependeDe.includes(r.spec) || (byId.get(d)?.tareas?.esperanSpec ?? []).some((x) => x.endsWith('→' + r.spec)))
      r.problemas.push({ msg: `ciclo de dependencias entre ${r.spec} y ${d}: una de las dos debe dejar de esperar a la otra`, skill: 'sdd-tasks' });
    if (r.dependeDe.some((d) => r.esperaA.includes(d)) && plainImpl) r.siguiente = { skill: null, motivo: `Depende de ${r.esperaA.join(', ')}, aún no completada: no se implementa todavía` };
    for (const d of r.dependeDe) if (!byId.has(d)) r.avisos.push(`Depende de ${d}, que no existe`);
  }
  // El paso del proyecto (brief, constitución, AGENTS.md y convenciones) va antes que cualquier spec.
  if (proj.siguiente && ['sdd-init', 'sdd-constitution', 'sdd-agents'].includes(proj.siguiente.skill))
    for (const r of results) if (r.siguiente.skill) r.siguiente = { skill: null, motivo: `antes, el paso del proyecto (${proj.siguiente.skill})` };
  const activeAll = results.filter((r) => !r.completada);
  // Sin specs activas, un hallazgo sin dueño o un CRÍTICO/ALTO global sigue necesitando una ruta.
  if (!activeAll.length && (!proj.siguiente || proj.siguiente.skill === 'sdd-spec')) {
    const u = unowned(rows)[0];
    const g = (rows ?? []).find((x) => isOpen(x) && isHigh(x) && x.global);
    if (u) proj.siguiente = { skill: 'sdd-review', motivo: blockMotivo(blockStep(u), ' (sin spec reconocible)') };
    else if (g) { const b = blockStep(g); proj.siguiente = { skill: b.ruta, motivo: blockMotivo(b, ' (global) sin spec activa') }; }
  }
  const inProgress = activeAll.filter((r) => !r.esperaA.length && r.tareas && r.tareas.hechas > 0 && r.tareas.pendientes > 0);
  const active = inProgress.length ? inProgress : activeAll.filter((r) => !r.esperaA.length);
  const shown = only ? results.filter((r) => r.spec === only) : results;
  if (only && !shown.length) { console.error(`sdd-check: la spec ${only} no existe`); return 2; }
  const open = (rows ?? []).filter(isOpen);
  const out = { proyecto: proj,
    backlog: rows ? { abiertos: open.length, criticosAltos: open.filter(isHigh).map((x) => x.id) } : null,
    specs: shown, activas: active.map((r) => r.spec) };
  for (const r of results) { delete r.retroDefecto; delete r.retroPendiente; }
  if (flag('--json')) { console.log(JSON.stringify(out, null, 2)); }
  else {
    if (proj.siguiente) console.log(`PROYECTO · SIGUIENTE PASO: ${proj.siguiente.skill} · MOTIVO: ${proj.siguiente.motivo}`);
    for (const w of proj.avisos) console.log(`AVISO: ${w}`);
    for (const p of proj.problemas) console.log(`PROBLEMA: ${p}`);
    if (out.backlog) console.log(`BACKLOG: ${out.backlog.abiertos} abiertos · CRÍTICO/ALTO: ${out.backlog.criticosAltos.join(', ') || 'ninguno'}`);
    for (const r of shown) {
      if (r.completada && !only && !r.problemas.length && !r.avisos.length) { console.log(`\nSPEC ${r.spec} v${show(r.specVersion)} · SIGUIENTE PASO: — · MOTIVO: ${r.siguiente.motivo}`); continue; }
      const arts = Object.entries(r.artefactos).map(([f, v]) => `${f.replace('.md', '')}=${f === 'migration-review.md' && !r.migracionRequerida && v.estado !== 'VIGENTE' ? 'N/A' : v.estado === 'VIGENTE' ? (v.veredicto ?? 'ok') : v.estado}`).join(' ');
      console.log(`\nSPEC ${r.spec} v${show(r.specVersion)} · ${show(r.estado)} · Tamaño ${show(r.tamano)} · plan v${show(r.planVersion)}`);
      if (arts) console.log(`  ${arts}`);
      if (r.tareas) console.log(`  tareas ${r.tareas.hechas}/${r.tareas.total} (+${r.tareas.archivadas} archivadas) · siguiente ${r.tareas.siguiente ?? '—'} · cerradas desde la última verificación completa: ${r.tareas.desdeTodo}`);
      for (const p of r.problemas) console.log(`  PROBLEMA: ${p.msg}`);
      if (r.tareas?.esperanUsuario?.length) console.log(`  esperan al usuario: ${r.tareas.esperanUsuario.join(', ')}`);
      if (r.tareas?.esperanSpec?.length) console.log(`  esperan a otra spec: ${r.tareas.esperanSpec.join(', ')}`);
      for (const w of r.avisos.slice(0, 12)) console.log(`  aviso: ${w}`);
      if (r.avisos.length > 12) console.log(`  aviso: … y ${r.avisos.length - 12} más (--json)`);
      if (r.esperaA?.length && !r.completada) console.log(`  espera a: ${r.esperaA.join(', ')} (Depende de)`);
      const s = r.siguiente;
      console.log(`  SIGUIENTE PASO: ${s.skill ?? '—'}${s.tarea ? ' ' + s.tarea : ''} · MOTIVO: ${s.motivo}`);
    }
    if (!only) {
      if (!active.length && activeAll.length) console.log(`\nAVISO: ninguna spec avanzable: todas esperan a dependencias no completadas o inexistentes (${activeAll.map((r) => r.spec).join(', ')})`);
      else if (active.length > 1) console.log(`\nAVISO: ${active.length} specs activas sin orden por dependencias (${out.activas.join(', ')}): elige una.`);
      else if (active.length === 1 && activeAll.length > 1) console.log(`\nSPEC A AVANZAR: ${active[0].spec} (en curso o sin dependencias pendientes)`);
    }
  }
  // Los problemas del backlog cuentan también con --spec: validate y release exigen «sin PROBLEMA».
  return shown.some((r) => r.problemas.length) || (!only && proj.problemas.length) || proj.problemas.some((p) => p.startsWith('backlog:')) ? 1 : 0;
}

// Secretos (política del paquete). FAIL: formatos de proveedor (en cualquier fichero) y, en código, credenciales con
// estructura (SECRET_STRONG) y .env reales. AVISO: heurísticas por nombre (SECRET_SOFT) y todo lo de tests, fixtures,
// documentación y .env de desarrollo. El escáner dedicado de CI (p. ej. gitleaks) bloquea lo que aquí solo avisa.
// «sdd-allow-secret» en la línea silencia un aviso; sobre un hallazgo que bloquea deja un AVISO de revisión humana y, en
// CI (--range), solo pasa si el sha256 de fichero y línea (el que muestra el FAIL) está en .sdd-allowed-secrets de la
// base del rango (en local, la versión commiteada). Los valores …EXAMPLE… de los proveedores no cuentan. La salida nunca
// muestra el secreto: fichero:línea y sus 4 primeros caracteres.
const SECRET_HARD = [
  /-----BEGIN [A-Z ]*PRIVATE KEY( BLOCK)?-----/, /\bAKIA[0-9A-Z]{16}\b/, /\bgh[pousr]_[A-Za-z0-9]{30,}\b/,
  /\bxox[abp]-[A-Za-z0-9-]{10,}/, /\bsk-(?:proj-|ant-|svcacct-)?[A-Za-z0-9_-]{32,}/, /\bAIza[0-9A-Za-z_-]{35}\b/,
  /\bgithub_pat_[A-Za-z0-9_]{40,}/, /\b[sr]k_live_[A-Za-z0-9]{20,}/, /\bglpat-[A-Za-z0-9_-]{20,}/,
  /\bnpm_[A-Za-z0-9]{36}\b/, /\bSG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}\b/,
  /hooks\.slack\.com\/services\/T[A-Z0-9]+\/B[A-Z0-9]+\/[A-Za-z0-9]{20,}/, /AccountKey=[A-Za-z0-9+/]{40,}={0,2}/,
  /\bwhsec_[A-Za-z0-9+/=]{20,}/, /\bhf_[A-Za-z0-9]{30,}\b/, /\bhvs\.[\w-]{24,}/, /\b\d{8,10}:AA[\w-]{33}\b/, /discord(?:app)?\.com\/api\/webhooks\/\d+\/[\w-]{50,}/,
  /LS0tLS1CRUdJTiB(?:QUklWQVRF|SU0EgUFJJVkFURS|FQyBQUklWQVRF|PUEVOU1NIIFBSSVZBVEU)/, // clave privada PEM en base64 (p. ej. Secrets de k8s)
];
// Alta confianza fuera de un formato de proveedor (credenciales con estructura): FAIL en código, AVISO en tests y docs.
const SECRET_STRONG = [
  /\bAuthorization['"]?\s*[:,]\s*['"`]?Basic\s+[A-Za-z0-9+/=]{12,256}/i, /\bcurl\b.{0,512}\s-u\s+(?!\$)[^\s:'"]{1,128}:(?!\$)[^\s'"]{3,256}/, /\bmysql(?:dump|admin)?\b.{0,512}\s-p(?!\$)[^\s'"]{3,256}/,
  /\bauth\s*=\s*\(\s*['"][^'"]{1,128}['"]\s*,\s*['"][^'"]{6,256}['"]\s*\)/, // requests auth=(usuario, contraseña)
  /\bNetworkCredential\(\s*"[^"]{0,128}"\s*,\s*"[^"]{6,256}"/, /\bsshpass\s+-p\s*['"]?(?!\$)[^\s'"]{6,256}/,
  /\beyJ[A-Za-z0-9_-]{8,4096}\.eyJ[A-Za-z0-9_-]{8,4096}\.[A-Za-z0-9_-]{8,4096}/,
];
// Heurísticas por nombre (password=, *_KEY=, fooKey=, define(), SQL): siempre AVISO visible (política: los falsos positivos
// no bloquean commits; el escáner dedicado de CI, p. ej. gitleaks, es el que bloquea). Repeticiones acotadas ({…,256}):
// tiempo lineal en líneas de cientos de KB. Exclusiones: referencias, llamadas, identificadores, claves públicas, «===».
// URL con credenciales (usuario opcional): FAIL salvo contraseña de relleno o igual al usuario (valores de desarrollo
// conocidos: no es un secreto) o host local (AVISO).
const URL_CRED = /\b[a-z][a-z0-9+.-]{0,30}:\/\/([^\s:/@'"$]{0,256}):(?![$%{<])([^\s@'"/]{3,256})@([^\s/:'"?#]{1,256})/i;
const URL_PLACEHOLDER = /^(pass|passwd|password|changeme|change_me|secret|guest|example|test|testing|dev|root|admin|postgres|mysql|redis|user|x{3,}|\*{3,})$/i;
const LOCAL_HOST = /^(localhost|127\.0\.0\.1|0\.0\.0\.0|\[?::1\]?|host\.docker\.internal)$/i;
const SECRET_SOFT = [
  /(?<!public[_-])(?<!existing[_-]?)(?:password|passwd|pwd|secret|api[_-]?key|token|access[_-]?key|credentials?)(?:\s*:\s*[\w&<>\[\]|.*]{1,40}?\s*(?==)|\s+[\w&<>\[\]|.*]{1,40}?\s*(?==))?['"]?\s*(?::=|=>|[:=])(?![=>])\s*['"]?(?!\$[{(A-Z_]|[<{%(\[~/]|process\.env|os\.environ|var\.|ssh-|projects\/|https?:|pk_(?:live|test)_|[\w.:\\]+[(\[]|\d+['\"]?(?:[\s,;)]|$)|[A-Za-z_][\w-]*(?:\.[\w-]+)+(?=['\"\s,;)]|$))(?=[^'"\s]{0,256}\d)[^'"\s,;]{8,256}/i,
  /(?<!existing[_-]?)(?:password|passwd|secret|secret[_-]?key)['"]?\s*(?::=|=>|[:=])(?![=>])\s*['"](?!\$[{(A-Z_]|[<{%~/]|projects\/|[a-z][a-z0-9]*(?:_[a-z0-9]+)+['"]|[A-Za-z_][\w-]*(?:\.[\w-]+)+(?=['\"\s,;)]|$))[^'"\s]{12,256}['"]/i, // frase de paso entre comillas
  /(?<![Pp][Uu][Bb][Ll][Ii][Cc])(?<![Ss][Ii][Tt][Ee])[_-][Kk][Ee][Yy]['"]?\s*(?::=|=>|[:=])(?![=>])\s*['"]?(?!pk_(?:live|test)_|[a-z][a-z0-9]*(?:[_-][a-z0-9]*)+['\"]?(?=[\s,;)]|$)|[a-z]{2,}(?:[A-Z][a-z]{2,}[0-9]*)*(?:[A-Z][0-9]*)?['\"]?(?=[\s,;)]|$)|[A-Za-z_][\w-]*(?:\.[\w-]+)+(?=['\"\s,;)]|$))(?=[^'"\s]{0,256}\d)(?=[^'"\s]{0,256}[A-Za-z])[A-Za-z0-9+_=-]{16,256}(?=['"\s,;]|$)/, // *_KEY
  /[a-z](?<![Pp]ublic)(?<![Ss]ite)(?:Key|Secret|Token|Password)(?:\s*:\s*[\w&<>\[\]|.*]{1,40}?\s*(?==)|\s+[\w&<>\[\]|.*]{1,40}?\s*(?==))?['"]?\s*:?=\s*(?:\[\]byte\()?['"](?![a-z][a-z0-9]*(?:[_-][a-z0-9]*)+['\"]?(?=[\s,;)]|$)|[a-z]{2,}(?:[A-Z][a-z]{2,}[0-9]*)*(?:[A-Z][0-9]*)?['\"]?(?=[\s,;)]|$)|[A-Za-z_][\w-]*(?:\.[\w-]+)+(?=['\"\s,;)]|$))(?=[^'"\s]{0,256}\d)[^'"\s]{16,256}['"]/, // fooKey = "…" (camelCase)
  /\bdefine\(\s*['"][A-Z_]*(?:PASSWORD|SECRET|KEY|TOKEN|SALT)[A-Z_]*['"]\s*,\s*['"](?!\$)[^'"\s]{8,256}['"]/, // PHP define
  /\b(?:PASSWORD\s+'[^'\s]{6,256}'|IDENTIFIED\s+BY\s+'[^'\s]{6,256}')/i, // SQL
  /\bset\(\s*\w*(?:PASSWORD|SECRET|TOKEN|KEY)\w*\s+"(?!\$)[^"\s]{8,256}"/i, // CMake set(…_KEY "…")
];
// Tests enfocados (desactivan el resto de la suite) → FAIL; desactivados, eliminados, sin aserciones o supresiones → AVISO.
const TEST_FILE = /(^|\/)(tests?|__tests__|spec|cypress|e2e)\/|[._-](test|spec)\.[cm]?[jt]sx?$|\.(cy|e2e)\.[cm]?[jt]sx?$|(^|\/)test_[^/]*\.py$|_test\.(py|go)$|_spec\.rb$|(Tests?|IT)\.(java|kt|cs)$/;
const FIXTURE = /(^|\/)(fixtures?|__fixtures__|testdata|__snapshots__|mocks?)\//;
const TEST_FOCUS = [/(?<![.\w])(?:it|test|describe|context|suite)(?:\.\w+)*\.only\b/, /(?<![.\w])(?:fit|fdescribe)\s*\(/,
  /(?<![.\w])fit\s+['"]/, /\bfocus:\s*true\b/];
const TEST_SKIP = [/(?<![.\w])(?:it|test|describe|context|suite)(?:\.\w+)*\.(?:skip(?:If)?|fixme)\b/, /(?<![.\w])(?:xit|xtest|xdescribe)\s*\(/,
  /@pytest\.mark\.(?:skip|skipif|xfail)\b/, /@unittest\.skip/, /\bpytest\.skip\s*\(/, /\bt\.Skip(?:Now|f)?\s*\(/,
  /@Disabled\b/, /@Ignore\b/, /#\[ignore\]/];
const TEST_DECL = /(?<![.\w])(?:it|test)\s*\(|\bdef test_\w+|\bfunc Test\w+|@Test\b|#\[test\]|\[(?:Fact|Theory|Test|TestMethod)\]/;
const ASSERTION = /\b(?:expect|assert\w*|Assert\.\w+|should|verify|t\.(?:Error|Fatal|Fail)\w*|require\.\w+|raises|toBe|toEqual)\b/;
const SUPPRESS = /eslint-disable|@ts-ignore|@ts-expect-error|@ts-nocheck|#\s*type:\s*ignore|#\s*noqa|pylint:\s*disable|\bnosec\b|NOLINT|nosemgrep|@SuppressWarnings|checkov:skip|tfsec:ignore|pragma:\s*no cover|istanbul ignore|c8 ignore|coverageThreshold|fail_under|cov-fail-under|NOSONAR|nolint/;
// Cambios en cómo se ejecutan los tests o la CI, y en los ficheros que leen todos los agentes → AVISO (revisión humana).
const CI_FILE = /(^|\/)(\.github\/workflows\/|\.circleci\/)|(^|\/)(\.gitlab-ci\.yml|Jenkinsfile|azure-pipelines\.yml|bitbucket-pipelines\.yml)$/;
const TEST_CFG_FILE = /(^|\/)(jest|vitest|playwright|cypress|karma)\.config\.[cm]?[jt]s$|(^|\/)(pytest\.ini|tox\.ini|\.coveragerc|phpunit\.xml(\.dist)?)$/;
const TEST_CFG_LINE = /"test[\w:-]*"\s*:|\baddopts\b|passWithNoTests|continue-on-error|--no-verify|\b(?:test|jest|vitest|pytest|mocha|go test|cargo test)\b.*\|\|\s*true\b|^\+\s*test\s*:/;
const STEERING = ['AGENTS.md', 'docs/agent-runbook.md', 'docs/constitution.md', 'docs/sdd-conventions.md'];
const DOC_FILE = /\.(md|mdx|markdown|rst|txt|adoc)$/i;
const SENSITIVE_FILE = /(^|\/)(\.env(\.[^/]+)?|\.envrc|\.npmrc|\.pypirc|[^/]*\.tfvars|[^/]*\.(pem|p12|pfx|key|jks|keystore)|id_(rsa|dsa|ecdsa|ed25519)[^/]*|credentials[^/]*\.json|kubeconfig[^/]*)$/;
const ENV_SAMPLE = /\.(example|sample|template|dist|defaults)$/i;
const ENV_SECRET = /^\s*(?:export\s+)?\S{0,128}?(?:password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|private[_-]?key|credentials?|(?<![A-Za-z0-9])(?:pass|pw)(?![A-Za-z0-9]))\w{0,64}\s*[=:]\s*['"]?(?!\$[{(A-Z_]|[<{%'"\s/.]|$|https?:)(?!(?:\d+|true|false|yes|no|on|off)['"]?\s*$)\S/i;
// .env de desarrollo, test o CI: sus valores suelen ser locales; un hallazgo genérico en ellos es AVISO, no FAIL.
const ENV_DEV = /(^|\/)\.env\.(test|testing|development|dev|ci|e2e)$/;
// Solo los .env de ejemplo son laxos (no cualquier .template/.dist: p. ej. una plantilla de despliegue con una URL real).
const ENV_EXAMPLE = /(^|\/)\.env[^/]*\.(example|sample|template|dist|defaults)$/;
// .env: nombres que terminan en KEY o AUTH, con valor largo (APP_KEY, ENCRYPTION_KEY, SENTRY_AUTH); no los públicos.
const ENV_SECRET2 = /^\s*(?:export\s+)?[\w.-]{0,128}?(?<![Pp][Uu][Bb][Ll][Ii][Cc][_-])(?<![Pp][Uu][Bb][Ll][Ii][Ss][Hh][Aa][Bb][Ll][Ee][_-])(?:key|auth)\s*[=:]\s*['"]?(?!\$[{(A-Z_]|[<{%'"\s/.]|https?:|pk_)[^'"\s]{12,}/i;
// Documentación (los avisos son laxos en ella), salvo .txt que son configuración.
const isDoc = (f) => DOC_FILE.test(f) && !/(^|\/)(requirements[^/]*|constraints[^/]*|CMakeLists)\.txt$/i.test(f);
const LOCKFILE = /(^|\/)(package-lock\.json|npm-shrinkwrap\.json|yarn\.lock|pnpm-lock\.yaml|poetry\.lock|uv\.lock|Pipfile\.lock|Cargo\.lock|go\.sum|Gemfile\.lock|composer\.lock)$/;
const stagedText = (rel) => norm(tryGit('show', `:${rel}`)) ?? read(join(root, rel)) ?? '';
const mask = (s) => `${s.slice(0, 4)}…`;
// Fragmento de una línea para un aviso, sin mostrarla si contiene un posible secreto.
// Ficheros sensibles: nunca se muestran; literales entre comillas de 8+ caracteres, tampoco (pueden ser secretos no detectados).
const snip = (t, f = '') => (SENSITIVE_FILE.test(f) ? '(línea de un fichero sensible: no se muestra)'
  : [...SECRET_HARD, ...SECRET_STRONG, ...SECRET_SOFT, URL_CRED, ENV_SECRET].some((re) => re.test(t)) ? '(línea con un posible secreto: no se muestra)'
  : t.replace(/(['"`])[^'"`]{6,}\1/g, '$1…$1').replace(/(?=[\w!#$%&*+\-.@^~]*\d)[\w!#$%&*+\-.@^~]{6,}/g, '…').slice(0, 80).trim());
// Clave de .sdd-allowed-secrets: ligada a fichero y línea (aprobar un fixture no aprueba la misma línea en otro sitio).
const allowKey = (x) => sha256(`${x.file}\0${x.text.trim()}`);
// Ruta de una cabecera +++ de git: sin el TAB final (nombres con espacios) y sin comillas C (caracteres especiales).
function diffPath(raw) {
  let p = raw.replace(/\t$/, '');
  if (/^".*"$/.test(p)) {
    const bytes = []; const body = p.slice(1, -1);
    for (let i = 0; i < body.length; i++) {
      if (body[i] !== '\\') { bytes.push(...Buffer.from(body[i], 'utf8')); continue; }
      const o = body.slice(i + 1, i + 4);
      if (/^[0-7]{3}$/.test(o)) { bytes.push(parseInt(o, 8)); i += 3; } else { const c = body[++i]; bytes.push(...Buffer.from({ t: '\t', n: '\n' }[c] ?? c, 'utf8')); }
    }
    p = Buffer.from(bytes).toString('utf8');
  }
  return p.replace(/^b\//, '');
}
// Opciones que impiden que la configuración del repo o del usuario oculte el diff (diff externo, textconv, -diff, NUL).
// Prefijos fijos: diff.dstPrefix/mnemonicPrefix no pueden disfrazar rutas (p. ej. hacer pasar código por tests/).
// --no-renames: un fichero movido (p. ej. de tests/ a src/) se escanea entero en su ruta nueva.
const RAW = ['-U0', '--no-color', '--no-ext-diff', '--no-textconv', '--text', '--src-prefix=a/', '--dst-prefix=b/', '--no-renames'];
const sha256 = (s) => createHash('sha256').update(s, 'utf8').digest('hex');

// Diff con estado de hunk: «+++»/«---» solo son cabeceras fuera de un hunk (una línea añadida «++ x» no cambia de fichero).
function parseDiff(text) {
  const plus = []; const minus = []; let file = ''; let inHunk = false; let ln = 0;
  // Solo \n separa líneas del diff: un \r suelto dentro de una línea añadida no debe partirla (ocultaría lo que sigue).
  for (const l of (text ?? '').split('\n').map((y) => y.replace(/\r$/, '').replace(/\r/g, ' '))) {
    if (l.startsWith('diff --git ')) { inHunk = false; file = ''; continue; }
    if (!inHunk && l.startsWith('+++ ')) { file = diffPath(l.slice(4)); continue; }
    if (!inHunk && l.startsWith('--- ')) continue;
    const h = l.match(/^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@/);
    if (h) { inHunk = true; ln = Number(h[1]); continue; }
    if (!inHunk) continue;
    if (l.startsWith('+')) plus.push({ file, line: ln++, text: l.slice(1) });
    else if (l.startsWith('-')) minus.push({ file, text: l.slice(1) });
    else if (l.startsWith(' ')) ln++;
  }
  return { plus, minus };
}

// allow-hash <fichero>:<línea>: la clave que una persona añade a .sdd-allowed-secrets para aprobar un falso positivo.
// Se calcula en local: los logs de CI nunca muestran el hash (con un secreto de baja entropía sería reversible).
function allowHash() {
  const m = (args[0] ?? '').match(/^(.+):(\d+)$/);
  const txt = m ? read(join(root, m[1])) : null;
  const line = txt?.split('\n')[Number(m[2]) - 1];
  if (line === undefined) { console.error('uso: sdd-check allow-hash <fichero>:<línea> (ruta relativa a la raíz del repositorio)'); return 2; }
  console.log(`${allowKey({ file: m[1], text: line })}  ${m[1]}:${m[2]}`);
  return 0;
}

function preCommit() {
  const task = opt('--task'); const bug = opt('--bug'); const range = opt('--range');
  if (tryGit('rev-parse', '--git-dir') === null) { console.error('pre-commit requiere un repositorio git'); return 2; }
  // --range <base>..<head>: modo CI. Mismos detectores sobre la rama; los secretos, sobre todo el historial del rango.
  const src = range ? [range] : ['--cached'];
  const namesOut = tryGit('diff', '--name-only', '-z', ...src);
  if (namesOut === null) { console.error(`sdd-check: rango no válido: ${range}`); return 2; }
  const staged = splitZ(namesOut);
  const added = new Set(splitZ(git('diff', '--name-only', '--diff-filter=A', '-z', ...src)));
  const deleted = splitZ(git('diff', '--name-only', '--diff-filter=D', '-z', ...src));
  const problems = []; const warnings = [];
  if (!staged.length && !range) problems.push('no hay nada staged');
  const specOpt = opt('--spec');
  const specDirs = existsSync(join(root, 'specs')) ? readdirSync(join(root, 'specs')).filter((d) => /^\d{3}-/.test(d) && statSync(join(root, 'specs', d)).isDirectory()).sort() : [];
  const code = staged.filter((f) => !/^(specs|docs|reviews)\//.test(f) && f !== 'AGENTS.md' && f !== '.sdd-allowed-secrets' && !LOCKFILE.test(f) && !deleted.includes(f));
  if (task && !range) {
    const has = (d) => parseTasks(read(join(root, 'specs', d, 'tasks.md'))).some((x) => x.id === task);
    let cands = specOpt ? [specOpt] : specDirs.filter(has);
    if (!specOpt && cands.length > 1) {
      const st = cands.filter((d) => staged.includes(`specs/${d}/tasks.md`));
      if (st.length === 1) cands = st; else problems.push(`${task} existe en varias specs (${cands.join(', ')}): usa --spec`);
    }
    if (!cands.length || (specOpt && !has(specOpt))) problems.push(`${task} no existe en ${specOpt ?? 'ningún tasks.md'}`);
    else if (cands.length === 1) {
      const rel = `specs/${cands[0]}/tasks.md`;
      if (!staged.includes(rel)) problems.push(`${rel} no está staged: la evidencia va en el mismo commit que el código`);
      const t = parseTasks(stagedText(rel)).find((x) => x.id === task);
      if (!t?.done) problems.push(`${task} no está marcada [x] en la versión staged de ${rel}`);
      else if (t.evidencePending || t.evidenceLines === 0) problems.push(`${task} sin evidencia en la versión staged`);
      if (staged.length && staged.every((x) => x.startsWith('specs/'))) warnings.push(`commit de tarea sin cambios fuera de specs/: si ${task} no tiene código ni tests (re-sellado, reapertura, cierre N/A), usa el pre-commit genérico`);
      if (t && code.length) {
        // Trazabilidad código → tarea: cada fichero de código staged figura en «Archivos:» (ruta, nombre o carpeta «dir/»).
        const arch = t.body.find((l) => /^\s*[-*]\s+\**Archivos\**\s*:/.test(l));
        if (!arch) warnings.push(`la evidencia de ${task} no tiene «Archivos:» (Convenciones › Tareas y evidencia)`);
        else {
          const txt = arch.replace(/^[^:]*:/, ''); const tokens = txt.split(/[\s,·;()`]+/).filter(Boolean);
          const miss = code.filter((f) => !(txt.includes(f) || tokens.includes(f.split('/').pop()) || tokens.some((k) => k.endsWith('/') && f.startsWith(k))));
          if (miss.length) problems.push(`ficheros staged no citados en «Archivos:» de ${task}: ${miss.slice(0, 5).join(', ')}`);
        }
        const req = t.body.find((l) => /Tests requeridos\**\s*:/.test(l));
        if (req && !/:\s*\**\s*N\/?A\b/i.test(req) && !code.some((f) => TEST_FILE.test(f)))
          warnings.push(`código staged sin ningún fichero de test aunque «Tests requeridos» de ${task} no es N/A`);
      }
    }
  }
  if (bug && !range) {
    const found = (specOpt ? [specOpt] : specDirs).map((d) => `specs/${d}/bugs/${bug}.md`).filter((x) => staged.includes(x) || existsSync(join(root, x)));
    if (!found.length) problems.push(`${bug}.md no existe`);
    else {
      if (found.length > 1) problems.push(`${bug} existe en varias specs: la numeración BUG-NNN es global, renumera`);
      const f = found[0];
      if (!staged.includes(f)) problems.push(`${f} no está staged`);
      const txt = stagedText(f);
      if (!/Estado\**\s*:\**\s*\**\s*CERRADO/i.test(txt)) problems.push(`${bug} no está CERRADO`);
      const clase = (txt.match(/Clase:[ \t]*([^\n]*)/) ?? [])[1] ?? '';
      if (added.has(f) && (!clase.trim() || /[|<·]/.test(clase))) problems.push(`${bug} sin «Clase:» de causa raíz (un solo valor)`);
    }
  }
  for (const f of staged.filter((x) => /(^|\/)(__pycache__|node_modules|\.DS_Store|\.pytest_cache|\.venv)(\/|$)|\.pyc$/.test(x)).slice(0, 5))
    warnings.push(`fichero generado staged (¿falta en los ignorados?): ${f}`);
  for (const f of staged.filter((x) => SENSITIVE_FILE.test(x) && !ENV_SAMPLE.test(x) && !deleted.includes(x)).slice(0, 5))
    warnings.push(`fichero de entorno o de credenciales staged: ${f} (comprueba que no contiene secretos; los valores de ejemplo van en un .env.example)`);
  for (const f of deleted.filter((x) => TEST_FILE.test(x)).slice(0, 5))
    warnings.push(`test eliminado: ${f} — solo si su requisito se eliminó o se movió (cítalo en la evidencia)`);
  const { plus, minus } = parseDiff(git('diff', ...RAW, ...src));
  // Secretos: en CI, todo el historial del rango (un secreto añadido y borrado después sigue en el historial).
  // -m: también el diff de los merges (lo añadido al resolverlos); base..head: solo los commits de la rama.
  const secretLines = range ? parseDiff(git('log', '-p', '-m', ...RAW, '--format=', range.replace('...', '..'))).plus : plus;
  // En CI, la versión de la base del rango; en local, la commiteada (nunca la que el propio cambio edita).
  const allowSrc = tryGit('show', `${range ? range.split(/\.\.\.?/)[0] : 'HEAD'}:.sdd-allowed-secrets`);
  const allowed = new Set((allowSrc ?? '').split('\n').map((x) => x.trim()).filter(Boolean));
  // Política: FAIL = formato de proveedor (cualquier fichero) o credencial con estructura / .env real (en código);
  // AVISO = heurística por nombre (siempre) o hallazgo en tests, fixtures, documentación y .env de desarrollo.
  const seen = new Set(); let nWarn = 0; const more = [];
  for (const x of secretLines) {
    const where = `${x.file}:${x.line}`;
    if (seen.has(where + x.text)) continue;
    const lax = isDoc(x.file) || TEST_FILE.test(x.file) || FIXTURE.test(x.file) || ENV_DEV.test(x.file) || ENV_EXAMPLE.test(x.file);
    const hard = SECRET_HARD.map((re) => x.text.match(re)).find((m) => m && !/EXAMPLE/.test(m[0]));
    const envHit = SENSITIVE_FILE.test(x.file) && !ENV_SAMPLE.test(x.file) ? (x.text.match(ENV_SECRET) ?? x.text.match(ENV_SECRET2)) : null;
    const u = x.text.match(URL_CRED);
    const url = u && !(URL_PLACEHOLDER.test(u[2]) || u[1] === u[2]) ? u : null;
    const strong = hard ? null : SECRET_STRONG.map((re) => x.text.match(re)).find(Boolean) ?? (url && !LOCAL_HOST.test(url[3]) ? url : null) ?? (envHit && !lax ? envHit : null);
    const weak = hard || strong ? null : SECRET_SOFT.map((re) => x.text.match(re)).find(Boolean) ?? url ?? envHit;
    if (!hard && !strong && !weak) continue;
    seen.add(where + x.text);
    const marked = /sdd-allow-secret/.test(x.text);
    const blocking = hard || (strong && !lax);
    const m = (hard ?? strong ?? weak)[0];
    if (allowed.has(allowKey(x))) warnings.push(`secreto probable permitido por .sdd-allowed-secrets (${range ? 'base del rango' : 'versión commiteada'}) en ${where}`);
    else if (blocking && marked && range)
      problems.push(`secreto probable en ${where} (${mask(m)}) marcado con sdd-allow-secret: en CI solo pasa si una persona añade a .sdd-allowed-secrets su sha256 de fichero y línea (calcúlalo en local: sdd-check allow-hash ${where})`);
    else if (blocking && marked) warnings.push(`secreto probable marcado como permitido (sdd-allow-secret) en ${where}: requiere revisión humana antes de integrar`);
    else if (blocking) problems.push(`secreto probable en ${where}: ${mask(m)} (si es un falso positivo, una persona puede aprobarlo en .sdd-allowed-secrets: sdd-check allow-hash ${where})`);
    else if (marked) continue;
    else if (nWarn++ >= 10) more.push(where);
    else warnings.push(lax || !weak ? `revisa (¿secreto real o valor de prueba?) en ${where}: ${mask(m)}`
      : `posible secreto en código (patrón genérico) en ${where}: ${mask(m)} — revísalo: si es real, muévelo a configuración segura`);
  }
  if (more.length) warnings.push(`… y ${more.length} posibles secretos más (revísalos): ${more.slice(0, 40).join(', ')}${more.length > 40 ? ', …' : ''}`);
  const tests = plus.filter((x) => TEST_FILE.test(x.file) && !DOC_FILE.test(x.file));
  for (const x of tests.filter((y) => TEST_FOCUS.some((re) => re.test(y.text))).slice(0, 5))
    problems.push(`test enfocado (desactiva el resto de la suite) en ${x.file}:${x.line}: ${snip(x.text, x.file)}`);
  for (const x of tests.filter((y) => TEST_SKIP.some((re) => re.test(y.text))).slice(0, 5))
    warnings.push(`test desactivado en ${x.file}:${x.line}: ${snip(x.text, x.file)} — solo si la tarea lo justifica (motivo en la evidencia); nunca para avanzar con un fallo`);
  for (const x of plus.filter((y) => !DOC_FILE.test(y.file) && SUPPRESS.test(y.text)).slice(0, 5))
    warnings.push(`supresión de lint, tipos o cobertura en ${x.file}:${x.line}: ${snip(x.text, x.file)} — justifícala en la evidencia`);
  if (!range) for (const f of [...added].filter((y) => TEST_FILE.test(y) && !DOC_FILE.test(y)).slice(0, 20)) {
    const body = stagedText(f);
    if (TEST_DECL.test(body) && !ASSERTION.test(body)) warnings.push(`${f} declara tests sin ninguna aserción (¿pueden fallar?)`);
  }
  const cfg = [...new Set([...staged.filter((f) => CI_FILE.test(f) || TEST_CFG_FILE.test(f)),
    ...plus.filter((y) => !DOC_FILE.test(y.file) && TEST_CFG_LINE.test(y.text)).map((y) => y.file)])];
  for (const f of cfg.slice(0, 5)) warnings.push(`cambia cómo se ejecutan los tests o la CI en ${f}: requiere revisión humana`);
  const touched = new Set([...plus, ...minus].map((x) => x.file));
  if ([...plus, ...minus].some((x) => x.file === 'AGENTS.md' && /^(\||Excepciones aceptadas)/.test(x.text)))
    warnings.push('cambia la tabla de comandos de AGENTS.md o sus excepciones (lo que ejecutan todos los gates): requiere revisión humana');
  if (staged.includes('.sdd-allowed-secrets')) warnings.push('cambia .sdd-allowed-secrets: solo lo editan personas; en CI cuenta la versión de la base del rango, no la de la rama');
  for (const f of STEERING.filter((y) => touched.has(y)))
    warnings.push(`cambia ${f} (instrucciones que leen los agentes): revisa que no introduce reglas ajenas al proyecto`);
  console.log(`MODO: ${range ? 'rango ' + range : task ? 'tarea ' + task : bug ? 'bug ' + bug : 'genérico (secretos y tests)'}`);
  console.log(`${range ? 'CAMBIADOS' : 'STAGED'} (${staged.length}): ${staged.join(', ')}`);
  for (const p of problems.slice(0, 50)) console.log(`PROBLEMA: ${p}`);
  if (problems.length > 50) console.log(`PROBLEMA: … y ${problems.length - 50} problemas más`);
  for (const w of warnings) console.log(`AVISO: ${w}`);
  console.log(problems.length ? 'PRE-COMMIT: FAIL' : 'PRE-COMMIT: OK — revisa que cada fichero pertenece al trabajo');
  return problems.length ? 1 : 0;
}

try {
  if (cmd === 'status') process.exit(status());
  if (cmd === 'pre-commit') process.exit(preCommit());
  if (cmd === 'allow-hash') process.exit(allowHash());
  console.error(`comando desconocido: ${cmd}`); process.exit(2);
} catch (e) {
  console.error(`sdd-check: ${e.message}`); process.exit(2);
}
