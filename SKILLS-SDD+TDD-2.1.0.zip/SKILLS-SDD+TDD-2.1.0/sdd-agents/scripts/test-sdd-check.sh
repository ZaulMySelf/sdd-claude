#!/usr/bin/env bash
# Tests de sdd-check: comportamiento esperado + paridad entre sdd-check.mjs y sdd_check.py.
# Uso: ./test-sdd-check.sh   (requiere git y python3; prueba también node si existe)
# Portable: sin `sed -i` ni extensiones GNU; rutas con espacios admitidas.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PY="$(command -v python3 || command -v python || command -v py)"; [ -n "$PY" ] || { echo "requiere Python 3"; exit 2; }
python3() { "$PY" "$@"; }
command -v git >/dev/null || { echo "requiere git"; exit 2; }
IMPLS=(py); command -v node >/dev/null && IMPLS=(node py)
run_impl() { local i="$1"; shift; if [ "$i" = node ]; then node "$HERE/sdd-check.mjs" "$@"; else python3 "$HERE/sdd_check.py" "$@"; fi; }
PASS=0; FAIL=0
bad() { FAIL=$((FAIL+1)); echo "  ✗ $*"; }

# rep FICHERO VIEJO NUEVO  — reemplazo literal (falla si VIEJO no aparece)
rep() { python3 - "$1" "$2" "$3" <<'PY'
import sys
p, a, b = sys.argv[1], sys.argv[2].encode().decode('unicode_escape').encode('latin-1').decode('utf-8'), sys.argv[3].encode().decode('unicode_escape').encode('latin-1').decode('utf-8')
s = open(p, encoding='utf-8', newline='').read()
if a not in s: sys.exit('rep: no encontrado en %s: %r' % (p, a))
open(p, 'w', encoding='utf-8', newline='').write(s.replace(a, b))
PY
}

# expect <nombre> <exit> <patrón obligatorio> <patrón prohibido|""> -- <args...>
expect() {
  local name="$1" rc_exp="$2" must="$3" mustnot="$4"; shift 5
  local outs=() out rc
  for impl in "${IMPLS[@]}"; do
    out="$(run_impl "$impl" "$@" 2>&1)"; rc=$?
    outs+=("$out")
    [ "$rc" = "$rc_exp" ] || bad "$name [$impl] exit=$rc (esperado $rc_exp)"$'\n'"$out"
    printf '%s\n' "$out" | grep -qE -- "$must" || bad "$name [$impl] falta /$must/"$'\n'"$out"
    if [ -n "$mustnot" ] && printf '%s\n' "$out" | grep -qE -- "$mustnot"; then bad "$name [$impl] sobra /$mustnot/"; fi
  done
  if [ ${#outs[@]} -eq 2 ] && [ "${outs[0]}" != "${outs[1]}" ]; then
    bad "$name: salida distinta entre implementaciones"; diff <(printf '%s\n' "${outs[0]}") <(printf '%s\n' "${outs[1]}") | head -20
  else PASS=$((PASS+1)); fi
}

NORM='import json,sys
def n(o):
  if isinstance(o,dict): return {k:n(v) for k,v in sorted(o.items()) if v is not None}
  if isinstance(o,list): return [n(x) for x in o]
  return o
print(json.dumps(n(json.load(sys.stdin)),sort_keys=True,ensure_ascii=False))'
json_parity() {
  [ ${#IMPLS[@]} -eq 2 ] || return 0
  local a b; a="$(run_impl node --json 2>/dev/null | python3 -c "$NORM")"; b="$(run_impl py --json 2>/dev/null | python3 -c "$NORM")"
  if [ -n "$a" ] && [ "$a" = "$b" ]; then PASS=$((PASS+1)); else bad "json distinto o vacío ($1)"; fi
}

hdr_spec() { # $1 dir $2 estado $3 versión $4 línea extra
  printf '| Campo | Valor |\n|---|---|\n| Spec-ID | %s |\n| Versión | %s |\n| Estado | %s |\n| Aprobación | %s |\n| Tamaño | M |\n| Interfaz | NO |\n| Origen | NUEVA |\n%s\n\n- RF-001: x\n\n## Registro de cambios\n| 1 | — | — | [NECESITA ACLARACIÓN] y (defecto) históricos |\n' \
    "$(basename "$1")" "${3:-2}" "$2" "$( [ "$2" = APROBADA ] && echo 'APROBADA (2026-01-01, por el usuario)' || echo PENDIENTE)" "${4:-}" > "$1/spec.md"
}
derived() { # $1 fichero $2 specV $3 planV $4 cuerpo
  printf '| Campo | Valor |\n|---|---|\n| Spec-Version | %s |\n%s\n\n%s\n' "$2" "$( [ -n "$3" ] && echo "| Plan-Version | $3 |")" "$4" > "$1"
}
ready_spec() { # $1 dir $2 versión  — spec aprobada con clarify y plan sin migración
  mkdir -p "$1"; hdr_spec "$1" APROBADA "$2"
  derived "$1/clarify.md" "$2" "" "SPEC CLARIFICADA: SÍ"
  printf '| Campo | Valor |\n|---|---|\n| Spec-Version | %s |\n| Plan-Version | 1 |\n| Migración requerida | NO |\n| Aprobación | NO REQUERIDA |\n' "$2" > "$1/plan.md"
}

T="$(mktemp -d)/repo con espacios"; mkdir -p "$T"; trap 'rm -rf "$(dirname "$T")"' EXIT
cd "$T" && git init -q && git config user.email t@t && git config user.name t && git config core.autocrlf false

echo "· proyecto vacío"
expect vacio 0 "PROYECTO · SIGUIENTE PASO: sdd-init" "" --

mkdir -p docs; echo "# brief" > docs/brief.md
printf '# Constitución\n\nEstado: APROBADA (2024-01-01)\n' > docs/constitution.md
expect constitucion_formato_antiguo 0 "SIGUIENTE PASO: sdd-agents" "sdd-constitution" --
printf '# Constitución\n\n> Estado: APROBADA (2026-01-01, por el usuario)\n' > docs/constitution.md
echo "# AGENTS" > AGENTS.md; echo "# runbook" > docs/agent-runbook.md
expect agents_sin_convenciones 0 "PROYECTO · SIGUIENTE PASO: sdd-agents · MOTIVO: AGENTS.md sin las Convenciones SDD actuales" "" --
echo "<!-- sdd-conventions: 2 -->" >> AGENTS.md
expect agents_convenciones_antiguas 0 "SIGUIENTE PASO: sdd-agents · MOTIVO: AGENTS.md sin las Convenciones SDD actuales \(marcador sdd-conventions: 3\)" "" --
echo "# AGENTS" > AGENTS.md; echo "<!-- sdd-conventions: 3 -->" >> AGENTS.md
expect sin_convenciones 0 "PROYECTO · SIGUIENTE PASO: sdd-agents · MOTIVO: falta docs/sdd-conventions.md" "" --
printf '# Convenciones SDD\n<!-- sdd-conventions: 2 -->\n' > docs/sdd-conventions.md
expect convenciones_antiguas 0 "PROYECTO · SIGUIENTE PASO: sdd-agents · MOTIVO: falta docs/sdd-conventions.md o es de otra versión" "" --
printf '# Convenciones SDD\n<!-- sdd-conventions: 3 -->\n' > docs/sdd-conventions.md
expect version 0 "^sdd-check 2\.1\.0$" "" -- --version

echo "· sin specs → sdd-spec"
expect sin_specs 0 "PROYECTO · SIGUIENTE PASO: sdd-spec · MOTIVO: no hay specs" "" --
mkdir -p reviews; printf '| ID | Fecha | Severidad | Tipo | Hallazgo | Spec | Ruta | Estado |\n|---|---|---|---|---|---|---|---|\n| R-001 | x | ALTO | BUG | inyección en lib | — | sdd-retro | ABIERTO |\n' > reviews/backlog.md
expect global_sin_specs 0 "PROYECTO · SIGUIENTE PASO: sdd-retro · MOTIVO: R-001 ALTO ABIERTO \(global\)" "sdd-spec" --
rm -rf reviews
mkdir -p specs/001-a/bugs

echo "· borrador; marcadores históricos en el registro no cuentan"
hdr_spec specs/001-a BORRADOR
expect borrador 0 "SIGUIENTE PASO: sdd-clarify" "PROYECTO ·" --

echo "· spec sin Versión → PROBLEMA; derivado sin Spec-Version → no vigente"
printf '| Campo | Valor |\n|---|---|\n| Estado | APROBADA |\n' > specs/001-a/spec.md
expect sin_version 1 "PROBLEMA: spec.md sin «Versión»" "" --
expect nulos_iguales 1 "SPEC 001-a v\? · APROBADA · Tamaño \? · plan v\?" "None|null|undefined" --
hdr_spec specs/001-a APROBADA
printf 'SPEC CLARIFICADA: SÍ\n' > specs/001-a/clarify.md
expect derivado_sin_version 0 "clarify=SIN-VERSIÓN" "spec completada" --
derived specs/001-a/clarify.md 2 "" "SPEC CLARIFICADA: SÍ"

echo "· plan pendiente → migración → INCOMPLETA → plan"
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 2 |\n| Plan-Version | 3 |\n| Migración requerida | SÍ |\n| Aprobación | PENDIENTE |\n' > specs/001-a/plan.md
expect plan_pendiente 0 "SIGUIENTE PASO: sdd-plan" "" --
rep specs/001-a/plan.md "| Aprobación | PENDIENTE |" "| Aprobación | APROBADO (2026-01-01, por el usuario) |"
expect migracion 0 "SIGUIENTE PASO: sdd-migration" "" --
derived specs/001-a/migration-review.md 2 3 "Siguiente paso: sdd-plan

MIGRACIÓN: INCOMPLETA"
expect migracion_incompleta 0 "SIGUIENTE PASO: sdd-plan · MOTIVO: MIGRACIÓN: INCOMPLETA" "" --
derived specs/001-a/migration-review.md 2 3 "MIGRACIÓN: SUFICIENTE"

echo "· tasks caducado; FAIL con destino declarado"
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 2 |\n| Plan-Version | 2 |\n\n- [ ] T-001 — a\n  - Evidencia (T-001): pendiente\n\nTRAZABILIDAD: PASS\n' > specs/001-a/tasks.md
expect tasks_caducado 0 "SIGUIENTE PASO: sdd-tasks" "" --
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 2 |\n| Plan-Version | 3 |\n\nSiguiente paso: sdd-change\n\nTRAZABILIDAD: FAIL\n' > specs/001-a/tasks.md
expect fail_change 0 "SIGUIENTE PASO: sdd-change · MOTIVO: TRAZABILIDAD: FAIL" "" --
rep specs/001-a/tasks.md "sdd-change" "sdd-tasks"
expect fail_tasks_a_plan 0 "SIGUIENTE PASO: sdd-plan · MOTIVO: TRAZABILIDAD: FAIL" "" --

echo "· tareas: usuario, dependencias, evidencia en línea, marcador antiguo, contador"
cat > specs/001-a/tasks.md <<'EOF'
| Campo | Valor |
|---|---|
| Spec-Version | 2 |
| Plan-Version | 3 |

## Tareas
- [x] T-001 — a
  - Depende de: —
  - Evidencia (T-001):
    - GREEN: x → 1/1; queda pendiente revisar el log
    - Verificación completa: todo → exit 0
- [x] T-002 — b
  - Depende de: T-001
  - Evidencia (T-002): RED x → 1 · GREEN x → 2/2
- [ ] T-003 — smoke real
  - Depende de: T-001
  - Requiere usuario: SÍ
  - Evidencia (T-003): pendiente
- [ ] T-004 — c
  - Depende de: T-002
  - Evidencia (T-004): pendiente
- [ ] T-005 — d
  - Depende de: T-004
  - Evidencia: (la añade sdd-implement)

TRAZABILIDAD: PASS
EOF
expect salta_usuario 0 "SIGUIENTE PASO: sdd-implement T-004" "PROBLEMA" --
expect espera_usuario 0 "esperan al usuario: T-003" "" --
expect contador_todo 0 "verificación completa: 1" "" --
expect marcador_antiguo 0 "T-005: marcador de evidencia no único" "" --
json_parity tareas

echo "· CRLF: misma lectura que LF"
python3 -c "import sys;p=sys.argv[1];s=open(p,encoding='utf-8').read();open(p,'w',encoding='utf-8',newline='').write(s.replace('\n','\r\n'))" specs/001-a/tasks.md
expect crlf 0 "SIGUIENTE PASO: sdd-implement T-004" "PROBLEMA" --
python3 -c "import sys;p=sys.argv[1];s=open(p,encoding='utf-8',newline='').read();open(p,'w',encoding='utf-8',newline='').write(s.replace('\r\n','\n'))" specs/001-a/tasks.md

echo "· reapertura: motivo en subviñeta (no rompe el marcador)"
rep specs/001-a/tasks.md "- [ ] T-004 — c" "- [ ] T-004 — c\n  - Reabierta: validate NO por nivel de test"
expect reabierta 0 "SIGUIENTE PASO: sdd-implement T-004" "PROBLEMA" --

echo "· tarea bloqueada: se enruta a la skill indicada"
rep specs/001-a/tasks.md "- [ ] T-004 — c" "- [ ] T-004 — c\n  - Bloqueada: nivel INTEG inalcanzable sin BD → sdd-plan"
expect bloqueada 0 "SIGUIENTE PASO: sdd-plan · MOTIVO: T-004 bloqueada: nivel INTEG inalcanzable sin BD" "" --
rep specs/001-a/tasks.md "  - Bloqueada: nivel INTEG inalcanzable sin BD → sdd-plan" "  - Bloqueada: falta la herramienta → sdd-plan (D-NNN)"
expect bloqueada_texto_tras_skill 0 "SIGUIENTE PASO: sdd-plan · MOTIVO: T-004 bloqueada" "" --
rep specs/001-a/tasks.md "  - Bloqueada: falta la herramienta → sdd-plan (D-NNN)" "  - Bloqueada: espera a 009-otra"
expect bloqueada_espera 1 "PROBLEMA: T-004 espera a 009-otra, que no existe" "" --
rep specs/001-a/tasks.md "  - Bloqueada: espera a 009-otra" "  - Bloqueada: no sé qué pasa"
expect bloqueada_ilegible 1 "PROBLEMA: T-004: línea Bloqueada sin destino legible" "" --
rep specs/001-a/tasks.md "  - Bloqueada: no sé qué pasa" "  - Bloqueada: fallo compartido (suite en rojo) → sdd-bug"
expect fallo_compartido_prioritario 0 "SIGUIENTE PASO: sdd-bug · MOTIVO: T-004 bloqueada: fallo compartido" "" --
rep specs/001-a/tasks.md "  - Bloqueada: fallo compartido (suite en rojo) → sdd-bug" "  - Bloqueada: nivel INTEG inalcanzable sin BD → sdd-plan"
rep specs/001-a/tasks.md "\n  - Bloqueada: nivel INTEG inalcanzable sin BD → sdd-plan" ""

echo "· cierre N/A aceptado como evidencia"
cp specs/001-a/tasks.md "$T/../na.bak"
printf -- '- [x] T-007 — real\n  - Evidencia (T-007): N/A — nivel REAL reducido aceptado en plan v3\n' >> specs/001-a/tasks.md
expect cierre_na 0 "SIGUIENTE PASO: sdd-implement T-004" "PROBLEMA" --
cp "$T/../na.bak" specs/001-a/tasks.md

echo "· solo quedan tareas de usuario"
rep specs/001-a/tasks.md "- [ ] T-004" "- [x] T-004"
rep specs/001-a/tasks.md "  - Evidencia (T-004): pendiente" "  - Evidencia (T-004):\n    - GREEN: y → 1/1"
rep specs/001-a/tasks.md "- [ ] T-005" "- [x] T-005"
rep specs/001-a/tasks.md "  - Evidencia: (la añade sdd-implement)" "  - Evidencia (T-005):\n    - GREEN: z → 1/1"
expect solo_usuario 0 "T-003 · MOTIVO: 1 tareas pendientes — REQUIERE USUARIO" "" --
mv docs/sdd-conventions.md "$T/../conv.bak"
expect proyecto_primero 0 "SIGUIENTE PASO: — · MOTIVO: antes, el paso del proyecto \(sdd-agents\)" "SIGUIENTE PASO: sdd-implement" --
mv "$T/../conv.bak" docs/sdd-conventions.md

echo "· problemas: [x] sin evidencia, duplicado"
cp specs/001-a/tasks.md "$T/../t.bak"
printf -- '- [x] T-006 — e\n  - Evidencia (T-006): pendiente\n- [ ] T-001 — dup\n  - Evidencia (T-001): pendiente\n' >> specs/001-a/tasks.md
expect sin_evidencia 1 "PROBLEMA: T-006 marcada \[x\] sin evidencia" "" --
expect duplicado 1 "PROBLEMA: T-001 duplicada" "" --
expect resellado 1 "SIGUIENTE PASO: sdd-implement T-006 · MOTIVO: .*re-sellado" "" --
cp "$T/../t.bak" specs/001-a/tasks.md

echo "· todo hecho → validate → release → completada"
git add -A >/dev/null; git commit -qm pre-validate
rep specs/001-a/tasks.md "- [ ] T-003" "- [x] T-003"
rep specs/001-a/tasks.md "  - Evidencia (T-003): pendiente" "  - Evidencia (T-003):\n    - REAL: ok"
git add -A >/dev/null; git commit -qm tareas
expect validate 0 "SIGUIENTE PASO: sdd-validate" "" --
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ"
expect release 0 "SIGUIENTE PASO: sdd-release" "" --
derived specs/001-a/release.md 2 3 "RELEASE: READY"
expect completada 0 "SIGUIENTE PASO: — · MOTIVO: spec completada" "" --
echo x > specs/001-a/notas.md; for f in zeta alfa Beta 10-x ñandu; do echo x > "specs/001-a/$f.md"; done
expect huerfanos_ordenados 0 "artefacto no reconocido por el flujo: notas.md" "" --
rm -f specs/001-a/notas.md specs/001-a/zeta.md specs/001-a/alfa.md specs/001-a/Beta.md specs/001-a/10-x.md specs/001-a/ñandu.md

echo "· veredictos negativos vigentes: sin bucles"
git add -A >/dev/null; git commit -qm base
derived specs/001-a/validation.md 2 3 "Siguiente paso: sdd-implement T-002

SPEC CUMPLIDA: NO"
expect no_declarado 0 "SIGUIENTE PASO: sdd-implement T-002 · MOTIVO: SPEC CUMPLIDA: NO: siguiente paso declarado" "" --
echo "y = 2" > mutado.js
expect no_con_arbol_sucio 0 "SIGUIENTE PASO: — · MOTIVO: requiere acción: código o tareas sin commitear \(mutado.js\)" "" --
rm -f mutado.js
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: NO"
expect no_sin_paso 0 "SIGUIENTE PASO: — · MOTIVO: SPEC CUMPLIDA: NO: requiere acción" "" --
git add -A >/dev/null; git commit -qm v; SHA=$(git rev-parse --short HEAD)
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 2 |\n| Plan-Version | 3 |\n| Commit | %s |\n\nSPEC CUMPLIDA: NO\n' "$SHA" > specs/001-a/validation.md
git add -A >/dev/null; git commit -qm v2
expect no_sin_trabajo 0 "requiere acción" "" --
echo "sin commitear" > docs/nota.md; echo "# AGENTS mod" >> AGENTS.md
expect no_sin_commitear_no_cuenta 0 "requiere acción" "sdd-validate ·" --
git add docs >/dev/null; git commit -qm doc; mkdir -p reviews; echo "- revisión" > reviews/backlog.md; git add reviews; git commit -qm rev
expect no_docs_reviews_no_cuentan 0 "requiere acción" "sdd-validate ·" --
rm -f reviews/backlog.md; git add -A >/dev/null; git commit -qm agents
expect no_agents_no_cuenta 0 "requiere acción" "sdd-validate ·" --
echo "codigo = 0" > codigo2.py; git add -A >/dev/null; git commit -qm "feat(009-otra): T-001 ajena"
expect no_otra_spec_no_cuenta 0 "requiere acción" "sdd-validate ·" --
echo "dep = 2" > deps.txt; git add -A >/dev/null; git commit -qm "refactor: actualiza dependencia vulnerable"
expect no_refactor_cuenta 0 "SIGUIENTE PASO: sdd-validate · MOTIVO: SPEC CUMPLIDA: NO y hay trabajo commiteado posterior" "" --
echo "codigo = 1" > codigo2.py; git add -A >/dev/null; git commit -qm "fix(001-a): BUG-001 algo"
expect no_trabajo_en_codigo 0 "SIGUIENTE PASO: sdd-validate · MOTIVO: SPEC CUMPLIDA: NO y hay trabajo commiteado posterior" "" --
mkdir -p sub2; pushd sub2 >/dev/null; expect no_trabajo_desde_subdir 0 "SIGUIENTE PASO: sdd-validate · MOTIVO: SPEC CUMPLIDA: NO y hay trabajo commiteado posterior" "" --; popd >/dev/null; rmdir sub2
SHA2=$(git rev-parse --short HEAD)
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 2 |\n| Plan-Version | 3 |\n| Commit | %s |\n\nSiguiente paso: sdd-tasks\n\nSPEC CUMPLIDA: NO\n' "$SHA2" > specs/001-a/validation.md
git add -A >/dev/null; git commit -qm v3
expect no_declara_tasks 0 "SIGUIENTE PASO: sdd-tasks · MOTIVO: SPEC CUMPLIDA: NO: siguiente paso declarado" "" --
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ"
derived specs/001-a/release.md 2 3 "Siguiente paso: sdd-validate

RELEASE: BLOCKED"; git add -A >/dev/null; git commit -qm blocked
expect blocked_validate_satisfecho 0 "SIGUIENTE PASO: — · MOTIVO: RELEASE: BLOCKED: requiere acción" "sdd-validate ·" --
SHA=$(git rev-parse --short HEAD)
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 2 |\n| Plan-Version | 3 |\n| Commit | %s |\n\nRELEASE: BLOCKED\n' "$SHA" > specs/001-a/release.md
git add -A >/dev/null; git commit -qm r2
expect blocked_sin_trabajo_propio_commit 0 "RELEASE: BLOCKED: requiere acción" "sdd-release ·" --
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ (re-validada)"; git add -A >/dev/null; git commit -qm reval
expect blocked_repite_tras_validate 0 "SIGUIENTE PASO: sdd-release · MOTIVO: RELEASE: BLOCKED y hay trabajo commiteado posterior" "" --
derived specs/001-a/release.md 2 3 "RELEASE: READY"; git add -A >/dev/null; git commit -qm ok

echo "· trabajo o bug posteriores a validación y release"
echo "x = 1" > nuevo.py; git add -A >/dev/null; git commit -qm codigo
expect completada_no_reactiva 0 "spec completada" "" --
derived specs/001-a/release.md 2 3 "$(printf 'Siguiente paso: sdd-validate\n\nRELEASE: BLOCKED')"; git add -A >/dev/null; git commit -qm rb
echo "x = 2" > nuevo.py; git add -A >/dev/null; git commit -qm "feat(001-a): T-099 otra"
expect trabajo_tras_validacion 0 "SIGUIENTE PASO: sdd-validate · MOTIVO: trabajo commiteado posterior a la validación" "" --
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ (v2)"; derived specs/001-a/release.md 2 3 "RELEASE: READY"; git add -A >/dev/null; git commit -qm vr
printf '# BUG-009\n- Clase: OTRO\n- Estado: CERRADO\n' > specs/001-a/bugs/BUG-009.md; git add -A >/dev/null; git commit -qm bug9
expect bug_tras_release_valida 0 "SIGUIENTE PASO: sdd-validate · MOTIVO: bug corregido después de la validación" "" --
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ (v3)"; git add -A >/dev/null; git commit -qm v4
expect bug_tras_release_release 0 "SIGUIENTE PASO: sdd-release · MOTIVO: bug corregido después del release" "" --
derived specs/001-a/release.md 2 3 "RELEASE: READY (v2)"; git add -A >/dev/null; git commit -qm r5
expect bug_ciclo_cerrado 0 "spec completada" "" --
rm -f nuevo.py specs/001-a/bugs/BUG-009.md; git add -A >/dev/null; git commit -qm limpia; derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ"; derived specs/001-a/release.md 2 3 "RELEASE: READY"; git add -A >/dev/null; git commit -qm vr2

echo "· Plan-Version ausente, spec inexistente, ficheros ocultos"
cp specs/001-a/validation.md "$T/../v.bak"; printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 2 |\n\nSPEC CUMPLIDA: SÍ\n' > specs/001-a/validation.md
expect sin_plan_version 0 "validation=SIN-VERSIÓN" "" --
cp "$T/../v.bak" specs/001-a/validation.md
expect spec_inexistente 2 "la spec 999-x no existe" "" -- --spec 999-x
touch specs/001-a/.gitkeep specs/001-a/.DS_Store
expect ocultos_ignorados 0 "SPEC 001-a" "no reconocido.*\\.(gitkeep|DS_Store)" --
rm -f specs/001-a/.gitkeep specs/001-a/.DS_Store

echo "· tras READY: trabajo con prefijo de la spec reabre ciclo; otra spec no"
echo "y = 1" > otro.py; git add -A >/dev/null; git commit -qm "feat(009-otra): T-001 algo"
expect otra_spec_no_reabre 0 "spec completada" "" --
echo "y = 2" > otro.py; git add -A >/dev/null; git commit -qm "refactor(001-a): limpia"
expect prefijo_reabre 0 "SIGUIENTE PASO: sdd-validate · MOTIVO: trabajo commiteado posterior a la validación" "" --
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ (rv)"; git add -A >/dev/null; git commit -qm rv
expect validacion_tras_release 0 "SIGUIENTE PASO: sdd-release · MOTIVO: validación posterior al release" "" --
derived specs/001-a/release.md 2 3 "RELEASE: READY (rr)"; git add -A >/dev/null; git commit -qm rr
expect ciclo_cerrado_de_nuevo 0 "spec completada" "" --
rm -f otro.py; git add -A >/dev/null; git commit -qm "chore: limpia"
cp specs/001-a/spec.md "$T/../s.bak"; rep specs/001-a/spec.md "| Estado | APROBADA |" "| Estado | APROBADA (2026-01-01) |"
expect estado_con_fecha 0 "spec completada" "sdd-clarify" --
cp "$T/../s.bak" specs/001-a/spec.md

echo "· release que archiva tareas no reabre el ciclo"
printf -- '# Tareas archivadas\n- [x] T-050 — a\n  - Evidencia (T-050): GREEN → 1/1\n' > specs/001-a/tasks-archive.md
derived specs/001-a/release.md 2 3 "RELEASE: READY (archiva)"; git add -A >/dev/null; git commit -qm "docs(001-a): release"
expect release_con_archivado 0 "spec completada" "sdd-validate" --
rm -f specs/001-a/tasks-archive.md; git add -A >/dev/null; git commit -qm "docs(001-a): limpia archivo"
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ"; derived specs/001-a/release.md 2 3 "RELEASE: READY"; git add -A >/dev/null; git commit -qm vr3

echo "· commit de re-sellado posterior a la validación no reabre"
derived specs/001-a/clarify.md 2 "" "Re-sellado v2: sin cambios
SPEC CLARIFICADA: SÍ"; git add -A >/dev/null; git commit -qm "docs(001-a): clarify re-sellado"
expect resellado_no_reabre 0 "spec completada" "sdd-validate" --

echo "· formatos tolerantes: veredicto «Sí», tareas y evidencia en negrita"
cp specs/001-a/validation.md "$T/../fv.bak"; derived specs/001-a/validation.md 2 3 "**SPEC CUMPLIDA**: Sí"
expect veredicto_si_minuscula 0 "validation=SÍ" "" -- --spec 001-a
cp "$T/../fv.bak" specs/001-a/validation.md
mkdir -p specs/012-fmt; hdr_spec specs/012-fmt APROBADA 1; derived specs/012-fmt/clarify.md 1 "" "SPEC CLARIFICADA: SÍ"
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n| Migración requerida | NO |\n| Aprobación | NO REQUERIDA |\n' > specs/012-fmt/plan.md
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n\n- [x] **T-001** — a\n  - **Evidencia (T-001):**\n    - GREEN: x → 1/1\n* [ ] T-002 — b\n  - **Requiere usuario:** SÍ\n  - Evidencia (T-002): pendiente.\n- [ ] T-003 — c\n  - Evidencia (T-003): pendiente\n-[ ]T-004 rota\n\nTRAZABILIDAD: PASS\n' > specs/012-fmt/tasks.md
expect tareas_formato_variante 1 "tareas 1/3.*siguiente T-003" "" -- --spec 012-fmt
expect linea_tarea_ilegible 1 "PROBLEMA: tasks.md:14: línea de tarea ilegible" "" -- --spec 012-fmt
rm -rf specs/012-fmt

echo "· espera a otra spec: la esperada se avanza y, al completarse, la espera se resuelve"
mkdir -p specs/013-base specs/014-usa; ready_spec specs/013-base 1
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n\n- [x] T-001 — a\n  - Evidencia (T-001):\n    - GREEN: x → 1/1\n\nTRAZABILIDAD: PASS\n' > specs/013-base/tasks.md
ready_spec specs/014-usa 1
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n\n- [x] T-001 — a\n  - Evidencia (T-001):\n    - GREEN: x → 1/1\n- [ ] T-002 — b\n  - Bloqueada: espera a 013-base\n  - Evidencia (T-002): pendiente\n\nTRAZABILIDAD: PASS\n' > specs/014-usa/tasks.md
git add -A >/dev/null; git commit -qm "docs: specs 013 y 014"
expect espera_avanza_esperada 0 "SPEC A AVANZAR: 013-base" "" --
derived specs/013-base/validation.md 1 1 "SPEC CUMPLIDA: SÍ"; derived specs/013-base/release.md 1 1 "RELEASE: READY"; git add -A >/dev/null; git commit -qm "docs(013-base): release"
expect espera_resuelta 0 "SIGUIENTE PASO: sdd-implement T-002" "" -- --spec 014-usa
expect espera_resuelta_aviso 0 "ya está completada; quita la línea" "" -- --spec 014-usa
rm -rf specs/013-base specs/014-usa; git add -A >/dev/null; git commit -qm limpia-esp

echo "· ciclo entre Depende de y espera a"
mkdir -p specs/017-x specs/018-y; ready_spec specs/017-x 1; ready_spec specs/018-y 1
rep specs/018-y/spec.md "| Origen | NUEVA |" "| Origen | NUEVA |\n| Depende de | 017-x |"
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n\n- [x] T-001 — a\n  - Evidencia (T-001):\n    - GREEN: x → 1/1\n- [ ] T-002 — b\n  - Bloqueada: espera a 018-y\n  - Evidencia (T-002): pendiente\n\nTRAZABILIDAD: PASS\n' > specs/017-x/tasks.md
expect ciclo_dependencias 1 "PROBLEMA: ciclo de dependencias entre" "" --
rm -rf specs/017-x specs/018-y

echo "· fallo compartido bloquea antes que tareas listas; refactor resuelve un NO; carpeta sin NNN"

mkdir -p specs/auth
expect carpeta_sin_nnn 0 "AVISO: specs/auth no sigue el formato NNN-slug" "" --
for impl in "${IMPLS[@]}"; do if run_impl "$impl" --json | python3 -c "import json,sys; json.load(sys.stdin)" >/dev/null 2>&1; then PASS=$((PASS+1)); else bad "json_valido_con_aviso [$impl]: JSON inválido"; fi; done
rmdir specs/auth

echo "· fila Seguridad sin comando con manifiesto de dependencias"
cp AGENTS.md "$T/../ag.bak"; printf '| Seguridad (obligatoria) | no disponible: sin dependencias | runtime | x |\n' >> AGENTS.md; echo "requests==2.0" > requirements.txt
expect seguridad_sin_comando 0 "AVISO: la fila Seguridad de AGENTS.md no tiene comando real" "" --
cp "$T/../ag.bak" AGENTS.md; rm -f requirements.txt
printf '| Seguridad (obligatoria) | pendiente | runtime | x |\n' >> AGENTS.md; mkdir -p packages/web; echo '{}' > packages/web/package.json; git add packages >/dev/null
expect seguridad_monorepo 0 "AVISO: la fila Seguridad.*packages/web/package.json" "" --
git rm -rq --cached packages; rm -rf packages; cp "$T/../ag.bak" AGENTS.md

echo "· Depende de: --spec no propone implementar mientras la dependencia no esté completada"
mkdir -p specs/015-dep; ready_spec specs/015-dep 1; rep specs/015-dep/spec.md "| Origen | NUEVA |" "| Origen | NUEVA |\n| Depende de | 016-pend |"
mkdir -p specs/016-pend; hdr_spec specs/016-pend BORRADOR 1
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n\n- [ ] T-001 — a\n  - Evidencia (T-001): pendiente\n\nTRAZABILIDAD: PASS\n' > specs/015-dep/tasks.md
expect depende_no_implementa 0 "MOTIVO: Depende de 016-pend, aún no completada" "" -- --spec 015-dep
rm -rf specs/015-dep specs/016-pend

echo "· «reseller» no es un re-sellado; artefacto heredado sin veredicto → su skill"
echo "r = 1" > reseller.py; git add -A >/dev/null; git commit -qm "feat(001-a): T-098 reseller panel"
expect reseller_cuenta 0 "SIGUIENTE PASO: sdd-validate · MOTIVO: trabajo commiteado posterior" "" -- --spec 001-a
rm -f reseller.py; git add -A >/dev/null; git commit -qm "chore: quita"
cp specs/001-a/validation.md "$T/../vh.bak"; derived specs/001-a/validation.md 2 3 "(sin veredicto)"
expect validation_sin_veredicto 0 "SIGUIENTE PASO: sdd-validate · MOTIVO: validation.md sin veredicto" "" -- --spec 001-a
echo "x = 1" > sucio.py
expect arbol_sucio_validate 0 "SIGUIENTE PASO: — · MOTIVO: requiere acción: código o tareas sin commitear \(sucio.py\)" "" -- --spec 001-a
rm -f sucio.py
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ (r9)"; git add -A >/dev/null; git commit -qm v9; derived specs/001-a/release.md 2 3 "RELEASE: READY (r9)"; git add -A >/dev/null; git commit -qm r9

echo "· adopción: spec heredada con release en modo adopción"
mkdir -p specs/011-heredada
printf '| Campo | Valor |\n|---|---|\n| Spec-ID | 011-heredada |\n| Versión | 2 |\n| Estado | APROBADA |\n| Aprobación | APROBADA |\n| Tamaño | M |\n| Interfaz | NO |\n| Origen | NUEVA |\n\n- RF-001: x\n' > specs/011-heredada/spec.md
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 2 |\n| Evidencia | ADOPCIÓN (confirmada por el usuario 2026-01-01, sin re-validar) |\n\nRELEASE: READY\n' > specs/011-heredada/release.md
git add -A >/dev/null; git commit -qm "docs(011-heredada): adopción"
expect adopcion_completada 0 "spec completada \\(adopción" "" -- --spec 011-heredada
printf -- '- [x] T-001 — vieja\n  - Evidencia: hecho\n- [x] T-002 — sin evidencia\n' > specs/011-heredada/tasks.md
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 2 |\n\nEvidencia: ADOPCIÓN (confirmada 2026-01-01)\n\nRELEASE: READY\n' > specs/011-heredada/release.md
git add -A >/dev/null; git commit -qm "docs(011-heredada): re-sellado adopción"
expect adopcion_linea_y_tareas 0 "spec completada \\(adopción" "PROBLEMA" -- --spec 011-heredada
echo "z = 1" > adop.py; git add -A >/dev/null; git commit -qm "feat(011-heredada): T-001 cambio"
expect adopcion_trabajo_nuevo 0 "SIGUIENTE PASO: sdd-clarify" "" -- --spec 011-heredada
mkdir -p specs/011-heredada/bugs; printf '# BUG-077\n- Estado: CERRADO\n' > specs/011-heredada/bugs/BUG-077.md; git add -A >/dev/null; git commit -qm "fix(011-heredada): BUG-077"
rm -f adop.py; git add -A >/dev/null; git commit -qm "chore: quita"
expect adopcion_bug 0 "SIGUIENTE PASO: sdd-release · MOTIVO: bug corregido en una spec adoptada" "" -- --spec 011-heredada
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 2 |\n| Evidencia | ADOPCIÓN (confirmada 2026-01-01) |\n\nSiguiente paso: sdd-bug\n\nRELEASE: BLOCKED\n' > specs/011-heredada/release.md
git add -A >/dev/null; git commit -qm "docs(011-heredada): adopción bloqueada"
expect adopcion_blocked 0 "SIGUIENTE PASO: sdd-bug · MOTIVO: RELEASE de adopción BLOCKED" "sdd-clarify" -- --spec 011-heredada
rm -rf specs/011-heredada adop.py; git add -A >/dev/null; git commit -qm limpia-adop

echo "· commit de código suelto tras release → aviso; tasks sin veredicto → sdd-tasks"
echo "q = 1" > suelto.py; git add -A >/dev/null; git commit -qm "perf: cache"
expect commit_suelto 0 "AVISO: 1 commit\\(s\\) de código posteriores al último release" "" --
rm -f suelto.py; git add -A >/dev/null; git commit -qm "chore: quita"
cp specs/001-a/tasks.md "$T/../tv.bak"; python3 -c "import sys;p=sys.argv[1];s=open(p,encoding='utf-8').read();open(p,'w',encoding='utf-8').write(s.replace('TRAZABILIDAD: PASS',''))" specs/001-a/tasks.md
expect tasks_sin_veredicto 0 "SIGUIENTE PASO: sdd-tasks · MOTIVO: tasks.md sin veredicto" "" -- --spec 001-a
cp "$T/../tv.bak" specs/001-a/tasks.md

echo "· backlog: bloquea validate, ruta con tarea, pipes en el hallazgo, CRITICO sin tilde, filas mal formadas"
mkdir -p reviews
cat > reviews/backlog.md <<'EOF'
| ID | Fecha | Severidad | Tipo | Hallazgo | Spec | Ruta | Estado |
|---|---|---|---|---|---|---|---|
| R-010 | x | ALTO | TAREA INCOMPLETA | usa `a || b` y \| escapado | 001 RF-001 | sdd-implement T-002 | ABIERTO |
EOF
expect backlog_ruta_tarea 0 "SIGUIENTE PASO: sdd-implement T-002 · MOTIVO: R-010 ALTO ABIERTO" "" --
rep reviews/backlog.md "| ABIERTO |" "| HECHO |"
printf '| R-011 | x | CRITICO | BUG | y | 001 | sdd-bug | abierto |\n' >> reviews/backlog.md
expect backlog_critico_sin_tilde 0 "SIGUIENTE PASO: sdd-bug · MOTIVO: R-011 CRITICO" "" --
printf '| R-012 | x | ALTO | faltan columnas |\n' >> reviews/backlog.md
expect backlog_malformada 1 "PROBLEMA: backlog: fila R-012 mal formada.*sdd-review" "" --
expect backlog_malformada_con_spec 1 "SPEC 001-a" "" -- --spec 001-a
printf '| ID | Fecha | Severidad | Tipo | Hallazgo | Spec | Ruta | Estado |\n|---|---|---|---|---|---|---|---|\n| R-013 | x | ALTO | BUG | y | 001 | sdd-validate | ABIERTO |\n| R-014 | x | URGENTE | BUG | y | 001 | sdd-bug | ABIERTO |\n| R-015 | x | MEDIO | TAREA INCOMPLETA | y | 001 | sdd-implement | ABIERTO |\n| R-016 | x | ALTO | BUG | y | 001 | sdd-validate | HECHO |\n' > reviews/backlog.md
expect backlog_ruta_invalida 1 "PROBLEMA: backlog: fila R-013 con Ruta no válida" "R-016" --
expect backlog_ruta_invalida_enruta 1 "SIGUIENTE PASO: sdd-review · MOTIVO: R-013 ALTO ABIERTO" "" -- --spec 001-a
expect backlog_severidad_invalida 1 "PROBLEMA: backlog: fila R-014 con Severidad no válida" "" --
expect backlog_implement_sin_tarea 1 "PROBLEMA: backlog: fila R-015 con Ruta no válida" "" --
rm -f reviews/backlog.md

echo "· veredicto de plantilla sin rellenar, severidad en femenino, fichero suelto en specs/"
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ | NO"
expect veredicto_plantilla 0 "validation=ok|SIGUIENTE PASO: (sdd-validate|—)" "spec completada" --
derived specs/001-a/validation.md 2 3 "SPEC CUMPLIDA: SÍ"
mkdir -p reviews; printf '| ID | Fecha | Severidad | Tipo | Hallazgo | Spec | Ruta | Estado |\n|---|---|---|---|---|---|---|---|\n| R-020 | x | Alta | BUG | y | 001 | sdd-bug | ABIERTO |\n' > reviews/backlog.md
expect severidad_femenino 0 "R-020 ALTA ABIERTO" "" --
rm -f reviews/backlog.md; echo nota > specs/002-notas.md
expect fichero_suelto 0 "spec completada" "002-notas" --
rm -f specs/002-notas.md

echo "· backlog global (Spec —): bloquea cualquier release, no reabre specs completadas"
ready_spec specs/012-glob 1
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n\n- [x] T-001 — a\n  - Evidencia (T-001): GREEN → 1/1\n\nTRAZABILIDAD: PASS\n' > specs/012-glob/tasks.md
derived specs/012-glob/validation.md 1 1 "SPEC CUMPLIDA: SÍ"
git add specs/012-glob >/dev/null; git commit -qm "docs(012-glob): validation"
mkdir -p reviews; printf '| ID | Fecha | Severidad | Tipo | Hallazgo | Spec | Ruta | Estado |\n|---|---|---|---|---|---|---|---|\n| R-030 | x | CRÍTICO | BUG | inyección en lib común | — | sdd-bug | ABIERTO |\n' > reviews/backlog.md
expect global_bloquea_release 0 "SIGUIENTE PASO: sdd-bug · MOTIVO: R-030 CRÍTICO ABIERTO \(global\)" "" -- --spec 012-glob
expect global_no_reabre 0 "SIGUIENTE PASO: — · MOTIVO: spec completada" "SIGUIENTE PASO: sdd-bug" -- --spec 001-a
printf '| R-031 | x | ALTO | TAREA INCOMPLETA | y | — | sdd-implement T-001 | ABIERTO |\n| R-032 | x | ALTO | PLAN OBSOLETO | y | — | sdd-plan | ABIERTO |\n| R-033 | x | MEDIO | BUG | y | O01 | sdd-bug | ABIERTO |\n' >> reviews/backlog.md
expect global_con_tarea 1 "PROBLEMA: backlog: fila R-031 con Ruta no válida" "" --
expect global_con_plan 1 "PROBLEMA: backlog: fila R-032 con Ruta no válida.*sdd-bug, sdd-change, sdd-refactor o sdd-retro" "" --
expect spec_mal_escrita 1 "PROBLEMA: backlog: fila R-033 con Spec no válida" "" --
rep reviews/backlog.md "| sdd-bug | ABIERTO |" "| sdd-bug | BUG-009 |"; rep reviews/backlog.md "| ABIERTO |" "| DESCARTADO (prueba) |"
expect global_resuelto 0 "SIGUIENTE PASO: sdd-release" "R-030" -- --spec 012-glob
printf '| R-040 | x | CRÍTICO | BUG | y | RF-001 | sdd-bug | ABIERTO |\n' >> reviews/backlog.md
expect spec_irreconocible 1 "PROBLEMA: backlog: fila R-040 con Spec no válida" "" -- --spec 012-glob
expect spec_irreconocible_bloquea 1 "SIGUIENTE PASO: sdd-review · MOTIVO: R-040 .*modo formato" "" -- --spec 012-glob
rep reviews/backlog.md "| y | RF-001 |" "| y | 009 RF-001 |"
expect spec_inexistente 1 "PROBLEMA: backlog: fila R-040 con Spec no válida" "" -- --spec 012-glob
rep reviews/backlog.md "| 009 RF-001 | sdd-bug | ABIERTO |" "| 009 RF-001 | sdd-bug | HECHO |"
printf '| R-041 | x | CRÍTICO | BUG | sin columnas |\n' >> reviews/backlog.md
expect malformada_bloquea 1 "SIGUIENTE PASO: sdd-review · MOTIVO: R-041 .*modo formato" "" -- --spec 012-glob
rm -rf specs/012-glob reviews/backlog.md; git add specs/012-glob >/dev/null; git commit -qm limpia-glob
printf '| ID | Fecha | Severidad | Tipo | Hallazgo | Spec | Ruta | Estado |\n|---|---|---|---|---|---|---|---|\n| R-050 | x | ALTO | BUG | y | — | sdd-bug | ABIERTO |\n' > reviews/backlog.md
expect global_sin_spec_activa 0 "PROYECTO · SIGUIENTE PASO: sdd-bug · MOTIVO: R-050 ALTO ABIERTO \(global\)" "" --
rm -f reviews/backlog.md

echo "· archivo: dependencias resueltas; reabrir una archivada = PROBLEMA"
ready_spec specs/004-arch 1
printf -- '- [x] T-001 — viejo\n  - Evidencia (T-001): RED a → 1 · GREEN a → 1/1\n' > specs/004-arch/tasks-archive.md
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n\n- [x] T-002 — y\n  - Depende de: T-001\n  - Evidencia (T-002): GREEN b → 1/1\n- [ ] T-003 — z\n  - Depende de: T-001, T-002\n  - Evidencia (T-003): pendiente\n\nTRAZABILIDAD: PASS\n' > specs/004-arch/tasks.md
expect archivo 0 "SIGUIENTE PASO: sdd-implement T-003" "PROBLEMA" -- --spec 004-arch
expect archivo_cuenta 0 "\(\+1 archivadas\)" "" -- --spec 004-arch
mkdir -p reviews; BH='| ID | Fecha | Severidad | Tipo | Hallazgo | Spec | Ruta | Estado |\n|---|---|---|---|---|---|---|---|\n'
printf "$BH"'| R-061 | x | MEDIO | TAREA INCOMPLETA | y | 004 | sdd-implement T-077 | ABIERTO |\n' > reviews/backlog.md
expect backlog_tarea_inexistente_medio 0 "aviso: backlog: R-061 apunta a T-077, que no existe en 004-arch" "PROBLEMA" -- --spec 004-arch
printf "$BH"'| R-062 | x | ALTO | TAREA INCOMPLETA | y | 004 | sdd-implement T-077 | ABIERTO |\n' > reviews/backlog.md
expect backlog_tarea_inexistente_alto 1 "PROBLEMA: backlog: R-062 apunta a T-077, que no existe en 004-arch" "" -- --spec 004-arch
printf "$BH"'| R-060 | x | ALTO | TAREA INCOMPLETA | y | 004 | sdd-implement T-001 | ABIERTO |\n' > reviews/backlog.md
cp specs/004-arch/tasks.md "$T/../ta.bak"; rep specs/004-arch/tasks.md "- [ ] T-003 — z\n  - Depende de: T-001, T-002\n  - Evidencia (T-003): pendiente" "- [x] T-003 — z\n  - Depende de: T-001, T-002\n  - Evidencia (T-003): GREEN c → 1/1"
expect backlog_tarea_archivada 0 "SIGUIENTE PASO: sdd-tasks · MOTIVO: R-060 ALTO ABIERTO" "sdd-implement T-001" -- --spec 004-arch
cp "$T/../ta.bak" specs/004-arch/tasks.md; rm -f reviews/backlog.md
printf -- '- [ ] T-001 — reabierta\n  - Evidencia (T-001): pendiente\n' >> specs/004-arch/tasks.md
expect archivada_reabierta 1 "T-001 está también en tasks-archive.md" "" -- --spec 004-arch
rm -rf specs/004-arch

echo "· RETRO (el registro de cambios no cuenta)"
mkdir -p specs/005-retro
printf '| Campo | Valor |\n|---|---|\n| Spec-ID | 005-retro |\n| Versión | 1 |\n| Estado | APROBADA |\n| Aprobación | APROBADA (2026-01-01, por el usuario) |\n| Tamaño | N/A (RETRO) |\n| Interfaz | NO |\n| Origen | RETRO |\n\n- RF-001: x (Test: t)\n\n## Registro de cambios\n| 1 | antes había un RF (defecto) |\n' > specs/005-retro/spec.md
expect retro_completa 0 "SIGUIENTE PASO: — · MOTIVO: spec RETRO completada" "" -- --spec 005-retro
rep specs/005-retro/spec.md "| Estado | APROBADA |" "| Estado | APROBADA (2026-01-01) |"
expect retro_estado_fecha 0 "spec RETRO completada" "" -- --spec 005-retro
mkdir -p reviews; printf '| ID | Fecha | Severidad | Tipo | Hallazgo | Spec | Ruta | Estado |\n|---|---|---|---|---|---|---|---|\n| R-090 | x | ALTO | BUG | y | 005 | sdd-bug | ABIERTO |\n' > reviews/backlog.md
expect retro_backlog 0 "SIGUIENTE PASO: sdd-bug · MOTIVO: R-090 ALTO ABIERTO" "" -- --spec 005-retro
rm -f reviews/backlog.md
rep specs/005-retro/spec.md "- RF-001: x (Test: t)" "- RF-001: x (Test: t)\n- RF-002: y (defecto)"
expect retro_defecto 0 "SIGUIENTE PASO: sdd-bug · MOTIVO: spec RETRO con RF marcados" "" -- --spec 005-retro
rep specs/005-retro/spec.md "- RF-002: y (defecto)" "Pendiente: sdd-change — ampliar el informe"
expect retro_pendiente 0 "SIGUIENTE PASO: sdd-change · MOTIVO: spec RETRO aprobada con pedido pendiente" "" -- --spec 005-retro
rep specs/005-retro/spec.md "Pendiente: sdd-change — ampliar el informe" "Pendiente: sdd-retro — caracterizar RF-003\nPendiente: sdd-change — ampliar el informe"
expect retro_caracterizar 0 "SIGUIENTE PASO: sdd-retro · MOTIVO: spec RETRO aprobada con pedido pendiente" "" -- --spec 005-retro
rep specs/005-retro/spec.md "Pendiente: sdd-retro — caracterizar RF-003\nPendiente: sdd-change — ampliar el informe" "- **Pendiente:** sdd-change — en viñeta"
expect retro_pendiente_vineta 0 "SIGUIENTE PASO: sdd-change" "" -- --spec 005-retro
rm -rf specs/005-retro

echo "· dependencias entre specs: una spec parada no cuenta como completada"
ready_spec specs/006-base 1
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n\n- [x] T-001 — a\n  - Evidencia (T-001): GREEN → 1/1\n\nTRAZABILIDAD: PASS\n' > specs/006-base/tasks.md
derived specs/006-base/validation.md 1 1 "SPEC CUMPLIDA: NO"
mkdir -p specs/007-hija; hdr_spec specs/007-hija BORRADOR 1 "| Depende de | 006-base |"
expect depende_de_parada 0 "espera a: 006-base" "" --
expect activa_base 0 "SPEC A AVANZAR: 006-base" "" --
derived specs/006-base/validation.md 1 1 "Siguiente paso: sdd-orchestrator

SPEC CUMPLIDA: NO"
expect siguiente_no_valido 0 "SIGUIENTE PASO: — · MOTIVO: SPEC CUMPLIDA: NO: requiere acción" "SIGUIENTE PASO: sdd-orchestrator" -- --spec 006-base
json_parity dependencias
rm -rf specs/006-base specs/007-hija

echo "· desde un subdirectorio"
mkdir -p sub/dir; pushd sub/dir >/dev/null; expect subdir 0 "SPEC 001-a v2" "PROYECTO · SIGUIENTE PASO: sdd-init" --; popd >/dev/null

echo "· fichero no UTF-8 (latin-1)"
ready_spec specs/008-lat 1; printf 'TRAZABILIDAD: PASS\n- [ ] T-001 \xf1and\xfa\n  - Evidencia (T-001): pendiente\n' >> specs/008-lat/clarify.md
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n\n- [ ] T-001 \xe1rbol\n  - Evidencia (T-001): pendiente\n\nTRAZABILIDAD: PASS\n' > specs/008-lat/tasks.md
expect latin1 0 "SIGUIENTE PASO: sdd-implement T-001" "Traceback|Error" -- --spec 008-lat
rm -rf specs/008-lat; rm -rf sub

echo "· pre-commit"
git add -A >/dev/null; git commit -qm base2 >/dev/null 2>&1 || true
expect sin_staged 1 "no hay nada staged" "" -- pre-commit --task T-001
echo 'código' > a.txt; git add a.txt
expect generico 0 "MODO: genérico \(secretos y tests\)" "PROBLEMA" -- pre-commit
printf 'it.only("x", () => {})\n' > foco.test.js; git add foco.test.js
expect test_enfocado 1 "PROBLEMA: test enfocado" "" -- pre-commit
printf 'it.only.each([1])("x", () => {})\n' > foco.test.js; git add foco.test.js
expect test_enfocado_each 1 "PROBLEMA: test enfocado" "" -- pre-commit
git reset -q foco.test.js; rm -f foco.test.js
printf 'model.fit(X, y)\nlayout.fit(box)\n' > train.py; git add train.py
expect fit_no_es_test 0 "PRE-COMMIT: OK" "test enfocado" -- pre-commit
git reset -q train.py; rm -f train.py
printf '// eslint-disable-next-line no-console\n' > lint.js; git add lint.js
expect supresion 0 "AVISO: supresión de lint, tipos o cobertura" "PROBLEMA" -- pre-commit
git reset -q lint.js; rm -f lint.js
printf 'test("a", () => {})\n' > borrar.test.js; git add borrar.test.js; git commit -qm "test: a" -- borrar.test.js; git rm -q borrar.test.js
expect test_eliminado 0 "AVISO: test eliminado: borrar.test.js" "" -- pre-commit
git commit -qm "test: quita a" -- borrar.test.js
cp AGENTS.md "$T/../ag2.bak"; printf '| Tests | npm test | x | y |\n' >> AGENTS.md; git add AGENTS.md
expect tabla_comandos 0 "AVISO: cambia la tabla de comandos de AGENTS.md" "" -- pre-commit
git reset -q AGENTS.md; cp "$T/../ag2.bak" AGENTS.md
printf 'it.skip("x", () => {})\n' > foco.test.js; printf '@pytest.mark.skip\ndef test_a(): pass\n' > test_s.py; git add foco.test.js test_s.py
expect test_desactivado 0 "AVISO: test desactivado" "PROBLEMA" -- pre-commit
git reset -q foco.test.js test_s.py; rm -f foco.test.js test_s.py
printf 'No dejes `it.only(` en el repo\n' > NOTAS.md; git add NOTAS.md
expect test_enfocado_en_doc 0 "PRE-COMMIT: OK" "test enfocado" -- pre-commit
printf 'const cfg = { password: "Sup3rS3cret!" }\n' > cfg.js; git add cfg.js
expect secreto_en_codigo 0 "AVISO: posible secreto en código \(patrón genérico\) en cfg.js:1" "Sup3rS3cret|PROBLEMA" -- pre-commit
printf 'const cfg = { password: "Sup3rS3cret!" } // sdd-allow-secret\n' > cfg.js; git add cfg.js
expect secreto_en_codigo_permitido 0 "PRE-COMMIT: OK" "cfg.js:1|PROBLEMA" -- pre-commit
git reset -q cfg.js; rm -f cfg.js
printf 'api_key: Optional[str] = None\ntokenizer_name = model_args.tok\npassword = var.db_password\nsecretName: db-credentials\ntoken_url = "https://auth.example.com/token"\nDB = "postgres://${PGUSER}:${PGPASSWORD}@db/app"\n' > svc.py; git add svc.py
expect benignos_sin_aviso 0 "PRE-COMMIT: OK" "AVISO|PROBLEMA" -- pre-commit
printf 'T = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"\n' > jwt.py; git add jwt.py
expect jwt_en_codigo 1 "PROBLEMA: secreto probable en jwt.py:1" "eyJhbGciOiJIUzI1NiJ9.eyJ" -- pre-commit
git reset -q svc.py jwt.py; rm -f svc.py jwt.py
printf '++ x\nit.only("a", () => {})\n' > inj.test.js; git add inj.test.js
expect diff_inyeccion 1 "PROBLEMA: test enfocado .*inj.test.js" "" -- pre-commit
git reset -q inj.test.js; rm -f inj.test.js
mkdir -p cypress/e2e; printf 'it.only("x", () => {})\n' > cypress/e2e/a.cy.ts; git add cypress
expect cypress_enfocado 1 "PROBLEMA: test enfocado" "" -- pre-commit
printf 'test.skipIf(win)("x", () => { expect(1).toBe(1) })\n' > cypress/e2e/a.cy.ts; git add cypress
expect skipif 0 "AVISO: test desactivado" "PROBLEMA" -- pre-commit
git reset -q cypress; rm -rf cypress
printf '// @ts-nocheck\n' > nocheck.ts; git add nocheck.ts
expect ts_nocheck 0 "AVISO: supresión" "" -- pre-commit
git reset -q nocheck.ts; rm -f nocheck.ts
printf '{"scripts":{"test":"jest --passWithNoTests || true"}}\n' > package.json; git add package.json
expect config_tests 0 "AVISO: cambia cómo se ejecutan los tests o la CI en package.json" "" -- pre-commit
git reset -q package.json; rm -f package.json
echo "regla nueva" >> docs/agent-runbook.md; git add docs/agent-runbook.md
expect guia_agentes 0 "AVISO: cambia docs/agent-runbook.md" "" -- pre-commit
git reset -q docs/agent-runbook.md; git checkout -q -- docs/agent-runbook.md
echo "· bypass: diff externo, .gitattributes, NUL, tope de avisos, nombres con espacios, secreto en avisos"
printf 'it.only("x", () => {})\n' > ext.test.js; git add ext.test.js; git config diff.external /bin/true
expect diff_externo 1 "PROBLEMA: test enfocado" "" -- pre-commit
git config --unset diff.external; printf '*.js -diff\n' > .gitattributes
expect gitattributes_nodiff 1 "PROBLEMA: test enfocado" "" -- pre-commit
rm -f .gitattributes; printf 'it.only("x", () => {})\n\0\n' > ext.test.js; git add ext.test.js
expect fichero_con_nul 1 "PROBLEMA: test enfocado" "" -- pre-commit
git reset -q ext.test.js; rm -f ext.test.js
mkdir -p tests zz; for i in 1 2 3 4 5 6 7 8 9; do echo "password = \"fixture-pass-$i\"" > tests/f$i.py; done; printf 'k = "%s"\n' "ghp_a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6q7R8" > zz/z.js; git add tests zz
expect tope_de_avisos 1 "PROBLEMA: secreto probable en zz/z.js:1" "" -- pre-commit
git reset -q tests zz; rm -rf tests zz
mkdir -p src; printf 'it.only("x", () => {})\n' > "src/a b.test.js"; git add src
expect nombre_con_espacios 1 "PROBLEMA: test enfocado .*src/a b.test.js" "" -- pre-commit
git reset -q src; rm -rf src
printf 'const k = "%s"; // eslint-disable-line\n' "ghp_a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6q7R8" > m.js; git add m.js
expect sin_secreto_en_avisos 1 "AVISO: supresión .*m.js:1" "a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6q7R8" -- pre-commit
git reset -q m.js; rm -f m.js
echo "· precisión: falsos positivos frecuentes y secretos que faltaban"
printf 'cache_key = "user_profile_v2"\nobject_key = "reports/2024/q1.csv"\ni18n_key: "errors.auth.e401"\npublic_key = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOMqqnkVzrm0SdG6UOoqKLsabgH5C9okWi0dh2l9GKJl"\nPWD=/home/runner/work/app2\npartition_key = "tenant#00042"\nsecret: projects/p1/secrets/db/versions/2\n' > ok.tf; git add ok.tf
expect falsos_positivos_r4 0 "PRE-COMMIT: OK" "PROBLEMA|AVISO: revisa" -- pre-commit
git reset -q ok.tf; rm -f ok.tf
printf 'a = "whsec_MfKQ9r8GKYqrTwjUPD8ILPZIo2LaLaSw"\nb = "hf_aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789"\n-----BEGIN PGP PRIVATE KEY BLOCK-----\nkey: LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQo=\nAuthorization: Basic dXNlcjpzM2NyM3RwYXNz\ndb_password = "correct-horse-battery-staple"\n' > leak.py; git add leak.py
for n in 1 2 3 4 5; do expect "secreto_nuevo_$n" 1 "PROBLEMA: secreto probable en leak.py:$n" "" -- pre-commit; done
expect secreto_nuevo_6_generico 1 "AVISO: posible secreto en código \(patrón genérico\) en leak.py:6" "PROBLEMA: secreto probable en leak.py:6" -- pre-commit
git reset -q leak.py; rm -f leak.py
echo "· precisión r5: identificadores, referencias de IaC, i18n, ===, claves públicas; camelCase, NetworkCredential, Discord"
cat > ok5.ts <<'EOT'
const STORAGE_KEY = 'todo_app_state_v1'
cache_key = "user_cache_v2_items"
LOCK_KEY = "billing_lock_v3_global"
password = random_password.rds_v2.result
access_key = aws_iam_access_key.deploy_v2.id
existingSecret: postgres-credentials-v2
password: 'login.fields.password'
if(this.state.lastNextToken===this._buf.charCodeAt(59)){}
stripe_publishable_key = "pk_live_51HcXyZaBcDeFgHiJkLmNoPq"
const publicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE7x"
EOT
git add ok5.ts
expect falsos_positivos_r5 0 "PRE-COMMIT: OK" "PROBLEMA|AVISO: revisa" -- pre-commit
git reset -q ok5.ts; rm -f ok5.ts
cat > leak5.go <<'EOT'
var jwtSigningKey = []byte("k8Hs2nQ9xLm4Vb7Tz1Rw")
const encryptionKey = "Zq7Lp2Xw9Mn4Kd8Rt5Vb";
var c = new NetworkCredential("svc", "Tr0ub4dor&3xQ");
u := "https://discord.com/api/webhooks/123456789012345678/AbCdEfGhIjKlMnOpQrStUvWxYz0123456789AbCdEfGhIjKlMnOpQrStUvWxYz01"
EOT
git add leak5.go
printf 'v = "hvs.CAESIJlU9JMYEhOPYv4igdhm9PnZDrabYTobQ4Ymnlq1qY-LGh4KHGh2cy5WUjJl"\nb = TeleBot("7123456789:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw1")\n' >> leak5.go; git add leak5.go
for n in 1 2; do expect "secreto_r5_generico_$n" 1 "AVISO: posible secreto en código \(patrón genérico\) en leak5.go:$n" "PROBLEMA: secreto probable en leak5.go:$n" -- pre-commit; done
for n in 3 4 5 6; do expect "secreto_r5_$n" 1 "PROBLEMA: secreto probable en leak5.go:$n" "" -- pre-commit; done
git reset -q leak5.go; rm -f leak5.go
echo "· ronda 6: falsos avisos y secretos genéricos que faltaban"
cat > ok6.ts <<'EOT'
export const vapidPublicKey = "BEl62iUYgUivxIkv69yViEuiBIa-Ib9-SkvMeAtA3LFgDzkrxZJjSgSnfck"
const storageKey = "todo-app-state-v2";
const LOCAL_STORAGE_KEY = "userPreferencesV2";
RECAPTCHA_SITE_KEY = "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"
VAPID_PUBLIC_KEY = "BEl62iUYgUivxIkv69yViEuiBIa-Ib9-SkvMeAtA3LFgDzkrxZJjSgSnfck"
$token = Str::random(60);
let api_key = ApiKey::generate(32);
CREATE ROLE app LOGIN PASSWORD :'app_password';
mysqldump -h db -u root -p$MYSQL_ROOT_PASSWORD app > /backup/app.sql
curl -fsS -u $NEXUS_USER:$NEXUS_PASSWORD --upload-file dist/app.tgz https://nexus.example.com/
test: ["CMD-SHELL", "mysqladmin ping -h localhost -u root -p$$MYSQL_ROOT_PASSWORD"]
const translationKey = "checkout.step2.title";
const cacheKey = "dashboard-stats-v2-weekly";
EOT
git add ok6.ts
expect falsos_avisos_r6 0 "PRE-COMMIT: OK" "PROBLEMA|ok6.ts:[0-9]" -- pre-commit
git reset -q ok6.ts; rm -f ok6.ts
cat > gen6.ts <<'EOT'
private readonly apiKey: string = "qlsqGu3KNA9iYPVT0auzTrVO8FYQEkqD";
api_key: str = "nDfl0WLRwLL38JNflufkyP1rKJK9ayQf"
const API_TOKEN: &str = "sRiEtvyJbflAMIELQaBMyvxcWqOpM87c";
var apiToken string = "38ccd7cc7321c2791c8688675fbc2bf2"
define('DB_PASSWORD', 'S3cur3Pa55w0rd');
CREATE USER reporting WITH PASSWORD 'R3p0rt!ng2026';
CREATE USER 'etl'@'%' IDENTIFIED BY 'Etl#Load2026';
EOT
git add gen6.ts
for n in 1 2 3 4 5 6 7; do expect "generico_r6_$n" 0 "AVISO: posible secreto en código \(patrón genérico\) en gen6.ts:$n" "PROBLEMA" -- pre-commit; done
git reset -q gen6.ts; rm -f gen6.ts
printf 'DB_PASS=wintersun\n' > .env; git add -f .env
expect env_pass 1 "PROBLEMA: secreto probable en .env:1" "wintersun" -- pre-commit
git reset -q .env; rm -f .env
echo "· ronda 7: URLs de desarrollo, Basic entre comillas, redis sin usuario, .env *_KEY/*_AUTH, requirements.txt, fragmentos"
cat > urls.ts <<'EOT'
const a = "postgres://postgres:postgres@db:5432/app"
const b = "amqp://guest:guest@localhost:5672"
const c = "driver://user:pass@localhost/dbname"
const d = "redis://default:changeme@redis:6379"
EOT
git add urls.ts
expect url_desarrollo_sin_fail 0 "PRE-COMMIT: OK" "PROBLEMA" -- pre-commit
printf 'const e = "postgres://app:Xk29fLmq7Rt@localhost:5432/app"\n' > urls.ts; git add urls.ts
expect url_localhost_aviso 0 "AVISO: .*urls.ts:1" "PROBLEMA" -- pre-commit
git reset -q urls.ts; rm -f urls.ts
printf 'DATABASE_URL=postgres://user:password@localhost:5432/acme\n' > .env.example; git add -f .env.example
expect env_example_lax 0 "PRE-COMMIT: OK" "PROBLEMA" -- pre-commit
git reset -q .env.example; rm -f .env.example
cat > r7.js <<'EOT'
fetch(u, { headers: { Authorization: 'Basic ZGVwbG95OnMzY3IzdHBhc3M=' } })
req.Header.Set("Authorization", "Basic ZGVwbG95OnMzY3IzdHBhc3M=")
const r = "redis://:Pr0dRedisPw9@cache.prod.internal:6379"
EOT
git add r7.js
for n in 1 2 3; do expect "r7_fuerte_$n" 1 "PROBLEMA: secreto probable en r7.js:$n" "" -- pre-commit; done
git reset -q r7.js; rm -f r7.js
printf 'APP_KEY=base64:2fl+Ktvkfl+Fuz4Qp/A75G2RTiWVA/ZoKZvp6fiiM10=\nSENTRY_AUTH=sntrys_eyJpYXQiOjE2OTQw\nENCRYPTION_KEY=9f8e7d6c5b4a39281706f5e4d3c2b1a0\nCACHE_KEY=sessions\nSTRIPE_PUBLISHABLE_KEY=pk_live_51HcXyZaBcDeFgHiJkLmNoPq\n' > .env; git add -f .env
for n in 1 2 3; do expect "env_key_auth_$n" 1 "PROBLEMA: secreto probable en .env:$n" "" -- pre-commit; done
expect env_key_no_secreto 1 "PROBLEMA" "en \.env:[45]" -- pre-commit
git reset -q .env; rm -f .env
printf -- '--extra-index-url https://deploy:Xk29fLmq7RtQ@pypi.internal.example.com/simple\n' > requirements.txt; git add requirements.txt
expect requirements_no_es_doc 1 "PROBLEMA: secreto probable en requirements.txt:1" "" -- pre-commit
git reset -q requirements.txt; rm -f requirements.txt
printf 'run --token l7UeioEJP2NNer --host 10.0.0.4  # nosec\n' > ssh.sh; git add ssh.sh
expect fragmento_redactado 0 "AVISO: supresión .*ssh.sh:1" "l7UeioEJP2NNer" -- pre-commit
printf "sshpass -p 'l7UeioEJP2NNer' ssh deploy@10.0.0.4\nsshpass -p \$SSHPASS ssh deploy@10.0.0.4\n" > ssh.sh; git add ssh.sh
expect sshpass_literal 1 "PROBLEMA: secreto probable en ssh.sh:1" "ssh.sh:2" -- pre-commit
git reset -q ssh.sh; rm -f ssh.sh
printf 'set(LICENSE_KEY "8iLc7bE6wSt9cbMOeEeUtuieeCIxVc57")\nset(CMAKE_BUILD_TYPE "Release")\n' > CMakeLists.txt; git add CMakeLists.txt
expect cmake_set 0 "AVISO: posible secreto en código .*CMakeLists.txt:1" "CMakeLists.txt:2|PROBLEMA" -- pre-commit
git reset -q CMakeLists.txt; rm -f CMakeLists.txt
mkdir -p tests; printf 'const u = "postgres://acme:Xk29fLmq7Rt@db.prod.example.com/acme"\n' > tests/helpers.ts; git add tests; git commit -qm "test: helpers"
git mv tests/helpers.ts src_db.ts
expect renombrado_no_oculta 1 "PROBLEMA: secreto probable en src_db.ts:1" "" -- pre-commit
git commit -qm "refactor: mueve helpers"
expect renombrado_no_oculta_ci 1 "PROBLEMA: secreto probable en src_db.ts:1" "" -- pre-commit --range HEAD~1..HEAD
git rm -q src_db.ts; git commit -qm "chore: quita"
echo "· ronda 8: un \\r suelto no oculta secretos; solo los .env de ejemplo son laxos"
mkdir -p src; printf '// cfg\rconst t = "%s";\n' "ghp_a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6q7R8" > src/cr.js; git add src
expect cr_suelto 1 "PROBLEMA: secreto probable en src/cr.js:1" "a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6q7R8" -- pre-commit
printf 'import os\rDB = "postgres://app:Xk29fLmq7RtQ@db.acme-prod.net/app"\r\n' > src/cr.js; git add src
expect cr_suelto_url 1 "PROBLEMA: secreto probable en src/cr.js:1" "" -- pre-commit
git reset -q src; rm -rf src
mkdir -p deploy; printf 'Url: postgres://app:Xk29fLmq7RtQ@db.acme-prod.net/app\n' > deploy/stack.template; git add deploy
expect template_no_laxo 1 "PROBLEMA: secreto probable en deploy/stack.template:1" "" -- pre-commit
git reset -q deploy; rm -rf deploy
echo "· bypass por prefijos del diff; línea enorme en tiempo lineal; .env nunca en claro"
printf 'k = "%s"\n' "ghp_a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6q7R8" > pre.py; git add pre.py; git config diff.dstPrefix tests/; git config diff.mnemonicPrefix true
expect prefijos_diff 1 "PROBLEMA: secreto probable en pre.py:1" "" -- pre-commit
git config --unset diff.dstPrefix; git config --unset diff.mnemonicPrefix; git reset -q pre.py; rm -f pre.py
python3 -c "open('big.js','w').write('e.api_key=t.x,'*20000+'\n')"; git add big.js
expect linea_enorme 0 "PRE-COMMIT: OK" "" -- pre-commit
git reset -q big.js; rm -f big.js
printf 'PASSWORD=hunterhunterzz # nosec\n' > .env; git add -f .env
expect env_nunca_en_claro 1 "AVISO: supresión .*\.env:1" "hunterhunterzz" -- pre-commit
printf 'MAIL_PASS=Wint3rSun2026 # nosec\n' > .env; git add -f .env
expect env_pass_detectado_y_no_en_claro 1 "PROBLEMA: secreto probable en \.env:1" "Wint3rSun2026" -- pre-commit
git reset -q .env; rm -f .env; printf 'const smtpPass = "Wint3r!Sun"; // eslint-disable-line\n' > smtp.js; git add smtp.js
expect literal_en_claro 0 "AVISO: supresión .*smtp.js:1" "Wint3r!Sun" -- pre-commit
git reset -q smtp.js; rm -f smtp.js; printf "x\n" > .env; git add -f .env
git reset -q .env; rm -f .env
git reset -q NOTAS.md; rm -f NOTAS.md
printf 'X=1\n' > .env; git add -f .env
expect env_staged 0 "AVISO: fichero de entorno o de credenciales staged: .env" "PROBLEMA" -- pre-commit
printf 'DB_PASSWORD=Pr0dPass!x9\n' > .env; git add -f .env
expect env_con_secreto 1 "PROBLEMA: secreto probable en .env:1" "Pr0dPass" -- pre-commit
printf 'DB_HOST=db\nSESSION_SECRET=averylongrandomsecretvalue\nAPI_TOKEN=\nPASSWORD=${VAULT_PW}\n' > .env; git add -f .env
expect env_secreto_sin_digitos 1 "PROBLEMA: secreto probable en .env:2" "averylong|\.env:3|\.env:4" -- pre-commit
git reset -q .env; rm -f .env
printf 'VITE_TOKEN_TTL=3600\nPASSWORD_MIN_LENGTH=8\nSESSION_SECRET_ROTATION_DAYS=30\nDEBUG=true\n' > .env.development; git add -f .env.development
expect env_config_no_secreta 0 "PRE-COMMIT: OK" "PROBLEMA|AVISO: revisa" -- pre-commit
printf 'DB_PASSWORD=postgres\n' > .env.development; git add -f .env.development
expect env_desarrollo_aviso 0 "AVISO: revisa .*\.env.development:1" "PROBLEMA" -- pre-commit
git reset -q .env.development; rm -f .env.development
printf 'SESSION_SECRET=averylongrandomsecretvalue\n' > .env.production; git add -f .env.production
expect env_produccion_fail 1 "PROBLEMA: secreto probable en .env.production:1" "" -- pre-commit
git reset -q .env.production; rm -f .env.production
printf 'SECRET_KEY_BASE=3b4f9a8c7d6e5f4a3b2c1d0e9f8a7b6c\nDB_PASSWORD_PROD=Pr0dPass!x9\nJWT_SECRET_KEY=averylongrandomsecretvalue\nPOSTGRES_PASSWORD_FILE=/run/secrets/pg\nTOKEN_URL=https://auth.example.com/token\n' > .env; git add -f .env
for n in 1 2 3; do expect "env_sufijo_$n" 1 "PROBLEMA: secreto probable en .env:$n" "" -- pre-commit; done
expect env_rutas_no 1 "PROBLEMA" "secreto probable en \.env:[45]" -- pre-commit
git reset -q .env; rm -f .env; printf 'X=1\n' > .env; git add -f .env
git reset -q .env; rm -f .env; printf 'registry=https://r.example.com/\n' > .npmrc; git add -f .npmrc
expect npmrc 0 "AVISO: fichero de entorno o de credenciales staged: .npmrc" "" -- pre-commit
git reset -q .npmrc; rm -f .npmrc
git reset -q .env; rm -f .env; printf 'X=\n' > .env.example; git add .env.example
expect env_example 0 "PRE-COMMIT: OK" "fichero de entorno" -- pre-commit
git reset -q .env.example; rm -f .env.example
mkdir -p cache/__pycache__; echo x > cache/__pycache__/m.pyc; git add cache
expect pyc_aviso 0 "AVISO: fichero generado staged" "" -- pre-commit
git reset -q cache; rm -rf cache
python3 -c "import sys; open('grande.lock','w').write(('linea de prueba ' * 8 + '\n') * 30000)"; git add grande.lock
expect diff_grande 0 "PRE-COMMIT: OK" "" -- pre-commit
git reset -q grande.lock; rm -f grande.lock
expect sin_tasks_staged 1 "no está staged: la evidencia va en el mismo commit" "" -- pre-commit --task T-001
rep specs/001-a/tasks.md "T-002 — b" "T-002 — b2"; git add specs/001-a/tasks.md
expect ok_task 0 "PRE-COMMIT: OK" "" -- pre-commit --task T-002
expect tarea_inexistente 1 "T-999 no existe" "" -- pre-commit --task T-999
rep specs/001-a/tasks.md "- [x] T-002 — b2" "* [x] **T-002** — b2"; git add specs/001-a/tasks.md
expect precommit_tarea_negrita 0 "PRE-COMMIT: OK" "" -- pre-commit --task T-002
rep specs/001-a/tasks.md "* [x] **T-002** — b2" "- [x] T-002 — b2"; git add specs/001-a/tasks.md
mkdir -p specs/009-z; printf -- '- [ ] T-002 — z\n  - Evidencia (T-002): pendiente\n' > specs/009-z/tasks.md
expect elige_spec_staged 0 "PRE-COMMIT: OK" "varias specs" -- pre-commit --task T-002
git reset -q specs/001-a/tasks.md
expect ambiguo 1 "T-002 existe en varias specs" "" -- pre-commit --task T-002
rm -rf specs/009-z; git add specs/001-a/tasks.md
echo 'fixture = { password: "valor-de-prueba-1" }' > f.txt; git add f.txt
expect secreto_blando 0 "AVISO: revisa" "PROBLEMA" -- pre-commit --task T-002
echo 'k = "AKIAABCDEFGHIJKLMNOP"' > k.txt; git add k.txt
expect secreto_duro 1 "PROBLEMA: secreto probable en k.txt:1" "AKIAABCDEFGHIJKLMNOP" -- pre-commit --task T-002
echo 'k = "sk-proj-abcdefghijklmnopqrstuvwxyz0123456789ABCD"' > k.txt; git add k.txt
expect secreto_sk_proj 1 "secreto probable" "" -- pre-commit --task T-002
echo 'n = "npm_abcdefghijklmnopqrstuvwxyz0123456789"' > k.txt; git add k.txt
expect secreto_npm 1 "secreto probable" "" -- pre-commit --task T-002
echo 'DATABASE_URL=postgres://app:s3cr3tpass@db.internal:5432/app' > k.txt; git add k.txt
expect secreto_url 0 "AVISO: revisa .*k.txt:1" "s3cr3tpass" -- pre-commit --task T-002
printf 'password: hunter2hunter2\nAPI_KEY=abcd1234efgh5678\n' > k.txt; git add k.txt
expect secreto_yaml 0 "AVISO: revisa .*k.txt:1" "hunter2hunter2" -- pre-commit --task T-002
expect secreto_env_sin_comillas 0 "AVISO: revisa .*k.txt:2" "abcd1234efgh5678" -- pre-commit --task T-002
printf 'password = process.env.DB_PASSWORD\ntoken: ${TOKEN_FROM_VAULT}\n' > k.txt; git add k.txt
expect secreto_referencia 0 "PRE-COMMIT: OK" "AVISO: revisa .*k.txt" -- pre-commit --task T-002
echo 'k = "AKIAIOSFODNN7EXAMPLE"' > k.txt; git add k.txt
expect secreto_ejemplo_proveedor 0 "PRE-COMMIT: OK" "secreto probable" -- pre-commit --task T-002
echo 'k = "AKIAABCDEFGHIJKLMNOP" # sdd-allow-secret' > k.txt; git add k.txt
expect secreto_permitido 0 "AVISO: secreto probable marcado como permitido.*revisión humana" "PROBLEMA" -- pre-commit --task T-002
printf '# BUG-001\n- Estado: CERRADO\n' > specs/001-a/bugs/BUG-001.md; git add specs/001-a/bugs/BUG-001.md
expect bug_sin_clase 1 "sin «Clase:»" "" -- pre-commit --bug BUG-001
printf '# BUG-001\n- Clase: ÉXITO-FALSO | MOCK-PERMISIVO\n- Estado: CERRADO\n' > specs/001-a/bugs/BUG-001.md; git add specs/001-a/bugs/BUG-001.md
expect bug_clase_plantilla 1 "sin «Clase:»" "" -- pre-commit --bug BUG-001
printf '# BUG-001\n- Clase: <una de: ÉXITO-FALSO · CONCURRENCIA>\n- Estado: CERRADO\n' > specs/001-a/bugs/BUG-001.md; git add specs/001-a/bugs/BUG-001.md
expect bug_clase_sin_rellenar 1 "sin «Clase:»" "" -- pre-commit --bug BUG-001
printf '# BUG-001\n- Clase: CONCURRENCIA\n- Estado: CERRADO\n' > specs/001-a/bugs/BUG-001.md; git add specs/001-a/bugs/BUG-001.md
expect bug_ok 0 "PRE-COMMIT: OK" "" -- pre-commit --bug BUG-001
git commit -qm bug; printf '# BUG-001\n- Estado: CERRADO\n- nota\n' > specs/001-a/bugs/BUG-001.md; git add specs/001-a/bugs/BUG-001.md
expect bug_antiguo 0 "PRE-COMMIT: OK" "Clase" -- pre-commit --bug BUG-001
git commit -qm bug2

echo "· pre-commit con nombre de spec no ASCII"
ready_spec "specs/010-gestión" 1
printf '| Campo | Valor |\n|---|---|\n| Spec-Version | 1 |\n| Plan-Version | 1 |\n\n- [x] T-001 — ñ\n  - Evidencia (T-001):\n    - GREEN: x → 1/1\n\nTRAZABILIDAD: PASS\n' > "specs/010-gestión/tasks.md"
echo x > b.txt; git add -A
expect no_ascii 0 "PRE-COMMIT: OK" "no está staged" -- pre-commit --task T-001 --spec 010-gestión
git commit -qm na
rep "specs/010-gestión/tasks.md" "— ñ" "— ñ2"; git add -A
expect tarea_solo_specs 0 "AVISO: commit de tarea sin cambios fuera de specs/" "" -- pre-commit --task T-001 --spec 010-gestión
git commit -qm na2

echo "· CI: pre-commit --range revisa los commits de una rama"
printf 'it.only("x", () => {})\n' > ci.test.js; git add ci.test.js; git commit -qm "test: ci"
expect rango_ci 1 "PROBLEMA: test enfocado .*en ci.test.js" "" -- pre-commit --range HEAD~1..HEAD
expect rango_ci_modo 1 "MODO: rango HEAD~1..HEAD" "" -- pre-commit --range HEAD~1..HEAD
expect rango_invalido 2 "rango no válido" "" -- pre-commit --range nada..HEAD
echo 'k = "AKIAABCDEFGHIJKLMNOQ"' > h.py; git add h.py; git commit -qm "feat: h"; git rm -q h.py; git commit -qm "chore: quita h"
expect rango_historial 1 "PROBLEMA: secreto probable en h.py:1" "AKIAABCDEFGHIJKLMNOQ" -- pre-commit --range HEAD~2..HEAD
L='k = "AKIAABCDEFGHIJKLMNOR" # sdd-allow-secret'; echo "$L" > p.py; git add p.py; git commit -qm "test: p"
expect rango_permitido_sin_hash 1 "PROBLEMA: .*p.py:1.*\.sdd-allowed-secrets" "AKIAABCDEFGHIJKLMNOR" -- pre-commit --range HEAD~1..HEAD
H=$(python3 -c "import hashlib,sys;print(hashlib.sha256((sys.argv[1]+chr(0)+sys.argv[2]).encode()).hexdigest())" p.py "$L")
expect rango_sin_hash_en_log 1 "allow-hash p.py:1" "$H" -- pre-commit --range HEAD~1..HEAD
expect allow_hash 0 "^$H  p.py:1\$" "" -- allow-hash p.py:1
python3 -c "import hashlib,sys;print(hashlib.sha256((sys.argv[1]+chr(0)+sys.argv[2]).encode()).hexdigest())" p2.py "$L" > .sdd-allowed-secrets; git add .sdd-allowed-secrets; git commit -qm "chore: permitidos"
expect rango_hash_en_el_mismo_rango 1 "PROBLEMA: .*p.py:1.*\.sdd-allowed-secrets" "" -- pre-commit --range HEAD~2..HEAD
expect rango_cambia_permitidos 1 "AVISO: cambia .sdd-allowed-secrets" "" -- pre-commit --range HEAD~2..HEAD
echo "$L" > p2.py; git add p2.py; git commit -qm "test: p2"
expect rango_permitido_con_hash_en_base 0 "AVISO: secreto probable permitido por .sdd-allowed-secrets.*p2.py:1" "PROBLEMA" -- pre-commit --range HEAD~1..HEAD
echo "$L" > p3.py; git add p3.py; git commit -qm "test: p3"
expect rango_hash_ligado_al_fichero 1 "PROBLEMA: .*p3.py:1.*\.sdd-allowed-secrets" "" -- pre-commit --range HEAD~1..HEAD
echo "$L" > p4.py; git add p4.py
expect local_permitido_no 0 "AVISO: secreto probable marcado como permitido .*p4.py:1" "PROBLEMA" -- pre-commit
git reset -q p4.py; rm -f p4.py; printf '%s\n%s\n' "$L" "$L" > p2.py; git add p2.py
expect local_lista_permitidos 0 "AVISO: secreto probable permitido por .sdd-allowed-secrets \(versión commiteada\) en p2.py:2" "PROBLEMA" -- pre-commit
git reset -q p2.py; git checkout -q -- p2.py
python3 -c "import hashlib,sys;print(hashlib.sha256((sys.argv[1]+chr(0)+sys.argv[2]).encode()).hexdigest())" q.py 'k2 = "AKIAABCDEFGHIJKLMNOS"' >> .sdd-allowed-secrets; git add .sdd-allowed-secrets; git commit -qm "chore: permitido el histórico de q (revisado)"
echo 'k2 = "AKIAABCDEFGHIJKLMNOS"' > q.py; git add q.py; git commit -qm "feat: q"; git rm -q q.py; git commit -qm "chore: quita q"
expect rango_historial_permitido 0 "AVISO: secreto probable permitido por .sdd-allowed-secrets.*q.py:1" "PROBLEMA" -- pre-commit --range HEAD~2..HEAD
echo 'k3 = "AKIAABCDEFGHIJKLMNOT"' > q.py; git add q.py; git commit -qm "feat: q3"; git rm -q q.py; git commit -qm "chore: quita q3"
expect rango_historial_sin_permiso 1 "PROBLEMA: secreto probable en q.py:1" "" -- pre-commit --range HEAD~2..HEAD
mkdir -p tests/fixtures; printf -- '-----BEGIN RSA PRIVATE KEY-----\nMIIEfixture\n' > tests/fixtures/server.key; git add tests; git commit -qm "test: fixture pem"
python3 -c "import hashlib,sys;print(hashlib.sha256((sys.argv[1]+chr(0)+sys.argv[2]).encode()).hexdigest())" tests/fixtures/server.key '-----BEGIN RSA PRIVATE KEY-----' >> .sdd-allowed-secrets; git add .sdd-allowed-secrets; git commit -qm "chore: permitido el fixture pem"
mkdir -p k8s; printf 'data: |\n  -----BEGIN RSA PRIVATE KEY-----\n' > k8s/tls.yaml; git add k8s; git commit -qm "feat: tls"
expect pem_no_generaliza 1 "PROBLEMA: secreto probable en k8s/tls.yaml:2" "" -- pre-commit --range HEAD~1..HEAD
echo 'db_password = "Pr0dS3cret!x"  # sdd-allow-secret' > g.py; git add g.py; git commit -qm "feat: g"
expect rango_generico_marcado 0 "PRE-COMMIT: OK" "Pr0dS3cret|PROBLEMA" -- pre-commit --range HEAD~1..HEAD
git rm -q g.py; git commit -qm "chore: quita g"
B0=$(git rev-parse HEAD); git checkout -qb rama; echo 'x = 1' > r.py; git add r.py; git commit -qm "feat: r"
git checkout -q -; git merge -q --no-ff --no-commit rama; printf 'k = "%s"\n' "ghp_a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6q7R8" > mg.py; git add mg.py; git commit -qm "merge rama"
expect secreto_en_merge 1 "PROBLEMA: secreto probable en mg.py:1" "" -- pre-commit --range "$B0..HEAD"
git rm -q mg.py; git commit -qm "chore: quita mg"

echo "· evidencia: Archivos frente a lo staged, código sin tests, tests sin aserciones"
rep "specs/010-gestión/tasks.md" "- [x] T-001 — ñ2" "- [x] T-001 — ñ2\n  - Tests requeridos: f (nivel: UNIT)"
rep "specs/010-gestión/tasks.md" "    - GREEN: x → 1/1" "    - GREEN: x → 1/1\n    - Archivos: otro.js"
printf 'export const f = 1\n' > src_mod.js; git add -A
expect archivos_no_citados 1 "PROBLEMA: ficheros staged no citados en «Archivos:» de T-001: src_mod.js" "" -- pre-commit --task T-001 --spec 010-gestión
expect codigo_sin_test 1 "AVISO: código staged sin ningún fichero de test" "" -- pre-commit --task T-001 --spec 010-gestión
rep "specs/010-gestión/tasks.md" "    - Archivos: otro.js" "    - Archivos: src_mod.js, mod.test.js"
printf 'test("a", () => { f() })\n' > mod.test.js; git add -A
expect test_sin_aserciones 0 "AVISO: mod.test.js declara tests sin ninguna aserción" "PROBLEMA|código staged sin" -- pre-commit --task T-001 --spec 010-gestión

echo
echo "RESULTADO: $PASS OK · $FAIL FALLOS · implementaciones: ${IMPLS[*]}"
[ "$FAIL" -eq 0 ]
