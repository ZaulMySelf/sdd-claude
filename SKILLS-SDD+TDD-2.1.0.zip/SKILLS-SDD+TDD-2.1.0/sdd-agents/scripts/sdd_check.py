#!/usr/bin/env python3
"""sdd-check — verificador determinista de artefactos SDD (sin dependencias; Python >= 3.8).

Port 1:1 de sdd-check.mjs: mismas reglas y misma salida (test-sdd-check.sh comprueba la paridad).
Uso (desde cualquier carpeta del repositorio):
  python3 <ruta>/sdd_check.py [status] [--spec NNN-slug] [--json]
  python3 <ruta>/sdd_check.py pre-commit [--task T-XXX | --bug BUG-NNN] [--spec NNN-slug]
  python3 <ruta>/sdd_check.py pre-commit --range <base>..<head>   (CI: los mismos detectores sobre una rama)
    (sin --task/--bug: commit genérico → solo lista staged y busca secretos)
Salida: 0 = OK · 1 = problemas que bloquean · 2 = error de uso o de entorno.
Lee solo cabeceras, veredictos, líneas de estado y el backlog; nunca modifica nada.
Se asume git para pre-commit y para detectar trabajo posterior a validation/release.
"""
import hashlib
import json
import os
import re
import subprocess
import sys

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except (AttributeError, ValueError):
    pass

KNOWN = {'spec.md', 'clarify.md', 'plan.md', 'migration-review.md', 'tasks.md',
         'tasks-archive.md', 'validation.md', 'release.md', 'bugs', 'assets', 'archive'}
VERDICTS = {
    'clarify.md': 'SPEC CLARIFICADA', 'migration-review.md': 'MIGRACIÓN', 'tasks.md': 'TRAZABILIDAD',
    'validation.md': 'SPEC CUMPLIDA', 'release.md': 'RELEASE',
}
OWN = {'sdd-validate': ('validation.md', ['SÍ', 'SI']), 'sdd-release': ('release.md', ['READY'])}
DERIVED = ['clarify.md', 'plan.md', 'migration-review.md', 'tasks.md', 'validation.md', 'release.md']
LIMITS = {'tasksBytes': 120_000, 'openTasks': 40, 'evidenceLines': 6, 'fullVerifyEvery': 5}
VERSION = '2.1.0'
CONVENTIONS = 3  # marcador mínimo «sdd-conventions: N» en AGENTS.md y docs/sdd-conventions.md
ROUTES = ['sdd-bug', 'sdd-change', 'sdd-refactor', 'sdd-plan', 'sdd-tasks', 'sdd-implement']
GLOBAL_ROUTES = ['sdd-bug', 'sdd-change', 'sdd-refactor', 'sdd-retro']
# Skills que pueden figurar como «Siguiente paso» de un artefacto (el orquestador no: se enrutaría a sí mismo).
STEPS = set(ROUTES) | {'sdd-migration', 'sdd-validate', 'sdd-release', 'sdd-agents', 'sdd-retro', 'sdd-spec', 'sdd-clarify', 'sdd-constitution'}

args = sys.argv[1:]
if '-h' in args or '--help' in args:
    print('uso: sdd-check [status] [--spec NNN-slug] [--json] | pre-commit [--task T-XXX | --bug BUG-NNN] [--spec NNN-slug] | pre-commit --range <base>..<head> | allow-hash <fichero>:<línea> | --version')
    sys.exit(0)
if '--version' in args:
    print('sdd-check ' + VERSION)
    sys.exit(0)
cmd = args.pop(0) if args and not args[0].startswith('--') else 'status'


def opt(name):
    if name in args:
        i = args.index(name)
        return args[i + 1] if i + 1 < len(args) else None
    return None


def flag(name):
    return name in args


GIT_CWD = [os.getcwd()]


def git(*a):
    # Bytes decodificados a mano: el modo texto de subprocess convierte cualquier \r en \n («universal newlines»),
    # lo que partiría una línea añadida con un \r suelto y ocultaría lo que sigue al escáner.
    return subprocess.run(['git', '-c', 'core.quotePath=false', *a], cwd=GIT_CWD[0], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          stdin=subprocess.DEVNULL, check=True).stdout.decode('utf-8', errors='replace')


def try_git(*a):
    try:
        return git(*a)
    except (subprocess.CalledProcessError, OSError):
        return None


root = (try_git('rev-parse', '--show-toplevel') or '').strip() or os.getcwd()
GIT_CWD[0] = root  # todas las rutas y pathspecs de git, relativas a la raíz del repo


def norm(t):
    return None if t is None else t.replace('\r\n', '\n').replace('\r', '\n')


def read(p):
    if not os.path.exists(p):
        return None
    with open(p, encoding='utf-8', errors='replace', newline='') as f:
        return norm(f.read())


def show(v):
    return '?' if v is None or v == '' else str(v)


def split_z(s):
    return [x for x in (s or '').split('\0') if x]


def header(text):
    out = {}
    if not text:
        return out
    for line in text.split('\n')[:40]:
        m = re.match(r'^\|\s*([^|]+?)\s*\|\s*([^|]*?)\s*\|\s*$', line)
        if m and not re.match(r'^-+$', m.group(1)) and m.group(1) != 'Campo':
            out[m.group(1)] = m.group(2)
        q = re.match(r'^(?:>\s*)?\**Estado\**:\s*\**\s*(\S+)', line)  # brief/constitution: «> Estado:» (o «Estado:» antiguo)
        if q:
            out['Estado'] = q.group(1)
    return out


def num(v):
    m = re.search(r'\d+', str(v if v is not None else ''))
    return int(m.group(0)) if m else None


def verdict(text, key):
    if not text:
        return None
    found = re.findall(r'^[>\-*\s]*\**' + re.escape(key) + r'\**\s*:\s*\**\s*([A-Za-zÁÉÍÓÚÑáéíóúñ]+)([^\n]*)', text, re.M | re.I)
    if not found:
        return None
    v, rest = found[-1]
    return None if '|' in rest else v.upper()  # la línea de plantilla «SÍ | NO» no es un veredicto


def declared_next(text):
    if not text:
        return None
    found = re.findall(r'Siguiente paso\**\s*:\**\s*[`*]*(sdd-[a-z]+)[`*]*(?:\s+[`*]*(T-\d+)[`*]*)?', text, re.I)
    if not found:
        return None
    skill, tarea = found[-1]
    return {'skill': skill, 'tarea': tarea or None}


def work_since(sha, own_rel, extra_excl=(), scope_id=None, with_refactor=False):
    # Modo amplio (scope_id None): código fuera de specs/ y la carpeta de la spec.
    # Modo de spec: solo commits con «(<scope_id>)» en el asunto o que tocan la carpeta de la spec.
    base = (try_git('log', '-1', '--format=%H', '--', own_rel) or '').strip() or sha
    if not base:
        return None
    spec_dir = '/'.join(own_rel.split('/')[:2])
    out = try_git('log', '--format=%x01%s', '--name-only', '%s..HEAD' % base, '--', '.', ':(exclude)%s' % own_rel, ':(exclude)docs', ':(exclude)reviews', ':(exclude)AGENTS.md', *[':(exclude)%s' % x for x in extra_excl])
    if out is None:
        return None
    for block in out.split('\x01')[1:]:
        parts = [x.strip() for x in block.split('\n') if x.strip()]
        if not parts:
            continue
        subject, files = parts[0], parts[1:]
        if re.search(r'\bre-?sell(a|ado|os|ar)?\b|decisión de tamaño', subject, re.I):
            continue
        in_spec = any(f.startswith(spec_dir + '/') for f in files)
        if (in_spec or '(%s)' % scope_id in subject or (with_refactor and re.match(r'^refactor\b', subject, re.I))) if scope_id else (in_spec or any(not f.startswith('specs/') for f in files)):
            return True
    return False


def last_commit(rel):
    return (try_git('log', '-1', '--format=%H', '--', rel) or '').strip() or None


def newer(a, b):
    return bool(a and b and a != b and try_git('merge-base', '--is-ancestor', a, b) is not None)


def indent_of(s):
    return len(s) - len(s.lstrip())


def parse_tasks(text):
    tasks, cur, bad = [], None, []
    for i, line in enumerate((text or '').split('\n')):
        m = re.match(r'^[-*]\s+\[( |x|X)\]\s+[`*]*(T-\d+)\b', line, re.A)
        if m:
            cur = {'id': m.group(2), 'done': m.group(1) != ' ', 'line': i + 1, 'body': []}
            tasks.append(cur)
            continue
        if re.match(r'^[-*]\s*\[[ xX]?\]', line) and re.search(r'T-\d', line):
            bad.append(i + 1)
        if re.match(r'^#{1,3} ', line):
            cur = None
            continue
        if cur is not None:
            cur['body'].append(line)
    for t in tasks:
        body = '\n'.join(t['body'])
        dep = re.search(r'Depende de:\s*([^\n]*)', body)
        t['deps'] = re.findall(r'T-\d+', dep.group(1), re.A) if dep else []
        t['requiresUser'] = bool(re.search(r'Requiere usuario\**\s*:\**\s*S[IÍ]', body, re.I))
        t['reopened'] = bool(re.search(r'^\s*[-*]\s+\**Reabierta\**\s*:', body, re.M | re.I))
        bl_line = re.search(r'^\s*(?:[-*]\s+)?\**Bloqueada\**:\**\s*(.*)$', body, re.M)
        bl = bl_line and re.match(r'^(.*?)\s*(?:→|->)\s*`?(sdd-[a-z]+)`?', bl_line.group(1))
        esp = bl_line and re.search(r'espera a\s+`?(\d{3}-[A-Za-z0-9_\u00C0-\uFFFF-]+)', bl_line.group(1))
        if bl:
            t['blocked'] = {'motivo': bl.group(1), 'skill': bl.group(2)}
        elif esp:
            t['blocked'] = {'motivo': 'espera a %s' % esp.group(1), 'skill': None, 'espera': esp.group(1)}
        elif bl_line:
            t['blocked'] = {'motivo': bl_line.group(1), 'skill': None, 'invalida': True}
        else:
            t['blocked'] = None
        ev_idx = next((k for k, l in enumerate(t['body']) if re.match(r'^\s*[-*]\s+\**Evidencia\b', l, re.I)), -1)
        t['hasEvidenceLine'] = ev_idx >= 0
        ev_head = t['body'][ev_idx] if ev_idx >= 0 else ''
        t['evidencePending'] = bool(re.search(
            r'Evidencia(\s*\(T-\d+\))?\s*\**\s*:\s*\**\s*(pendiente|\(la añade sdd-implement\))[\s.*]*$', ev_head.strip(), re.I))
        t['evidenceMarkerUnique'] = t['id'] in ev_head
        hm = re.search(r'Evidencia[^:]*:\s*(.*)$', ev_head)
        head_rest = hm.group(1) if hm else ''
        ev = []
        if ev_idx >= 0:
            ind = indent_of(ev_head)
            for l in t['body'][ev_idx + 1:]:
                if not l.strip() or indent_of(l) <= ind:
                    break
                ev.append(l)
        t['evidenceLines'] = len(ev) + (1 if head_rest.strip() and not t['evidencePending'] else 0)
        t['fullVerify'] = bool(re.search(r'Verificación completa', '\n'.join([head_rest] + ev), re.I))
    return tasks, bad


def backlog_rows():
    t = read(os.path.join(root, 'reviews', 'backlog.md'))
    if not t:
        return None
    rows = []
    for l in t.split('\n'):
        if not re.match(r'^\|\s*R-\d+', l):
            continue
        s = l.strip()
        s = s[1:] if s.startswith('|') else s
        s = s[:-1] if s.endswith('|') else s
        c = [x.strip() for x in re.split(r'(?<!\\)\|', s)]
        rid = c[0]
        if len(c) < 8:
            rows.append({'id': rid, 'malformada': True})
            continue
        ruta = c[-2]
        rm = re.search(r'sdd-[a-z]+', ruta)
        tm = re.search(r'T-\d+', ruta)
        row = {'id': rid, 'severidad': c[2].upper(), 'spec': c[-3], 'rutaTexto': ruta, 'ruta': rm.group(0) if rm else '',
               'tarea': tm.group(0) if tm else None, 'estado': c[-1].upper()}
        row['global'] = bool(re.match(r'^(—|–|-|global)$', row['spec'], re.I))
        rows.append(row)
    return rows


def is_open(x):
    return not x.get('malformada') and bool(re.match(r'^ABIERTO\b', x['estado']))


def is_high(x):
    return bool(re.search(r'CR[IÍ]TIC[AO]|ALT[AO]', x['severidad']))


def classify_backlog(rows, existing):
    # Una fila que no se puede clasificar nunca deja de bloquear: las de Spec o Severidad ilegibles
    # (y las mal formadas) son «sin dueño» y bloquean validate y release de todas las specs.
    for row in rows or []:
        if row.get('malformada') or not re.match(r'^ABIERTO\b', row['estado']):
            continue
        nnns = re.findall(r'(?<![-\w])\d{3}\b', row['spec'])
        if not re.match(r'^(CR[IÍ]TIC[AO]|ALT[AO]|MEDI[AO]|BAJ[AO])\b', row['severidad']):
            row['error'] = 'con Severidad no válida («%s»): CRÍTICO, ALTO, MEDIO o BAJO' % row['severidad']
            row['sinDueno'] = True
        elif not row['global'] and (not re.match(r'^\d{3}\b', row['spec']) or len(nnns) != 1 or not any(d.startswith(nnns[0] + '-') for d in existing)):
            row['error'] = 'con Spec no válida («%s»): NNN [Req] de una spec existente, o — si es global' % row['spec']
            row['sinDueno'] = True
        elif row['ruta'] not in (GLOBAL_ROUTES if row['global'] else ROUTES) or (row['ruta'] == 'sdd-implement' and not row['tarea']) or (row['global'] and row['tarea']):
            row['error'] = 'con Ruta no válida («%s»): %s' % (row['rutaTexto'], 'en una fila global (Spec —) sdd-bug, sdd-change, sdd-refactor o sdd-retro' if row['global'] else 'sdd-bug, sdd-change, sdd-refactor, sdd-plan, sdd-tasks o sdd-implement T-XXX')


def after_neg(r):
    # ¿Hay un veredicto negativo vigente de validate o release? (lo que sigue no debe heredar código sin commitear)
    return any((r['artefactos'].get(f) or {}).get('estado') == 'VIGENTE' and r['artefactos'][f].get('veredicto') is not None
               and r['artefactos'][f].get('veredicto') not in ('SÍ', 'SI', 'READY') for f in ('validation.md', 'release.md'))


def unowned(rows):
    return [x for x in (rows or []) if x.get('malformada') or (is_open(x) and x.get('sinDueno'))]


def block_step(x):
    # Una fila con formato no válido bloquea igual (no se pierde un CRÍTICO), pero enruta a corregir su formato.
    if x.get('error') or x.get('malformada'):
        return {'id': x['id'], 'severidad': x.get('severidad') or '?', 'ruta': 'sdd-review', 'tarea': None, 'global': bool(x.get('global')), 'formato': True}
    return {'id': x['id'], 'severidad': x['severidad'], 'ruta': x['ruta'], 'tarea': x['tarea'], 'global': x['global'], 'formato': False}


def block_motivo(b, extra):
    return '%s %s ABIERTO%s%s' % (b['id'], b['severidad'], extra, ' (formato no válido → sdd-review modo formato)' if b['formato'] else '')


def analyze_spec(d, rows, done_specs=frozenset(), existing=frozenset()):
    def p(f):
        return os.path.join(d, f)
    spec = read(p('spec.md'))
    sh = header(spec)
    spec_v = num(sh.get('Versión', sh.get('Version')))
    sid = os.path.basename(d)
    body = re.split(r'^## Registro de cambios', spec, maxsplit=1, flags=re.M)[0] if spec else ''
    r = {'spec': sid, 'specVersion': spec_v, 'estado': sh.get('Estado'),
         'aprobacion': sh.get('Aprobación'), 'tamano': sh.get('Tamaño'), 'origen': sh.get('Origen'),
         'dependeDe': re.findall(r'\d{3}-[A-Za-z0-9_\u00C0-\uFFFF-]+', sh.get('Depende de') or ''),
         'pendientesAclaracion': len(re.findall(r'\[NECESITA ACLARACIÓN:', body)),
         'retroDefecto': '(defecto)' in body,
         'retroPendiente': (re.search(r'^\s*(?:[-*]\s+)?\**Pendiente\**:\**\s*`?(sdd-retro|sdd-bug|sdd-change)\b', body, re.M) or [None, None])[1],
         'artefactos': {}, 'problemas': [], 'avisos': [], 'tareas': None, 'completada': False}
    if not spec:
        r['problemas'].append({'msg': 'falta spec.md', 'skill': 'sdd-spec'})
        r['siguiente'] = {'skill': 'sdd-spec', 'motivo': 'falta spec.md'}
        return r
    for k in ['Spec-ID', 'Versión', 'Estado', 'Aprobación', 'Tamaño', 'Interfaz', 'Origen']:
        if k not in sh:
            r['avisos'].append('spec.md: cabecera sin «%s»' % k)
    if spec_v is None:
        r['problemas'].append({'msg': 'spec.md sin «Versión» en la cabecera', 'skill': 'sdd-clarify'})
    ph = header(read(p('plan.md')))
    plan_v = num(ph.get('Plan-Version'))
    r['planVersion'] = plan_v
    r['migracionRequerida'] = bool(re.match(r'^S[IÍ]', ph.get('Migración requerida') or '', re.I))
    r['planAprobacion'] = ph.get('Aprobación')
    for f in DERIVED:
        t = read(p(f))
        if t is None:
            r['artefactos'][f] = {'estado': 'AUSENTE'}
            continue
        h = header(t)
        sv = num(h.get('Spec-Version'))
        pv = None if f in ('plan.md', 'clarify.md') else num(h.get('Plan-Version'))
        estado = 'VIGENTE'
        if sv is None:
            estado = 'SIN-VERSIÓN'
            r['avisos'].append('%s: cabecera sin Spec-Version (se trata como caducado: la skill dueña re-sella)' % f)
        elif spec_v is not None and sv != spec_v:
            estado = 'CADUCADO'
        if estado == 'VIGENTE' and f not in ('plan.md', 'clarify.md') and plan_v is not None and pv is None:
            estado = 'SIN-VERSIÓN'
            r['avisos'].append('%s: cabecera sin Plan-Version (se trata como caducado: la skill dueña re-sella)' % f)
        if estado == 'VIGENTE' and pv is not None and plan_v is not None and pv != plan_v:
            estado = 'CADUCADO'
        cm = re.search(r'\b[0-9a-f]{7,40}\b', str(h.get('Commit') or ''))
        r['artefactos'][f] = {'estado': estado, 'specVersion': sv, 'planVersion': pv,
                              'veredicto': verdict(t, VERDICTS[f]) if f in VERDICTS else None,
                              'siguienteDeclarado': declared_next(t), 'commit': cm.group(0) if cm else None,
                              'adopcion': bool(re.match(r'^ADOPCI[OÓ]N', str(h.get('Evidencia') or ''), re.I) or re.search(r'^\s*(?:[-*]\s+)?\**Evidencia\**:\**\s*ADOPCI[OÓ]N', t, re.I | re.M))}
    for f in sorted(os.listdir(d)):
        if f not in KNOWN and not f.startswith('.'):
            r['avisos'].append('artefacto no reconocido por el flujo: %s (intégralo con sdd-change o sdd-release lo archiva)' % f)
    tt = read(p('tasks.md'))
    for mv in re.findall(r'movido a\s+`?(\d{3}-[A-Za-z0-9_\u00C0-\uFFFF-]+)', body):
        if existing and mv not in existing:
            r['problemas'].append({'msg': 'RF movido a %s, que no existe: créala' % mv, 'skill': 'sdd-spec'})
    ra = r['artefactos'].get('release.md') or {}
    adopted = ra.get('estado') == 'VIGENTE' and ra.get('adopcion')
    if tt and not adopted:
        tasks, bad_lines = parse_tasks(tt)
        for ln in bad_lines:
            r['problemas'].append({'msg': 'tasks.md:%d: línea de tarea ilegible (formato: «- [ ] T-NNN — objetivo»)' % ln, 'skill': 'sdd-tasks'})
        for t in tasks:
            e = (t['blocked'] or {}).get('espera')
            if e and e in done_specs:
                r['avisos'].append('%s: %s ya está completada; quita la línea «Bloqueada: espera a %s»' % (t['id'], e, e))
                t['blocked'] = None
            elif e and existing and e not in existing:
                r['problemas'].append({'msg': '%s espera a %s, que no existe: créala' % (t['id'], e), 'skill': 'sdd-spec'})
        archived = {t['id'] for t in parse_tasks(read(p('tasks-archive.md')))[0] if t['done']}
        ids = {}
        for t in tasks:
            if t['id'] in ids:
                r['problemas'].append({'msg': '%s duplicada (líneas %s y %s)' % (t['id'], ids[t['id']], t['line']), 'skill': 'sdd-tasks'})
            ids[t['id']] = t['line']
            if t['id'] in archived:
                r['problemas'].append({'msg': '%s está también en tasks-archive.md: las archivadas no se reabren, crea una tarea nueva' % t['id'], 'skill': 'sdd-tasks'})
            if t['done'] and (not t['hasEvidenceLine'] or t['evidencePending'] or t['evidenceLines'] == 0):
                r['problemas'].append({'msg': '%s marcada [x] sin evidencia' % t['id'], 'skill': 'sdd-implement', 'tarea': t['id'], 'modo': 're-sellado'})
            if not t['done'] and t['hasEvidenceLine'] and not t['evidencePending']:
                if t['reopened']:
                    r['problemas'].append({'msg': '%s reabierta con evidencia antigua: sustituye la evidencia por el marcador pendiente e implementa' % t['id'], 'skill': 'sdd-implement', 'tarea': t['id']})
                else:
                    r['problemas'].append({'msg': '%s pendiente con evidencia escrita (¿falta marcar [x] o reabrir?)' % t['id'], 'skill': 'sdd-implement', 'tarea': t['id'], 'modo': 're-sellado'})
            if not t['done'] and not t['evidenceMarkerUnique']:
                r['avisos'].append('%s: marcador de evidencia no único (usa «Evidencia (%s): pendiente»)' % (t['id'], t['id']))
            if t['done'] and t['evidenceLines'] > LIMITS['evidenceLines']:
                r['avisos'].append('%s: evidencia de %d líneas (máx. %d)' % (t['id'], t['evidenceLines'], LIMITS['evidenceLines']))
        r['_ids'] = {t['id'] for t in tasks}
        r['_arch'] = set(archived)
        done = set(archived) | {t['id'] for t in tasks if t['done']}
        pending = [t for t in tasks if not t['done']]
        for t in [x for x in pending if x['blocked'] and x['blocked'].get('invalida')]:
            r['problemas'].append({'msg': '%s: línea Bloqueada sin destino legible (formato: «Bloqueada: <motivo> → <skill>» o «Bloqueada: espera a NNN-slug»)' % t['id'], 'skill': 'sdd-tasks'})
        blocked_t = next((t for t in pending if t['blocked'] and t['blocked'].get('skill') and re.search(r'fallo compartido', t['blocked']['motivo'], re.I)), None) or next((t for t in pending if t['blocked'] and t['blocked'].get('skill')), None)
        ready = [t for t in pending if not t['blocked'] and all(x in done for x in t['deps'])]
        nxt = next((t for t in ready if not t['requiresUser']), ready[0] if ready else None)
        since = 0
        for t in tasks:
            if t['done']:
                since = 0 if t['fullVerify'] else since + 1
        r['tareas'] = {'total': len(tasks), 'hechas': sum(1 for t in tasks if t['done']), 'archivadas': len(archived),
                       'pendientes': len(pending), 'siguiente': nxt['id'] if nxt else None,
                       'siguienteRequiereUsuario': bool(nxt and nxt['requiresUser']),
                       'esperanUsuario': [t['id'] for t in ready if t['requiresUser']],
                       'bloqueadas': [t['id'] for t in pending] if pending and not nxt else [],
                       'desdeTodo': since, 'pedirTodo': since >= LIMITS['fullVerifyEvery'],
                       'bloqueada': {'tarea': blocked_t['id'], 'skill': blocked_t['blocked']['skill'], 'motivo': blocked_t['blocked']['motivo']} if blocked_t else None,
                       'esperanSpec': ['%s→%s' % (t['id'], t['blocked']['espera']) for t in pending if t['blocked'] and t['blocked'].get('espera')]}
        size = os.path.getsize(p('tasks.md'))
        if size > LIMITS['tasksBytes']:
            r['avisos'].append('tasks.md ocupa %d KB: lo archiva sdd-release al cerrar el ciclo; si no hay ciclo cerrado, valora partir la spec' % int(size / 1024 + 0.5))
        if len(pending) > LIMITS['openTasks']:
            r['avisos'].append('%d tareas abiertas (> %d): valora partir la spec' % (len(pending), LIMITS['openTasks']))
    nnn = sid[:3]
    mine = [x for x in (rows or []) if is_open(x) and not x['global'] and not x.get('sinDueno') and x['spec'].startswith(nnn)]
    # Ruta hacia una tarea: archivada → sdd-tasks crea la sustituta; inexistente → la Ruta se corrige (formato).
    ids, arch = r.pop('_ids', None), r.pop('_arch', None)
    for x in [y for y in mine if y['ruta'] == 'sdd-implement' and y['tarea'] and ids is not None]:
        if x['tarea'] in arch and x['tarea'] not in ids:
            x['ruta'], x['tarea'] = 'sdd-tasks', None
        elif x['tarea'] not in ids:
            msg = 'backlog: %s apunta a %s, que no existe en %s: corrige su Ruta' % (x['id'], x['tarea'], sid)
            if is_high(x):
                r['problemas'].append({'msg': msg, 'skill': 'sdd-review'})
            else:
                r['avisos'].append(msg)  # MEDIO/BAJO no interrumpen la cadena
    r['backlogBloqueante'] = [block_step(x) for x in mine if is_high(x)]
    r['siguiente'] = next_step(r, d)
    gate = r['siguiente']['skill'] in ('sdd-validate', 'sdd-release')
    un = unowned(rows)
    # Hallazgos CRÍTICO/ALTO globales (Spec —, p. ej. código compartido): no reabren specs completadas, pero bloquean todo release.
    g = next((x for x in (rows or []) if is_open(x) and is_high(x) and x['global']), None)
    if un and gate:
        r['siguiente'] = {'skill': 'sdd-review', 'tarea': None, 'motivo': block_motivo(block_step(un[0]), ' (sin spec reconocible) bloquea validate y release')}
    elif g and r['siguiente']['skill'] == 'sdd-release':
        b = block_step(g)
        r['siguiente'] = {'skill': b['ruta'], 'tarea': b['tarea'], 'motivo': block_motivo(b, ' (global) bloquea el release')}
    elif (gate or (after_neg(r) and r['siguiente']['skill'])) and DIRTY:
        r['siguiente'] = {'skill': None, 'motivo': 'requiere acción: código o tareas sin commitear (%s): commitearlos con su skill, aparcarlos o descartarlos' % ', '.join(DIRTY[:5])}
    r['completada'] = r['siguiente']['skill'] is None and 'completada' in r['siguiente']['motivo']
    return r


def after_negative(r, d, f, skill, label):
    art = r['artefactos'][f]
    rel = os.path.relpath(os.path.join(d, f), root).replace('\\', '/')
    changed = work_since(art.get('commit'), rel, [], r['spec'] if f == 'validation.md' else None, True)
    if changed is True:
        return {'skill': skill, 'motivo': '%s y hay trabajo commiteado posterior a la última ejecución: repetir' % label}
    dn = art.get('siguienteDeclarado')
    own = OWN.get(dn['skill']) if dn else None
    satisfied = bool(own and r['artefactos'].get(own[0], {}).get('estado') == 'VIGENTE'
                     and r['artefactos'][own[0]].get('veredicto') in own[1])
    if dn and dn['skill'] in STEPS and dn['skill'] != skill and not satisfied:
        return {'skill': dn['skill'], 'tarea': dn.get('tarea'), 'motivo': '%s: siguiente paso declarado en el artefacto' % label}
    return {'skill': None, 'motivo': '%s: requiere acción (sin siguiente paso aplicable ni trabajo posterior a la última ejecución)' % label}


def next_step(r, d):
    a = r['artefactos']

    def vig(f):
        return f in a and a[f]['estado'] == 'VIGENTE'
    cl = next((p for p in r['problemas'] if p['skill'] == 'sdd-clarify'), None)
    if cl:
        return {'skill': 'sdd-clarify', 'motivo': cl['msg']}
    def rel(f):
        return os.path.relpath(os.path.join(d, f), root).replace('\\', '/')
    blk = r['backlogBloqueante'][0] if r['backlogBloqueante'] else None
    blk_step = {'skill': blk['ruta'], 'tarea': blk['tarea'], 'motivo': block_motivo(blk, ' en el backlog')} if blk else None
    if re.match(r'^RETRO', r['origen'] or '', re.I) and r['specVersion'] == 1 and re.match(r'^APROBADA\b', r['estado'] or '') and a['plan.md']['estado'] == 'AUSENTE':
        if r['retroDefecto']:
            return {'skill': 'sdd-bug', 'motivo': 'spec RETRO con RF marcados (defecto)'}
        if r['retroPendiente']:
            return {'skill': r['retroPendiente'], 'motivo': 'spec RETRO aprobada con pedido pendiente (Pendiente: en la spec)'}
        return blk_step or {'skill': None, 'motivo': 'spec RETRO completada'}
    spec_prob = next((p for p in r['problemas'] if p['skill'] == 'sdd-spec'), None)
    if spec_prob:
        return {'skill': 'sdd-spec', 'motivo': spec_prob['msg']}
    if vig('release.md') and a['release.md'].get('adopcion') and a['release.md'].get('veredicto') != 'READY':
        if blk_step:
            return blk_step
        if newer(last_commit(rel('release.md')), last_commit(rel('bugs'))):
            return {'skill': 'sdd-release', 'motivo': 'adopción BLOCKED y bug corregido después: repetir el release de adopción'}
        dn = a['release.md'].get('siguienteDeclarado')
        if dn and dn['skill'] != 'sdd-release' and dn['skill'] in STEPS:
            return {'skill': dn['skill'], 'tarea': dn.get('tarea'), 'motivo': 'RELEASE de adopción BLOCKED: siguiente paso declarado'}
        return {'skill': None, 'motivo': 'RELEASE de adopción BLOCKED: requiere acción'}
    if vig('release.md') and a['release.md'].get('adopcion') and a['release.md'].get('veredicto') == 'READY':
        if blk_step:
            return blk_step
        rel_a = last_commit(rel('release.md'))
        if newer(rel_a, last_commit(rel('bugs'))):
            return {'skill': 'sdd-release', 'motivo': 'bug corregido en una spec adoptada: nuevo release de adopción (con la fila Todo)'}
        if work_since(None, rel('release.md'), [], r['spec']) is not True:
            return {'skill': None, 'motivo': 'spec completada (adopción, RELEASE: READY vigente)'}
    if (not re.match(r'^APROBADA\b', r['estado'] or '') or 'APROBADA' not in (r['aprobacion'] or '') or r['pendientesAclaracion'] > 0
            or not vig('clarify.md') or a['clarify.md'].get('veredicto') not in ('SÍ', 'SI')):
        return {'skill': 'sdd-clarify', 'motivo': 'spec no aprobada, con dudas o clarify ausente/caducado/sin versión/NO'}
    if not vig('plan.md') or 'PENDIENTE' in (r['planAprobacion'] or ''):
        return {'skill': 'sdd-plan', 'motivo': 'plan ausente, caducado, sin versión o pendiente de aprobación'}
    if r['migracionRequerida']:
        if not vig('migration-review.md'):
            return {'skill': 'sdd-migration', 'motivo': 'migración requerida sin revisión vigente'}
        if a['migration-review.md'].get('veredicto') is None:
            return {'skill': 'sdd-migration', 'motivo': 'migration-review.md sin veredicto (heredado)'}
        if a['migration-review.md'].get('veredicto') != 'SUFICIENTE':
            return {'skill': 'sdd-plan', 'motivo': 'MIGRACIÓN: INCOMPLETA — completar §10 (sube Plan-Version)'}
    if not vig('tasks.md'):
        return {'skill': 'sdd-tasks', 'motivo': 'tasks.md ausente, caducado o sin versión'}
    if a['tasks.md'].get('veredicto') is None:
        return {'skill': 'sdd-tasks', 'motivo': 'tasks.md sin veredicto TRAZABILIDAD (heredado): auditar la trazabilidad y emitirlo'}
    if a['tasks.md'].get('veredicto') != 'PASS':
        dn = a['tasks.md'].get('siguienteDeclarado')
        return {'skill': 'sdd-change' if dn and dn['skill'] == 'sdd-change' else 'sdd-plan',
                'motivo': 'TRAZABILIDAD: FAIL (la skill de destino sube su versión, lo que regenera tasks)'}
    if r['problemas']:
        p = r['problemas'][0]
        extra = (' — modo %s: re-ejecuta sus tests y sella la evidencia sin cambiar código si pasan' % p['modo']) if p.get('modo') else ''
        return {'skill': p['skill'], 'tarea': p.get('tarea'), 'motivo': p['msg'] + extra}
    if r['tareas'] and r['tareas']['bloqueada'] and (re.search(r'fallo compartido', r['tareas']['bloqueada']['motivo'], re.I) or not (r['tareas']['siguiente'] and not r['tareas']['siguienteRequiereUsuario'])):
        b = r['tareas']['bloqueada']
        return {'skill': b['skill'], 'tarea': b['tarea'] if b['skill'] == 'sdd-implement' else None, 'motivo': '%s bloqueada: %s' % (b['tarea'], b['motivo'])}
    if r['tareas'] and r['tareas']['pendientes']:
        if not r['tareas']['siguiente'] and r['tareas']['esperanSpec']:
            return {'skill': None, 'motivo': 'tareas esperando a otra spec: ' + ', '.join(r['tareas']['esperanSpec'])}
        if not r['tareas']['siguiente']:
            return {'skill': 'sdd-tasks', 'motivo': 'pendientes con dependencias no resolubles: ' + ', '.join(r['tareas']['bloqueadas'])}
        return {'skill': 'sdd-implement', 'tarea': r['tareas']['siguiente'],
                'motivo': '%d tareas pendientes%s%s' % (r['tareas']['pendientes'],
                                                        ' — REQUIERE USUARIO (no lanzar sin él)' if r['tareas']['siguienteRequiereUsuario'] else '',
                                                        ' — pedir verificación completa (fila Todo)' if r['tareas']['pedirTodo'] else '')}
    if r['backlogBloqueante']:
        b = r['backlogBloqueante'][0]
        return {'skill': b['ruta'], 'tarea': b['tarea'], 'motivo': block_motivo(b, ' en el backlog (bloquea validate)')}
    if not vig('validation.md'):
        return {'skill': 'sdd-validate', 'motivo': 'validación ausente, caducada o sin versión'}

    bug_c = last_commit(rel('bugs'))
    val_c = last_commit(rel('validation.md'))
    rel_c = last_commit(rel('release.md'))
    if a['validation.md'].get('veredicto') in ('SÍ', 'SI'):
        if newer(val_c, bug_c):
            return {'skill': 'sdd-validate', 'motivo': 'bug corregido después de la validación: repetir'}
        after_rel = newer(val_c, rel_c)
        if work_since(None, rel('release.md') if after_rel else rel('validation.md'), [rel('validation.md') if after_rel else rel('release.md')], r['spec']) is True:
            return {'skill': 'sdd-validate', 'motivo': 'trabajo commiteado posterior a la validación: repetir'}
    if a['validation.md'].get('veredicto') not in ('SÍ', 'SI'):
        if a['validation.md'].get('veredicto') is None:
            return {'skill': 'sdd-validate', 'motivo': 'validation.md sin veredicto (heredado)'}
        return after_negative(r, d, 'validation.md', 'sdd-validate', 'SPEC CUMPLIDA: NO')
    if not vig('release.md'):
        return {'skill': 'sdd-release', 'motivo': 'release ausente, caducado o sin versión'}
    if a['release.md'].get('veredicto') != 'READY':
        if a['release.md'].get('veredicto') is None:
            return {'skill': 'sdd-release', 'motivo': 'release.md sin veredicto (heredado)'}
        return after_negative(r, d, 'release.md', 'sdd-release', 'RELEASE: BLOCKED')
    if newer(rel_c, bug_c):
        return {'skill': 'sdd-release', 'motivo': 'bug corregido después del release: nuevo release'}
    if newer(rel_c, val_c):
        return {'skill': 'sdd-release', 'motivo': 'validación posterior al release: nuevo release'}
    return {'skill': None, 'motivo': 'spec completada (RELEASE: READY vigente)'}


def project(rows, n_specs):
    res = {'problemas': [], 'avisos': []}
    if not os.path.exists(os.path.join(root, 'docs/brief.md')):
        res['siguiente'] = {'skill': 'sdd-init', 'motivo': 'falta docs/brief.md'}
    elif not (header(read(os.path.join(root, 'docs/constitution.md'))).get('Estado') or '').startswith('APROBADA'):
        res['siguiente'] = {'skill': 'sdd-constitution', 'motivo': 'constitution ausente o no APROBADA'}
    elif not os.path.exists(os.path.join(root, 'AGENTS.md')):
        res['siguiente'] = {'skill': 'sdd-agents', 'motivo': 'falta AGENTS.md'}
    elif not ((lambda m: m is not None and num(m.group(0)) >= CONVENTIONS)(re.search(r'sdd-conventions:\s*\d+', read(os.path.join(root, 'AGENTS.md')) or ''))):
        res['siguiente'] = {'skill': 'sdd-agents', 'motivo': 'AGENTS.md sin las Convenciones SDD actuales (marcador sdd-conventions: %d)' % CONVENTIONS}
    elif not ((lambda m: m is not None and num(m.group(0)) >= CONVENTIONS)(re.search(r'sdd-conventions:\s*\d+', read(os.path.join(root, 'docs/sdd-conventions.md')) or ''))):
        res['siguiente'] = {'skill': 'sdd-agents', 'motivo': 'falta docs/sdd-conventions.md o es de otra versión (marcador sdd-conventions: %d)' % CONVENTIONS}
    elif n_specs == 0:
        res['siguiente'] = {'skill': 'sdd-spec', 'motivo': 'no hay specs: describe una funcionalidad'}
    sec_row = next((l for l in (read(os.path.join(root, 'AGENTS.md')) or '').split('\n') if re.match(r'^\|\s*Seguridad', l, re.I)), None)
    mf = ['package.json', 'requirements.txt', 'pyproject.toml', 'Pipfile', 'go.mod', 'Cargo.toml', 'Gemfile', 'pom.xml', 'build.gradle', 'composer.json']
    manif = []
    # también en monorepos (versionados, fuera de dependencias instaladas)
    for f in [x for x in mf if os.path.exists(os.path.join(root, x))] + [x for x in split_z(try_git('ls-files', '-z')) if x.split('/')[-1] in mf and not re.search(r'(^|/)(node_modules|vendor)/', x)]:
        if f not in manif:
            manif.append(f)
    manif = manif[:5]
    sd = os.path.join(root, 'specs')
    if os.path.isdir(sd):
        for dd in os.listdir(sd):
            if not re.match(r'^\d{3}-', dd) and not dd.startswith('.') and os.path.isdir(os.path.join(sd, dd)):
                res['avisos'].append('specs/%s no sigue el formato NNN-slug y se ignora (renómbrala para incluirla en el flujo)' % dd)
    if sec_row and re.search(r'no disponible|pendiente', sec_row, re.I) and manif:
        res['avisos'].append('la fila Seguridad de AGENTS.md no tiene comando real pero hay manifiesto de dependencias (%s): actívala si hay dependencias de runtime (la tarea que las introduce, o sdd-agents)' % ', '.join(manif))
    if not os.path.exists(os.path.join(root, 'docs/agent-runbook.md')):
        res['avisos'].append('falta docs/agent-runbook.md (conocimiento operativo versionado; ver sdd-agents)')
    last_rel = (try_git('log', '-1', '--format=%H', '--', 'specs/*/release.md') or '').strip()
    if last_rel:
        subj = [x for x in (try_git('log', '--format=%s', '%s..HEAD' % last_rel, '--', '.', ':(exclude)specs', ':(exclude)docs', ':(exclude)reviews', ':(exclude)AGENTS.md') or '').split('\n') if x]
        loose = [x for x in subj if not re.search(r'\(\d{3}-[^)]*\)', x) and not re.match(r'^(refactor|docs|test|chore)\b', x)]
        if loose:
            res['avisos'].append('%d commit(s) de código posteriores al último release sin spec ni refactor (p. ej. «%s»): ¿pasan por sdd-bug, sdd-change o sdd-refactor?' % (len(loose), loose[0][:60]))
    for x in [y for y in (rows or []) if y.get('malformada')]:
        res['problemas'].append('backlog: fila %s mal formada (se esperan 8 columnas: ID|Fecha|Severidad|Tipo|Hallazgo|Spec|Ruta|Estado) → corrige su formato (quien la escribió o sdd-review en modo formato)' % x['id'])
    for x in [y for y in (rows or []) if y.get('error')]:
        res['problemas'].append('backlog: fila %s %s → corrige su formato (quien la escribió o sdd-review en modo formato)' % (x['id'], x['error']))
    return res


def dirty_files():
    # «Árbol limpio» de AGENTS.md › Commits: cuentan el código, tasks.md y BUG-NNN.md; el resto de specs/, docs/, reviews/ y AGENTS.md, no.
    changed = split_z(try_git('diff', '--name-only', '-z', 'HEAD')) + split_z(try_git('ls-files', '--others', '--exclude-standard', '-z'))
    return sorted({f for f in changed if not (re.match(r'^(specs|docs|reviews)/', f) and not re.match(r'^specs/[^/]+/(tasks\.md|bugs/BUG-[^/]*\.md)$', f)) and f != 'AGENTS.md'})


DIRTY = []


def status():
    global DIRTY
    rows = backlog_rows()
    specs_dir = os.path.join(root, 'specs')
    only = opt('--spec')
    alls = sorted(d for d in os.listdir(specs_dir) if re.match(r'^\d{3}-', d) and os.path.isdir(os.path.join(specs_dir, d))) if os.path.isdir(specs_dir) else []
    existing = frozenset(alls)
    classify_backlog(rows, existing)
    DIRTY = dirty_files()
    proj = project(rows, len(alls))
    first = [analyze_spec(os.path.join(specs_dir, d), rows, frozenset(), existing) for d in alls]
    done_set = frozenset(r['spec'] for r in first if r['completada'])
    results = [analyze_spec(os.path.join(specs_dir, d), rows, done_set, existing) for d in alls]
    by_id = {r['spec']: r for r in results}
    for r in results:
        waits = [x.split('→')[1] for x in ((r['tareas'] or {}).get('esperanSpec') or [])]
        r['esperaA'] = [d for d in dict.fromkeys(r['dependeDe'] + waits) if not (by_id.get(d) or {}).get('completada')]
        plain_impl = r['siguiente']['skill'] == 'sdd-implement' and not r['problemas']
        if r['esperaA'] and plain_impl and not (r['tareas'] or {}).get('siguiente'):
            r['siguiente'] = {'skill': None, 'motivo': 'espera a %s' % ', '.join(r['esperaA'])}
        for dd in r['esperaA']:
            o = by_id.get(dd) or {}
            if r['spec'] in (o.get('dependeDe') or []) or any(x.endswith('→' + r['spec']) for x in ((o.get('tareas') or {}).get('esperanSpec') or [])):
                r['problemas'].append({'msg': 'ciclo de dependencias entre %s y %s: una de las dos debe dejar de esperar a la otra' % (r['spec'], dd), 'skill': 'sdd-tasks'})
        if any(x in r['esperaA'] for x in r['dependeDe']) and plain_impl:
            r['siguiente'] = {'skill': None, 'motivo': 'Depende de %s, aún no completada: no se implementa todavía' % ', '.join(r['esperaA'])}
        for d in r['dependeDe']:
            if d not in by_id:
                r['avisos'].append('Depende de %s, que no existe' % d)
    # El paso del proyecto (brief, constitución, AGENTS.md y convenciones) va antes que cualquier spec.
    if proj.get('siguiente') and proj['siguiente']['skill'] in ('sdd-init', 'sdd-constitution', 'sdd-agents'):
        for r in results:
            if r['siguiente']['skill']:
                r['siguiente'] = {'skill': None, 'motivo': 'antes, el paso del proyecto (%s)' % proj['siguiente']['skill']}
    active_all = [r for r in results if not r['completada']]
    # Sin specs activas, un hallazgo sin dueño o un CRÍTICO/ALTO global sigue necesitando una ruta.
    if not active_all and (not proj.get('siguiente') or proj['siguiente']['skill'] == 'sdd-spec'):
        un = unowned(rows)
        g = next((x for x in (rows or []) if is_open(x) and is_high(x) and x['global']), None)
        if un:
            proj['siguiente'] = {'skill': 'sdd-review', 'motivo': block_motivo(block_step(un[0]), ' (sin spec reconocible)')}
        elif g:
            b = block_step(g)
            proj['siguiente'] = {'skill': b['ruta'], 'motivo': block_motivo(b, ' (global) sin spec activa')}
    in_progress = [r for r in active_all if not r['esperaA'] and r['tareas'] and r['tareas']['hechas'] > 0 and r['tareas']['pendientes'] > 0]
    active = in_progress or [r for r in active_all if not r['esperaA']]
    shown = [r for r in results if r['spec'] == only] if only else results
    if only and not shown:
        print('sdd-check: la spec %s no existe' % only, file=sys.stderr)
        return 2
    opened = [x for x in (rows or []) if is_open(x)]
    out = {'proyecto': proj,
           'backlog': {'abiertos': len(opened), 'criticosAltos': [x['id'] for x in opened if is_high(x)]} if rows is not None else None,
           'specs': shown, 'activas': [r['spec'] for r in active]}
    for r in results:
        r.pop('retroDefecto', None)
        r.pop('retroPendiente', None)
    if flag('--json'):
        print(json.dumps(out, indent=2, ensure_ascii=False))
    else:
        if proj.get('siguiente'):
            print('PROYECTO · SIGUIENTE PASO: %s · MOTIVO: %s' % (proj['siguiente']['skill'], proj['siguiente']['motivo']))
        for w in proj['avisos']:
            print('AVISO: ' + w)
        for p in proj['problemas']:
            print('PROBLEMA: ' + p)
        if out['backlog']:
            print('BACKLOG: %d abiertos · CRÍTICO/ALTO: %s' % (out['backlog']['abiertos'], ', '.join(out['backlog']['criticosAltos']) or 'ninguno'))
        for r in shown:
            if r['completada'] and not only and not r['problemas'] and not r['avisos']:
                print('\nSPEC %s v%s · SIGUIENTE PASO: — · MOTIVO: %s' % (r['spec'], show(r['specVersion']), r['siguiente']['motivo']))
                continue
            arts = ' '.join('%s=%s' % (f.replace('.md', ''), 'N/A' if (f == 'migration-review.md' and not r['migracionRequerida'] and v['estado'] != 'VIGENTE') else ((v.get('veredicto') or 'ok') if v['estado'] == 'VIGENTE' else v['estado']))
                            for f, v in r['artefactos'].items())
            print('\nSPEC %s v%s · %s · Tamaño %s · plan v%s' % (r['spec'], show(r['specVersion']), show(r['estado']),
                                                                  show(r['tamano']), show(r.get('planVersion'))))
            if arts:
                print('  ' + arts)
            tr = r['tareas']
            if tr:
                print('  tareas %d/%d (+%d archivadas) · siguiente %s · cerradas desde la última verificación completa: %d'
                      % (tr['hechas'], tr['total'], tr['archivadas'], tr['siguiente'] or '—', tr['desdeTodo']))
            for p in r['problemas']:
                print('  PROBLEMA: ' + p['msg'])
            if tr and tr['esperanUsuario']:
                print('  esperan al usuario: ' + ', '.join(tr['esperanUsuario']))
            if tr and tr['esperanSpec']:
                print('  esperan a otra spec: ' + ', '.join(tr['esperanSpec']))
            for w in r['avisos'][:12]:
                print('  aviso: ' + w)
            if len(r['avisos']) > 12:
                print('  aviso: … y %d más (--json)' % (len(r['avisos']) - 12))
            if r.get('esperaA') and not r['completada']:
                print('  espera a: %s (Depende de)' % ', '.join(r['esperaA']))
            s = r['siguiente']
            print('  SIGUIENTE PASO: %s%s · MOTIVO: %s' % (s['skill'] or '—', (' ' + s['tarea']) if s.get('tarea') else '', s['motivo']))
        if not only:
            if not active and active_all:
                print('\nAVISO: ninguna spec avanzable: todas esperan a dependencias no completadas o inexistentes (%s)' % ', '.join(r['spec'] for r in active_all))
            elif len(active) > 1:
                print('\nAVISO: %d specs activas sin orden por dependencias (%s): elige una.' % (len(active), ', '.join(out['activas'])))
            elif len(active) == 1 and len(active_all) > 1:
                print('\nSPEC A AVANZAR: %s (en curso o sin dependencias pendientes)' % active[0]['spec'])
    # Los problemas del backlog cuentan también con --spec: validate y release exigen «sin PROBLEMA».
    return 1 if any(r['problemas'] for r in shown) or (not only and proj['problemas']) or any(x.startswith('backlog:') for x in proj['problemas']) else 0


# Secretos (política del paquete). FAIL: formatos de proveedor (en cualquier fichero) y, en código, credenciales con
# estructura (SECRET_STRONG) y .env reales. AVISO: heurísticas por nombre (SECRET_SOFT) y todo lo de tests, fixtures,
# documentación y .env de desarrollo. El escáner dedicado de CI (p. ej. gitleaks) bloquea lo que aquí solo avisa.
# «sdd-allow-secret» en la línea silencia un aviso; sobre un hallazgo que bloquea deja un AVISO de revisión humana y, en
# CI (--range), solo pasa si el sha256 de fichero y línea (el que muestra el FAIL) está en .sdd-allowed-secrets de la
# base del rango (en local, la versión commiteada). Los valores …EXAMPLE… de los proveedores no cuentan. La salida nunca
# muestra el secreto: fichero:línea y sus 4 primeros caracteres.
SECRET_HARD = [re.compile(x) for x in [
    r'-----BEGIN [A-Z ]*PRIVATE KEY( BLOCK)?-----', r'\bAKIA[0-9A-Z]{16}\b', r'\bgh[pousr]_[A-Za-z0-9]{30,}\b',
    r'\bxox[abp]-[A-Za-z0-9-]{10,}', r'\bsk-(?:proj-|ant-|svcacct-)?[A-Za-z0-9_-]{32,}', r'\bAIza[0-9A-Za-z_-]{35}\b',
    r'\bgithub_pat_[A-Za-z0-9_]{40,}', r'\b[sr]k_live_[A-Za-z0-9]{20,}', r'\bglpat-[A-Za-z0-9_-]{20,}',
    r'\bnpm_[A-Za-z0-9]{36}\b', r'\bSG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}\b',
    r'hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[A-Za-z0-9]{20,}', r'AccountKey=[A-Za-z0-9+/]{40,}={0,2}',
    r'\bwhsec_[A-Za-z0-9+/=]{20,}', r'\bhf_[A-Za-z0-9]{30,}\b', r'\bhvs\.[\w-]{24,}', r'\b\d{8,10}:AA[\w-]{33}\b', r'discord(?:app)?\.com/api/webhooks/\d+/[\w-]{50,}',
    r'LS0tLS1CRUdJTiB(?:QUklWQVRF|SU0EgUFJJVkFURS|FQyBQUklWQVRF|PUEVOU1NIIFBSSVZBVEU)']]  # clave privada PEM en base64
# Alta confianza fuera de un formato de proveedor (credenciales con estructura): FAIL en código, AVISO en tests y docs.
SECRET_STRONG = [
    re.compile(r'\bAuthorization[\'"]?\s*[:,]\s*[\'"`]?Basic\s+[A-Za-z0-9+/=]{12,256}', re.I),
    re.compile(r'\bcurl\b.{0,512}\s-u\s+(?!\$)[^\s:\'\"]{1,128}:(?!\$)[^\s\'\"]{3,256}'),
    re.compile(r'\bmysql(?:dump|admin)?\b.{0,512}\s-p(?!\$)[^\s\'\"]{3,256}'),
    re.compile(r'\bauth\s*=\s*\(\s*[\'"][^\'\"]{1,128}[\'"]\s*,\s*[\'"][^\'\"]{6,256}[\'"]\s*\)'),
    re.compile(r'\bNetworkCredential\(\s*"[^"]{0,128}"\s*,\s*"[^"]{6,256}"'), re.compile(r'\bsshpass\s+-p\s*[\'"]?(?!\$)[^\s\'"]{6,256}'),
    re.compile(r'\beyJ[A-Za-z0-9_-]{8,4096}\.eyJ[A-Za-z0-9_-]{8,4096}\.[A-Za-z0-9_-]{8,4096}'),
]
# Heurísticas por nombre (password=, *_KEY=, fooKey=, define(), SQL): siempre AVISO visible (política: los falsos positivos
# no bloquean commits; el escáner dedicado de CI, p. ej. gitleaks, es el que bloquea). Repeticiones acotadas ({…,256}):
# tiempo lineal en líneas de cientos de KB. Exclusiones: referencias, llamadas, identificadores, claves públicas, «===».
# URL con credenciales (usuario opcional): FAIL salvo contraseña de relleno o igual al usuario (valores de desarrollo
# conocidos: no es un secreto) o host local (AVISO).
URL_CRED = re.compile(r'\b[a-z][a-z0-9+.-]{0,30}://([^\s:/@\'"$]{0,256}):(?![$%{<])([^\s@\'"/]{3,256})@([^\s/:\'"?#]{1,256})', re.I)
URL_PLACEHOLDER = re.compile(r'^(pass|passwd|password|changeme|change_me|secret|guest|example|test|testing|dev|root|admin|postgres|mysql|redis|user|x{3,}|\*{3,})$', re.I)
LOCAL_HOST = re.compile(r'^(localhost|127\.0\.0\.1|0\.0\.0\.0|\[?::1\]?|host\.docker\.internal)$', re.I)
SECRET_SOFT = [
    re.compile(r'(?<!public[_-])(?<!existing)(?<!existing_)(?<!existing-)(?:password|passwd|pwd|secret|api[_-]?key|token|access[_-]?key|credentials?)(?:\s*:\s*[\w&<>\[\]|.*]{1,40}?\s*(?==)|\s+[\w&<>\[\]|.*]{1,40}?\s*(?==))?[\'"]?\s*(?::=|=>|[:=])(?![=>])\s*[\'"]?(?!\$[{(A-Z_]|[<{%(\[~/]|process\.env|os\.environ|var\.|ssh-|projects/|https?:|pk_(?:live|test)_|[\w.:\\]+[(\[]|\d+[\'"]?(?:[\s,;)]|$)|[A-Za-z_][\w-]*(?:\.[\w-]+)+(?=[\'"\s,;)]|$))(?=[^\'"\s]{0,256}\d)[^\'\"\s,;]{8,256}', re.I),
    re.compile(r'(?<!existing)(?<!existing_)(?<!existing-)(?:password|passwd|secret|secret[_-]?key)[\'"]?\s*(?::=|=>|[:=])(?![=>])\s*[\'"](?!\$[{(A-Z_]|[<{%~/]|projects/|[a-z][a-z0-9]*(?:_[a-z0-9]+)+[\'"]|[A-Za-z_][\w-]*(?:\.[\w-]+)+(?=[\'"\s,;)]|$))[^\'"\s]{12,256}[\'"]', re.I),
    re.compile(r'(?<![Pp][Uu][Bb][Ll][Ii][Cc])(?<![Ss][Ii][Tt][Ee])[_-][Kk][Ee][Yy][\'"]?\s*(?::=|=>|[:=])(?![=>])\s*[\'"]?(?!pk_(?:live|test)_|[a-z][a-z0-9]*(?:[_-][a-z0-9]*)+[\'"]?(?=[\s,;)]|$)|[a-z]{2,}(?:[A-Z][a-z]{2,}[0-9]*)*(?:[A-Z][0-9]*)?[\'"]?(?=[\s,;)]|$)|[A-Za-z_][\w-]*(?:\.[\w-]+)+(?=[\'"\s,;)]|$))(?=[^\'"\s]{0,256}\d)(?=[^\'"\s]{0,256}[A-Za-z])[A-Za-z0-9+_=-]{16,256}(?=[\'"\s,;]|$)'),
    re.compile(r'[a-z](?<![Pp]ublic)(?<![Ss]ite)(?:Key|Secret|Token|Password)(?:\s*:\s*[\w&<>\[\]|.*]{1,40}?\s*(?==)|\s+[\w&<>\[\]|.*]{1,40}?\s*(?==))?[\'"]?\s*:?=\s*(?:\[\]byte\()?[\'"](?![a-z][a-z0-9]*(?:[_-][a-z0-9]*)+[\'"]?(?=[\s,;)]|$)|[a-z]{2,}(?:[A-Z][a-z]{2,}[0-9]*)*(?:[A-Z][0-9]*)?[\'"]?(?=[\s,;)]|$)|[A-Za-z_][\w-]*(?:\.[\w-]+)+(?=[\'"\s,;)]|$))(?=[^\'"\s]{0,256}\d)[^\'"\s]{16,256}[\'"]'),
    re.compile(r'\bdefine\(\s*[\'"][A-Z_]*(?:PASSWORD|SECRET|KEY|TOKEN|SALT)[A-Z_]*[\'"]\s*,\s*[\'"](?!\$)[^\'"\s]{8,256}[\'"]'),
    re.compile(r'\b(?:PASSWORD\s+\'[^\'\s]{6,256}\'|IDENTIFIED\s+BY\s+\'[^\'\s]{6,256}\')', re.I),
    re.compile(r'\bset\(\s*\w*(?:PASSWORD|SECRET|TOKEN|KEY)\w*\s+"(?!\$)[^"\s]{8,256}"', re.I),  # CMake set(…_KEY "…")
]
# Tests enfocados (desactivan el resto de la suite) → FAIL; desactivados, eliminados, sin aserciones o supresiones → AVISO.
TEST_FILE = re.compile(r'(^|/)(tests?|__tests__|spec|cypress|e2e)/|[._-](test|spec)\.[cm]?[jt]sx?$|\.(cy|e2e)\.[cm]?[jt]sx?$|(^|/)test_[^/]*\.py$|_test\.(py|go)$|_spec\.rb$|(Tests?|IT)\.(java|kt|cs)$')
FIXTURE = re.compile(r'(^|/)(fixtures?|__fixtures__|testdata|__snapshots__|mocks?)/')
TEST_FOCUS = [re.compile(x) for x in [r'(?<![.\w])(?:it|test|describe|context|suite)(?:\.\w+)*\.only\b', r'(?<![.\w])(?:fit|fdescribe)\s*\(',
                                      r'(?<![.\w])fit\s+[\'"]', r'\bfocus:\s*true\b']]
TEST_SKIP = [re.compile(x) for x in [
    r'(?<![.\w])(?:it|test|describe|context|suite)(?:\.\w+)*\.(?:skip(?:If)?|fixme)\b', r'(?<![.\w])(?:xit|xtest|xdescribe)\s*\(',
    r'@pytest\.mark\.(?:skip|skipif|xfail)\b', r'@unittest\.skip', r'\bpytest\.skip\s*\(', r'\bt\.Skip(?:Now|f)?\s*\(',
    r'@Disabled\b', r'@Ignore\b', r'#\[ignore\]']]
TEST_DECL = re.compile(r'(?<![.\w])(?:it|test)\s*\(|\bdef test_\w+|\bfunc Test\w+|@Test\b|#\[test\]|\[(?:Fact|Theory|Test|TestMethod)\]')
ASSERTION = re.compile(r'\b(?:expect|assert\w*|Assert\.\w+|should|verify|t\.(?:Error|Fatal|Fail)\w*|require\.\w+|raises|toBe|toEqual)\b')
SUPPRESS = re.compile(r'eslint-disable|@ts-ignore|@ts-expect-error|@ts-nocheck|#\s*type:\s*ignore|#\s*noqa|pylint:\s*disable|\bnosec\b|NOLINT|nosemgrep|@SuppressWarnings|checkov:skip|tfsec:ignore|pragma:\s*no cover|istanbul ignore|c8 ignore|coverageThreshold|fail_under|cov-fail-under|NOSONAR|nolint')
# Cambios en cómo se ejecutan los tests o la CI, y en los ficheros que leen todos los agentes → AVISO (revisión humana).
CI_FILE = re.compile(r'(^|/)(\.github/workflows/|\.circleci/)|(^|/)(\.gitlab-ci\.yml|Jenkinsfile|azure-pipelines\.yml|bitbucket-pipelines\.yml)$')
TEST_CFG_FILE = re.compile(r'(^|/)(jest|vitest|playwright|cypress|karma)\.config\.[cm]?[jt]s$|(^|/)(pytest\.ini|tox\.ini|\.coveragerc|phpunit\.xml(\.dist)?)$')
TEST_CFG_LINE = re.compile(r'"test[\w:-]*"\s*:|\baddopts\b|passWithNoTests|continue-on-error|--no-verify|\b(?:test|jest|vitest|pytest|mocha|go test|cargo test)\b.*\|\|\s*true\b|^\+\s*test\s*:')
STEERING = ['AGENTS.md', 'docs/agent-runbook.md', 'docs/constitution.md', 'docs/sdd-conventions.md']
DOC_FILE = re.compile(r'\.(md|mdx|markdown|rst|txt|adoc)$', re.I)
SENSITIVE_FILE = re.compile(r'(^|/)(\.env(\.[^/]+)?|\.envrc|\.npmrc|\.pypirc|[^/]*\.tfvars|[^/]*\.(pem|p12|pfx|key|jks|keystore)|id_(rsa|dsa|ecdsa|ed25519)[^/]*|credentials[^/]*\.json|kubeconfig[^/]*)$')
ENV_SAMPLE = re.compile(r'\.(example|sample|template|dist|defaults)$', re.I)
ENV_SECRET = re.compile(r'^\s*(?:export\s+)?\S{0,128}?(?:password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|private[_-]?key|credentials?|(?<![A-Za-z0-9])(?:pass|pw)(?![A-Za-z0-9]))\w{0,64}\s*[=:]\s*[\'"]?(?!\$[{(A-Z_]|[<{%\'"\s/.]|$|https?:)(?!(?:\d+|true|false|yes|no|on|off)[\'"]?\s*$)\S', re.I)
# .env de desarrollo, test o CI: sus valores suelen ser locales; un hallazgo genérico en ellos es AVISO, no FAIL.
ENV_DEV = re.compile(r'(^|/)\.env\.(test|testing|development|dev|ci|e2e)$')
# Solo los .env de ejemplo son laxos (no cualquier .template/.dist: p. ej. una plantilla de despliegue con una URL real).
ENV_EXAMPLE = re.compile(r'(^|/)\.env[^/]*\.(example|sample|template|dist|defaults)$')
# .env: nombres que terminan en KEY o AUTH, con valor largo (APP_KEY, ENCRYPTION_KEY, SENTRY_AUTH); no los públicos.
ENV_SECRET2 = re.compile(r'^\s*(?:export\s+)?[\w.-]{0,128}?(?<![Pp][Uu][Bb][Ll][Ii][Cc][_-])(?<![Pp][Uu][Bb][Ll][Ii][Ss][Hh][Aa][Bb][Ll][Ee][_-])(?:key|auth)\s*[=:]\s*[\'"]?(?!\$[{(A-Z_]|[<{%\'"\s/.]|https?:|pk_)[^\'"\s]{12,}', re.I)


def is_doc(f):
    # Documentación (los avisos son laxos en ella), salvo .txt que son configuración.
    return bool(DOC_FILE.search(f)) and not re.search(r'(^|/)(requirements[^/]*|constraints[^/]*|CMakeLists)\.txt$', f, re.I)
LOCKFILE = re.compile(r'(^|/)(package-lock\.json|npm-shrinkwrap\.json|yarn\.lock|pnpm-lock\.yaml|poetry\.lock|uv\.lock|Pipfile\.lock|Cargo\.lock|go\.sum|Gemfile\.lock|composer\.lock)$')


def staged_text(rel):
    t = try_git('show', ':' + rel)
    if t is not None:
        return norm(t)
    return read(os.path.join(root, rel)) or ''


def mask(s):
    return s[:4] + '…'


def snip(t, f=''):
    # Ficheros sensibles: nunca se muestran; literales entre comillas de 8+ caracteres, tampoco (pueden ser secretos no detectados).
    if SENSITIVE_FILE.search(f):
        return '(línea de un fichero sensible: no se muestra)'
    if any(rx.search(t) for rx in SECRET_HARD + SECRET_STRONG + SECRET_SOFT + [URL_CRED, ENV_SECRET]):
        return '(línea con un posible secreto: no se muestra)'
    t = re.sub(r'([\'"`])[^\'"`]{6,}\1', r'\1…\1', t)
    return re.sub(r'(?=[\w!#$%&*+\-.@^~]*\d)[\w!#$%&*+\-.@^~]{6,}', '…', t)[:80].strip()


def allow_key(x):
    # Clave de .sdd-allowed-secrets: ligada a fichero y línea (aprobar un fixture no aprueba la misma línea en otro sitio).
    return sha256(x['file'] + '\0' + x['text'].strip())


def diff_path(raw):
    # Ruta de una cabecera +++ de git: sin el TAB final (nombres con espacios) y sin comillas C (caracteres especiales).
    p = re.sub(r'\t$', '', raw)
    if re.match(r'^".*"$', p):
        out, body, i = bytearray(), p[1:-1], 0
        while i < len(body):
            if body[i] != '\\':
                out += body[i].encode('utf-8')
            elif re.match(r'^[0-7]{3}$', body[i + 1:i + 4]):
                out.append(int(body[i + 1:i + 4], 8))
                i += 3
            else:
                i += 1
                c = body[i] if i < len(body) else ''
                out += {'t': '\t', 'n': '\n'}.get(c, c).encode('utf-8')
            i += 1
        p = out.decode('utf-8', errors='replace')
    return re.sub(r'^b/', '', p)


# Opciones que impiden que la configuración del repo o del usuario oculte el diff (diff externo, textconv, -diff, NUL).
# Prefijos fijos: diff.dstPrefix/mnemonicPrefix no pueden disfrazar rutas (p. ej. hacer pasar código por tests/).
# --no-renames: un fichero movido (p. ej. de tests/ a src/) se escanea entero en su ruta nueva.
RAW = ['-U0', '--no-color', '--no-ext-diff', '--no-textconv', '--text', '--src-prefix=a/', '--dst-prefix=b/', '--no-renames']


def sha256(s):
    return hashlib.sha256(s.encode('utf-8')).hexdigest()


def parse_diff(text):
    # Diff con estado de hunk: «+++»/«---» solo son cabeceras fuera de un hunk (una línea añadida «++ x» no cambia de fichero).
    plus, minus, cur, in_hunk, ln = [], [], '', False, 0
    # Solo \n separa líneas del diff: un \r suelto dentro de una línea añadida no debe partirla (ocultaría lo que sigue).
    for l in [re.sub(r'\r', ' ', re.sub(r'\r$', '', y)) for y in (text or '').split('\n')]:
        if l.startswith('diff --git '):
            in_hunk, cur = False, ''
            continue
        if not in_hunk and l.startswith('+++ '):
            cur = diff_path(l[4:])
            continue
        if not in_hunk and l.startswith('--- '):
            continue
        h = re.match(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@', l)
        if h:
            in_hunk, ln = True, int(h.group(1))
            continue
        if not in_hunk:
            continue
        if l.startswith('+'):
            plus.append({'file': cur, 'line': ln, 'text': l[1:]})
            ln += 1
        elif l.startswith('-'):
            minus.append({'file': cur, 'text': l[1:]})
        elif l.startswith(' '):
            ln += 1
    return plus, minus


def allow_hash():
    # allow-hash <fichero>:<línea>: la clave que una persona añade a .sdd-allowed-secrets para aprobar un falso positivo.
    # Se calcula en local: los logs de CI nunca muestran el hash (con un secreto de baja entropía sería reversible).
    m = re.match(r'^(.+):(\d+)$', args[0] if args else '')
    txt = read(os.path.join(root, m.group(1))) if m else None
    lines = txt.split('\n') if txt is not None else []
    n = int(m.group(2)) if m else 0
    if not (1 <= n <= len(lines)):
        print('uso: sdd-check allow-hash <fichero>:<línea> (ruta relativa a la raíz del repositorio)', file=sys.stderr)
        return 2
    print('%s  %s:%s' % (allow_key({'file': m.group(1), 'text': lines[n - 1]}), m.group(1), m.group(2)))
    return 0


def pre_commit():
    task, bug, rng = opt('--task'), opt('--bug'), opt('--range')
    if try_git('rev-parse', '--git-dir') is None:
        print('pre-commit requiere un repositorio git', file=sys.stderr)
        return 2
    # --range <base>..<head>: modo CI. Mismos detectores sobre la rama; los secretos, sobre todo el historial del rango.
    src = [rng] if rng else ['--cached']
    names_out = try_git('diff', '--name-only', '-z', *src)
    if names_out is None:
        print('sdd-check: rango no válido: %s' % rng, file=sys.stderr)
        return 2
    staged = split_z(names_out)
    added_l = split_z(git('diff', '--name-only', '--diff-filter=A', '-z', *src))
    added = set(added_l)
    deleted = split_z(git('diff', '--name-only', '--diff-filter=D', '-z', *src))
    problems, warnings = [], []
    if not staged and not rng:
        problems.append('no hay nada staged')
    spec_opt = opt('--spec')
    specs_root = os.path.join(root, 'specs')
    spec_dirs = sorted(d for d in os.listdir(specs_root) if re.match(r'^\d{3}-', d) and os.path.isdir(os.path.join(specs_root, d))) if os.path.isdir(specs_root) else []
    code = [f for f in staged if not re.match(r'^(specs|docs|reviews)/', f) and f != 'AGENTS.md' and f != '.sdd-allowed-secrets' and not LOCKFILE.search(f) and f not in deleted]
    if task and not rng:
        def has(d):
            return any(x['id'] == task for x in parse_tasks(read(os.path.join(root, 'specs', d, 'tasks.md')))[0])
        cands = [spec_opt] if spec_opt else [d for d in spec_dirs if has(d)]
        if not spec_opt and len(cands) > 1:
            st = [d for d in cands if 'specs/%s/tasks.md' % d in staged]
            if len(st) == 1:
                cands = st
            else:
                problems.append('%s existe en varias specs (%s): usa --spec' % (task, ', '.join(cands)))
        if not cands or (spec_opt and not has(spec_opt)):
            problems.append('%s no existe en %s' % (task, spec_opt or 'ningún tasks.md'))
        elif len(cands) == 1:
            rel = 'specs/%s/tasks.md' % cands[0]
            if rel not in staged:
                problems.append('%s no está staged: la evidencia va en el mismo commit que el código' % rel)
            t = next((x for x in parse_tasks(staged_text(rel))[0] if x['id'] == task), None)
            if not (t and t['done']):
                problems.append('%s no está marcada [x] en la versión staged de %s' % (task, rel))
            elif t['evidencePending'] or t['evidenceLines'] == 0:
                problems.append('%s sin evidencia en la versión staged' % task)
            if staged and all(x.startswith('specs/') for x in staged):
                warnings.append('commit de tarea sin cambios fuera de specs/: si %s no tiene código ni tests (re-sellado, reapertura, cierre N/A), usa el pre-commit genérico' % task)
            if t and code:
                # Trazabilidad código → tarea: cada fichero de código staged figura en «Archivos:» (ruta, nombre o carpeta «dir/»).
                arch = next((l for l in t['body'] if re.match(r'^\s*[-*]\s+\**Archivos\**\s*:', l)), None)
                if not arch:
                    warnings.append('la evidencia de %s no tiene «Archivos:» (Convenciones › Tareas y evidencia)' % task)
                else:
                    txt = re.sub(r'^[^:]*:', '', arch, count=1)
                    tokens = [k for k in re.split(r'[\s,·;()`]+', txt) if k]
                    miss = [f for f in code if not (f in txt or f.split('/')[-1] in tokens or any(k.endswith('/') and f.startswith(k) for k in tokens))]
                    if miss:
                        problems.append('ficheros staged no citados en «Archivos:» de %s: %s' % (task, ', '.join(miss[:5])))
                req = next((l for l in t['body'] if re.search(r'Tests requeridos\**\s*:', l)), None)
                if req and not re.search(r':\s*\**\s*N/?A\b', req, re.I) and not any(TEST_FILE.search(f) for f in code):
                    warnings.append('código staged sin ningún fichero de test aunque «Tests requeridos» de %s no es N/A' % task)
    if bug and not rng:
        found = [x for x in ('specs/%s/bugs/%s.md' % (d, bug) for d in ([spec_opt] if spec_opt else spec_dirs))
                 if x in staged or os.path.exists(os.path.join(root, x))]
        if not found:
            problems.append('%s.md no existe' % bug)
        else:
            if len(found) > 1:
                problems.append('%s existe en varias specs: la numeración BUG-NNN es global, renumera' % bug)
            f = found[0]
            if f not in staged:
                problems.append('%s no está staged' % f)
            txt = staged_text(f)
            if not re.search(r'Estado\**\s*:\**\s*\**\s*CERRADO', txt, re.I):
                problems.append('%s no está CERRADO' % bug)
            cm = re.search(r'Clase:[ \t]*([^\n]*)', txt)
            clase = cm.group(1) if cm else ''
            if f in added and (not clase.strip() or re.search(r'[|<·]', clase)):
                problems.append('%s sin «Clase:» de causa raíz (un solo valor)' % bug)
    for f in [x for x in staged if re.search(r'(^|/)(__pycache__|node_modules|\.DS_Store|\.pytest_cache|\.venv)(/|$)|\.pyc$', x)][:5]:
        warnings.append('fichero generado staged (¿falta en los ignorados?): %s' % f)
    for f in [x for x in staged if SENSITIVE_FILE.search(x) and not ENV_SAMPLE.search(x) and x not in deleted][:5]:
        warnings.append('fichero de entorno o de credenciales staged: %s (comprueba que no contiene secretos; los valores de ejemplo van en un .env.example)' % f)
    for f in [x for x in deleted if TEST_FILE.search(x)][:5]:
        warnings.append('test eliminado: %s — solo si su requisito se eliminó o se movió (cítalo en la evidencia)' % f)
    plus, minus = parse_diff(git('diff', *RAW, *src))
    # Secretos: en CI, todo el historial del rango (un secreto añadido y borrado después sigue en el historial).
    # -m: también el diff de los merges (lo añadido al resolverlos); base..head: solo los commits de la rama.
    secret_lines = parse_diff(git('log', '-p', '-m', *RAW, '--format=', rng.replace('...', '..')))[0] if rng else plus
    # allowlist: en CI se lee de la base del rango (lo integrado y revisado), nunca del propio rango
    # En CI, la versión de la base del rango; en local, la commiteada (nunca la que el propio cambio edita).
    allow_src = try_git('show', '%s:.sdd-allowed-secrets' % (re.split(r'\.\.\.?', rng)[0] if rng else 'HEAD'))
    allowed = {x.strip() for x in (allow_src or '').split('\n') if x.strip()}
    # Política: FAIL = formato de proveedor (cualquier fichero) o credencial con estructura / .env real (en código);
    # AVISO = heurística por nombre (siempre) o hallazgo en tests, fixtures, documentación y .env de desarrollo.
    seen, n_warn, more = set(), 0, []
    for x in secret_lines:
        where = '%s:%d' % (x['file'], x['line'])
        if (where + x['text']) in seen:
            continue
        lax = bool(is_doc(x['file']) or TEST_FILE.search(x['file']) or FIXTURE.search(x['file']) or ENV_DEV.search(x['file']) or ENV_EXAMPLE.search(x['file']))
        hard = next((mm for mm in (rx.search(x['text']) for rx in SECRET_HARD) if mm and 'EXAMPLE' not in mm.group(0)), None)
        env_hit = (ENV_SECRET.search(x['text']) or ENV_SECRET2.search(x['text'])) if SENSITIVE_FILE.search(x['file']) and not ENV_SAMPLE.search(x['file']) else None
        u = URL_CRED.search(x['text'])
        url = u if u and not (URL_PLACEHOLDER.search(u.group(2)) or u.group(1) == u.group(2)) else None
        strong = None if hard else (next((mm for mm in (rx.search(x['text']) for rx in SECRET_STRONG) if mm), None)
                                    or (url if url and not LOCAL_HOST.search(url.group(3)) else None) or (env_hit if env_hit and not lax else None))
        weak = None if (hard or strong) else (next((mm for mm in (rx.search(x['text']) for rx in SECRET_SOFT) if mm), None) or url or env_hit)
        if not hard and not strong and not weak:
            continue
        seen.add(where + x['text'])
        marked = 'sdd-allow-secret' in x['text']
        blocking = bool(hard or (strong and not lax))
        m = (hard or strong or weak).group(0)
        if allow_key(x) in allowed:
            warnings.append('secreto probable permitido por .sdd-allowed-secrets (%s) en %s' % ('base del rango' if rng else 'versión commiteada', where))
        elif blocking and marked and rng:
            problems.append('secreto probable en %s (%s) marcado con sdd-allow-secret: en CI solo pasa si una persona añade a .sdd-allowed-secrets su sha256 de fichero y línea (calcúlalo en local: sdd-check allow-hash %s)' % (where, mask(m), where))
        elif blocking and marked:
            warnings.append('secreto probable marcado como permitido (sdd-allow-secret) en %s: requiere revisión humana antes de integrar' % where)
        elif blocking:
            problems.append('secreto probable en %s: %s (si es un falso positivo, una persona puede aprobarlo en .sdd-allowed-secrets: sdd-check allow-hash %s)' % (where, mask(m), where))
        elif marked:
            continue
        else:
            if n_warn >= 10:
                more.append(where)
            else:
                warnings.append('revisa (¿secreto real o valor de prueba?) en %s: %s' % (where, mask(m)) if (lax or not weak)
                                else 'posible secreto en código (patrón genérico) en %s: %s — revísalo: si es real, muévelo a configuración segura' % (where, mask(m)))
            n_warn += 1
    if more:
        warnings.append('… y %d posibles secretos más (revísalos): %s%s' % (len(more), ', '.join(more[:40]), ', …' if len(more) > 40 else ''))
    tests = [y for y in plus if TEST_FILE.search(y['file']) and not DOC_FILE.search(y['file'])]
    for x in [y for y in tests if any(rx.search(y['text']) for rx in TEST_FOCUS)][:5]:
        problems.append('test enfocado (desactiva el resto de la suite) en %s:%d: %s' % (x['file'], x['line'], snip(x['text'], x['file'])))
    for x in [y for y in tests if any(rx.search(y['text']) for rx in TEST_SKIP)][:5]:
        warnings.append('test desactivado en %s:%d: %s — solo si la tarea lo justifica (motivo en la evidencia); nunca para avanzar con un fallo' % (x['file'], x['line'], snip(x['text'], x['file'])))
    for x in [y for y in plus if not DOC_FILE.search(y['file']) and SUPPRESS.search(y['text'])][:5]:
        warnings.append('supresión de lint, tipos o cobertura en %s:%d: %s — justifícala en la evidencia' % (x['file'], x['line'], snip(x['text'], x['file'])))
    if not rng:
        for f in [y for y in added_l if TEST_FILE.search(y) and not DOC_FILE.search(y)][:20]:
            body = staged_text(f)
            if TEST_DECL.search(body) and not ASSERTION.search(body):
                warnings.append('%s declara tests sin ninguna aserción (¿pueden fallar?)' % f)
    cfg = []
    for f in [f for f in staged if CI_FILE.search(f) or TEST_CFG_FILE.search(f)] + [y['file'] for y in plus if not DOC_FILE.search(y['file']) and TEST_CFG_LINE.search(y['text'])]:
        if f not in cfg:
            cfg.append(f)
    for f in cfg[:5]:
        warnings.append('cambia cómo se ejecutan los tests o la CI en %s: requiere revisión humana' % f)
    touched = {x['file'] for x in plus + minus}
    if any(x['file'] == 'AGENTS.md' and re.match(r'^(\||Excepciones aceptadas)', x['text']) for x in plus + minus):
        warnings.append('cambia la tabla de comandos de AGENTS.md o sus excepciones (lo que ejecutan todos los gates): requiere revisión humana')
    if '.sdd-allowed-secrets' in staged:
        warnings.append('cambia .sdd-allowed-secrets: solo lo editan personas; en CI cuenta la versión de la base del rango, no la de la rama')
    for f in [y for y in STEERING if y in touched]:
        warnings.append('cambia %s (instrucciones que leen los agentes): revisa que no introduce reglas ajenas al proyecto' % f)
    print('MODO: %s' % ('rango ' + rng if rng else 'tarea ' + task if task else 'bug ' + bug if bug else 'genérico (secretos y tests)'))
    print('%s (%d): %s' % ('CAMBIADOS' if rng else 'STAGED', len(staged), ', '.join(staged)))
    for p in problems[:50]:
        print('PROBLEMA: ' + p)
    if len(problems) > 50:
        print('PROBLEMA: … y %d problemas más' % (len(problems) - 50))
    for w in warnings:
        print('AVISO: ' + w)
    print('PRE-COMMIT: FAIL' if problems else 'PRE-COMMIT: OK — revisa que cada fichero pertenece al trabajo')
    return 1 if problems else 0


if __name__ == '__main__':
    try:
        if cmd == 'status':
            sys.exit(status())
        if cmd == 'pre-commit':
            sys.exit(pre_commit())
        if cmd == 'allow-hash':
            sys.exit(allow_hash())
        print('comando desconocido: ' + cmd, file=sys.stderr)
        sys.exit(2)
    except SystemExit:
        raise
    except Exception as e:  # noqa: BLE001 — cualquier fallo inesperado es error de entorno (2), nunca «problemas» (1)
        print('sdd-check: %s' % e, file=sys.stderr)
        sys.exit(2)
