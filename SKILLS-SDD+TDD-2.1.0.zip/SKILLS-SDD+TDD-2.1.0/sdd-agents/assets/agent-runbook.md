# Runbook operativo para agentes

> Conocimiento operativo verificado del proyecto. Sin secretos ni datos personales: las credenciales
> se obtienen en tiempo de ejecución (variables de entorno, gestor de secretos), nunca se copian aquí.
> Si un comando de este runbook falla, se corrige aquí; no se improvisa.

## Entorno de ejecución
- Dónde corren tests, build y servidor: <local | remoto: `<host>` y ruta `<dir>` | contenedor `<nombre>`>.
- Sincronización (solo si es remoto): `<comando run> sync` (borra en destino lo borrado en local; excluidos y protegidos no se tocan). Protegidos: <lista>.
- Recursos que NO se tocan: <bases de datos, servicios, puertos o contenedores ajenos o de producción>.

## Comandos (no interactivos; salida resumida; el log completo queda en `<dir local de logs>`)
| Para | Comando | Duración aprox. |
|---|---|---|
| Arrancar / detener servicios auxiliares (si hacen falta) | `<arranque en segundo plano>` / `<parada>` | |
| Un fichero o caso de test | | |
| Paquete/componente completo | | |
| Integración (almacenamiento desechable) | | |
| E2E | | |
| Build | | |
| Auditoría de dependencias | | |

## Datos de prueba
- Crear y destruir almacenamiento desechable: <comando>. Nunca los datos reales `<nombre>`.

## Convenciones de tests del repo
- <qué se sustituye por dobles y cómo; helpers compartidos; fixtures de contrato y su fuente>.

## Módulos canónicos
La fuente única es la sección §4b del plan de cada spec; no se duplica aquí.

## Trampas conocidas
- <síntoma> → <causa> → <qué hacer>.
