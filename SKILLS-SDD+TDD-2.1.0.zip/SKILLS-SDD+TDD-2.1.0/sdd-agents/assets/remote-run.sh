#!/usr/bin/env bash
# run — ejecuta comandos del proyecto en un entorno remoto de desarrollo (SSH + rsync).
# Plantilla de sdd-agents: ajusta solo los bloques CONFIG y ALIAS; el resto es genérico.
# Uso: run <alias|--raw "cmd"> [args...]  ·  run sync [--dry-run]  ·  run init [--confirm] (marca el destino tras revisar el dry-run)
# - Sincroniza el árbol local (rsync --delete; excluidos y protegidos nunca se borran en remoto).
# - Ejecuta en remoto, guarda el log COMPLETO en local ($LOG_DIR) e imprime un resumen filtrado.
# - Devuelve el exit code REAL del comando remoto (no el del filtro).
# Un solo comando a la vez por entorno: no lo lances en paralelo desde varios agentes.
# Requisitos: bash, ssh y rsync en local; bash y rsync en el remoto.
set -uo pipefail

# ---- CONFIG -----------------------------------------------------------------
HOST="${DEV_HOST:-<alias-ssh>}"               # alias de ~/.ssh/config o usuario@host
REMOTE_DIR="${DEV_DIR:-<ruta-remota>}"        # copia de trabajo en el destino (ruta ABSOLUTA, sin ~)
SSH_OPTS=(-o BatchMode=yes -o ConnectTimeout=15)   # añade -F <config> si el sistema lo necesita
# Excluidos: control de versiones, secretos locales, dependencias instaladas, artefactos de build
# y resultados de tests del ecosistema del proyecto (p. ej. node_modules, .venv, target, vendor, dist, build).
EXCLUDES=(.git .env '.env.*' .envrc .npmrc .pypirc '*.pem' '*.key' '*.p12' '*.pfx' '*.tfvars' '*.tfstate*' 'id_*' 'credentials*.json' 'kubeconfig*' .sdd-run-target)
# Rutas que SOLO existen en remoto y nunca deben borrarse (datos, uploads, config local…).
# Antes del primer uso: `run sync --dry-run`, revisa la lista de «deleting» y, si es correcta, `run init`
# (marca REMOTE_DIR como destino con .sdd-run-target; sin esa marca, run nunca sincroniza con borrado).
PROTECT=()
LOG_DIR="${LOG_DIR:-.run-logs}"               # añádelo a los ignorados del control de versiones
EXCLUDES+=("$LOG_DIR")
# Líneas que resumen el resultado (amplíalo con el formato de tus herramientas).
SUMMARY_RE='(^|[^a-z])(passed|failed|failures?|errors?|FAIL|PASS|ok|skipped|tests? run|test result|Tests?:|Suites?:|vulnerabilit|warning)|✓|✕|×|exit='
# ---- ALIAS (nombre -> comando remoto; los args se añaden al final) -----------
alias_cmd() {
  case "$1" in
    # test)        echo "<comando de tests>" ;;
    # test-unit)   echo "<comando de tests de un paquete>" ;;
    # integration) echo "<comando de integración>" ;;
    # e2e)         echo "<comando e2e>" ;;
    # build)       echo "<comando de build>" ;;
    # audit)       echo "<auditor de dependencias, solo runtime, umbral alto>" ;;
    *)             return 1 ;;
  esac
}
# -----------------------------------------------------------------------------

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT" || exit 2
# rsync --delete sobre una ruta mal configurada borraría datos ajenos: ruta absoluta, 2+ niveles, sin «..» ni «//»,
# configurada, y marcada como destino (.sdd-run-target, la crea «run init» tras revisar el --dry-run).
REMOTE_DIR="${REMOTE_DIR%/}"
case "$HOST$REMOTE_DIR" in *"<"*|*">"*) echo "configura HOST y REMOTE_DIR (o DEV_HOST y DEV_DIR)"; exit 2 ;; esac
if ! [[ "$REMOTE_DIR" =~ ^/[^/]+/[^/]+ ]] || [[ "$REMOTE_DIR" == *//* || "$REMOTE_DIR" =~ (^|/)\.\.?(/|$) ]]; then
  echo "REMOTE_DIR debe ser absoluta, de 2+ niveles y sin segmentos «.» o «..» ni «//»: $REMOTE_DIR"; exit 2
fi
mkdir -p "$LOG_DIR"
# Un solo comando a la vez desde esta copia (si hay flock). No protege frente a otras copias que apunten al mismo
# destino: no compartas un REMOTE_DIR entre copias de trabajo.
if command -v flock >/dev/null; then exec 9>"$LOG_DIR/.lock"; flock -n 9 || { echo "otro run en curso en este entorno"; exit 4; }; fi

remote_marked() { ssh "${SSH_OPTS[@]}" "$HOST" "test -f $(printf '%q' "$REMOTE_DIR/.sdd-run-target")"; }

sync_tree() {
  local ex=(); for e in "${EXCLUDES[@]}"; do ex+=(--exclude "$e"); done
  for p in "${PROTECT[@]+"${PROTECT[@]}"}"; do ex+=(--filter "P $p"); done
  ex+=(--filter "P /.sdd-run-target")
  rsync -az --delete "${ex[@]}" "$@" -e "ssh ${SSH_OPTS[*]}" ./ "$HOST:$REMOTE_DIR/"
}

[ $# -ge 1 ] || { echo "uso: run <alias|--raw 'cmd'|sync [--dry-run]|init> [args]"; exit 2; }
if [ "$1" = "init" ]; then
  Q="$(printf '%q' "$REMOTE_DIR")"
  # Nunca el $HOME remoto ni una carpeta suya directa sin confirmar: rsync --delete borraría lo que no esté en local.
  ssh "${SSH_OPTS[@]}" "$HOST" "mkdir -p $Q && test \"\$(cd $Q && pwd -P)\" != \"\$(cd ~ && pwd -P)\"" || { echo "REMOTE_DIR no puede ser el \$HOME remoto"; exit 2; }
  N="$(sync_tree --dry-run --itemize-changes 2>/dev/null | grep -c '^\*deleting' || true)"
  if [ "${2:-}" != "--confirm" ]; then
    echo "La primera sincronización borraría $N entradas en $HOST:$REMOTE_DIR (detalle: run sync --dry-run)."
    echo "Si es correcto: run init --confirm"; exit 2
  fi
  ssh "${SSH_OPTS[@]}" "$HOST" "touch $Q/.sdd-run-target" && echo "destino marcado: $HOST:$REMOTE_DIR"; exit $?
fi
if [ "$1" = "sync" ]; then
  shift
  if [ "${1:-}" = "--dry-run" ]; then sync_tree --dry-run --itemize-changes; exit $?; fi
  remote_marked || { echo "destino sin marcar: revisa «run sync --dry-run» y ejecuta «run init»"; exit 2; }
  sync_tree; exit $?
fi
if [ "$1" = "--raw" ]; then shift; CMD="${1:?falta el comando}"; shift; NAME=raw
else NAME="$1"; shift; CMD="$(alias_cmd "$NAME")" || { echo "alias desconocido: $NAME"; exit 2; }; fi
for a in "$@"; do CMD+=" $(printf '%q' "$a")"; done

remote_marked || { echo "destino sin marcar: revisa «run sync --dry-run» y ejecuta «run init»"; exit 2; }
sync_tree || { echo "sync falló"; exit 3; }
LOG="$LOG_DIR/$(date +%Y%m%d-%H%M%S)-$NAME.log"
ssh "${SSH_OPTS[@]}" "$HOST" "cd $(printf '%q' "$REMOTE_DIR") && $CMD" >"$LOG" 2>&1
RC=$?
ESC="$(printf '\033')"
sed "s/${ESC}\[[0-9;]*m//g" "$LOG" | grep -E "$SUMMARY_RE" | awk '!seen[$0]++' | tail -40 || true
echo "exit=$RC · log: $LOG"
exit $RC
