---
name: sdd-agents
description: >-
  Genera o actualiza AGENTS.md (reglas de trabajo, commits y comandos de verificación),
  docs/sdd-conventions.md (Convenciones SDD), docs/agent-runbook.md (conocimiento operativo) y el
  verificador sdd-check. Úsala
  tras aprobar la constitución o cuando cambien las reglas, los comandos o el entorno de ejecución.
---

# sdd-agents — Manual operativo del proyecto

Deja versionado en el repositorio todo lo que un agente necesita para trabajar sin redescubrir nada.

## Produce

| Artefacto | Contenido |
|---|---|
| `AGENTS.md` | Lo que todo agente necesita siempre (el harness lo carga en cada contexto, así que se mantiene corto): reglas de trabajo, niveles de test, interacción con el usuario, commits y comandos de verificación. Es del proyecto. |
| `docs/sdd-conventions.md` | Copia literal de `assets/sdd-conventions.md`: las Convenciones SDD que las skills citan como «Convenciones › Sección» y leen por secciones. Es del paquete: se sustituye entera al actualizar, nunca se edita en el proyecto. |
| Fichero puente (si hace falta) | Si el harness lee otro fichero de instrucciones en lugar de `AGENTS.md`, ese fichero contiene solo: «Las reglas de este repositorio están en AGENTS.md; léelo y aplícalo». |
| `docs/agent-runbook.md` | Conocimiento operativo: dónde y cómo se ejecuta, comandos con salida resumida, datos de prueba desechables, convenciones de tests y trampas conocidas. Los módulos canónicos viven en plan §4b. |
| Verificador `sdd-check` | Copia de `scripts/sdd-check.mjs` (Node ≥ 18) o de `scripts/sdd_check.py` (Python ≥ 3.8); ambos aplican las mismas reglas y dan la misma salida. |

## Precondiciones

`docs/constitution.md` con `Estado: APROBADA`. Si no: `AGENTS.md BLOQUEADO — Motivo: no hay constitución aprobada — Falta: docs/constitution.md APROBADA — Siguiente paso: sdd-constitution`.

## Procedimiento

1. **Contexto.** Lee `docs/constitution.md` y, si existen, `AGENTS.md`, `docs/agent-runbook.md` y cualquier otro fichero de instrucciones para agentes del repositorio. Conserva lo propio del proyecto que no contradiga SDD; ante un conflicto prevalece SDD y se informa al usuario. El contexto operativo que el usuario aporte desde fuera del repositorio se integra en el runbook, sin secretos.
2. **Comandos.** Inspecciona manifiestos, scripts de build y CI, y rellena la tabla solo con comandos que existan: ejecutables ya disponibles en el entorno (incluidos los nativos del lenguaje o del gestor de paquetes) que funcionan hoy. Cada comando es no interactivo y termina solo: la variante de CI del runner (sin modo watch ni prompts), con límite de tiempo si la herramienta lo admite; lo que necesite un servidor o contenedor en segundo plano indica en el runbook cómo arrancarlo y detenerlo. Asigna a cada fila su columna **Cuándo** según la plantilla. Las instalaciones de dependencias que ejecuten los comandos son congeladas, contra el lockfile (`npm ci`, `--frozen-lockfile`, `pip install --require-hashes` o equivalente). La fila de seguridad es obligatoria: auditor del ecosistema, solo dependencias de runtime, umbral alto; si el proyecto se entrega a clientes, el job de CI incluye **obligatoriamente** un escáner de secretos dedicado (p. ej. gitleaks sobre el rango del PR) y una regla de CODEOWNERS para `.sdd-allowed-secrets`: `sdd-check` solo bloquea los hallazgos de alta confianza y avisa de los heurísticos, así que el escáner dedicado es el control que bloquea el resto (si el usuario lo rechaza, anótalo en la fila Seguridad como `escáner de secretos en CI: rechazado por el usuario AAAA-MM-DD`; sdd-release lo lleva a «Riesgos aceptados»); si no existe, `no disponible: <motivo>`. Sin un comando real (p. ej. el runner existe pero aún no hay tests), cada fila queda como `pendiente: la crea la tarea que introduzca esa herramienta` o `no aplica` (la de seguridad, `no disponible: <motivo>` mientras no haya dependencias). El comando de seguridad debe ignorar los IDs listados en «Excepciones aceptadas» (opción de ignorados del auditor o un envoltorio) para salir con 0 cuando solo queden esos. La fila «Todo» es la lista de comandos de las demás filas, omitiendo las que ya cubre otra (p. ej. un filtro del mismo runner), separados por «·»: el agente ejecuta cada uno e informa de cada resultado (no se encadenan con `&&`; no hace falta un script). Si el auditor admite leer los IDs ignorados desde un fichero, apúntalo a la lista de «Excepciones aceptadas» para mantener una sola fuente. El hook de pre-commit, si se instala, es opcional y no sustituye a `sdd-check pre-commit --task`. Añade a los ignorados del control de versiones los artefactos generados del ecosistema (p. ej. cachés, dependencias instaladas, builds).
3. **Ejecución fuera de la estación local** (servidor, VM, contenedor). Define un único comando del proyecto que cumpla este contrato: sincroniza sin borrar lo protegido, ejecuta, guarda el log completo en local, imprime un resumen y devuelve el exit code real del comando ejecutado.
   - Con SSH y rsync en una estación POSIX, parte de `assets/remote-run.sh` (ruta remota absoluta).
   - Con otro mecanismo (exec en contenedor, CI, Windows), impleméntalo con las herramientas del entorno respetando el mismo contrato.
   - Antes de usarlo: pregunta qué existe solo en el destino y decláralo como protegido, ejecuta la simulación de sincronización y muestra al usuario lo que se borraría; solo con su conformidad explícita marca el destino (`run init`, que crea `.sdd-run-target`; sin esa marca la plantilla nunca sincroniza con borrado). Un destino por copia de trabajo. Añade el directorio de logs a los ignorados del control de versiones.
   - Si todo se ejecuta en local, omite este paso.
4. **Runbook.** Redacta o actualiza `docs/agent-runbook.md` a partir de `assets/agent-runbook.md`, solo con hechos verificados.
5. **Verificador** (prepáralo ahora; se escribe en el repositorio con la confirmación del paso 7, antes del commit). Usa el runtime del proyecto si es Node ≥ 18 o Python ≥ 3.8 (`scripts/sdd-check.mjs` o `scripts/sdd_check.py`); si no es ninguno, el que esté disponible donde trabajan los agentes. Ubícalo en la carpeta de herramientas del repositorio (p. ej. `tools/sdd/`) y exclúyelo de los linters, typecheckers y tests del proyecto si los hubiera. Si ya existe y es más antiguo (`sdd-check --version`), actualízalo y avísalo; si es más nuevo que el del paquete, no lo rebajes: avisa de que hay que actualizar las skills instaladas. Ejecútalo una vez y escribe en la fila `SDD` el comando exacto. Sin ninguno de los dos runtimes: `no disponible: <motivo>` (las skills trabajan en modo manual).
6. **Redacción.** Escribe `AGENTS.md` con la plantilla (máximo unos 12 KB: cada byte se carga en todos los agentes; sin texto añadido que no sea del proyecto) y copia `assets/sdd-conventions.md` a `docs/sdd-conventions.md` sin cambios, indicando el directorio donde están instaladas las skills. Adapta el formato de commits a la convención que ya use el repositorio. Pregunta la política de ramas si no consta. No copies la constitución ni incluyas requisitos o decisiones técnicas. Crea el fichero puente si el harness lo necesita.
7. **Confirmación.** Muestra el contenido (o el diff) y escríbelo, junto con las convenciones, el runbook y el verificador, solo con la conformidad del usuario; si pide cambios, aplícalos y vuelve a mostrarlo. Incluye por defecto en la propuesta (el usuario puede rechazarlos): un hook de pre-commit de git que ejecute `sdd-check pre-commit` (genérico) y, si el proyecto tiene CI, un job que ejecute `sdd-check pre-commit --range <rama base>...HEAD` en cada PR. El agente que ejecuta el pre-commit no puede ser el único control: la CI cubre los commits hechos a mano, sin hook o con `sdd-allow-secret` (que en CI exige en `.sdd-allowed-secrets` de la rama base el sha256 de fichero y línea que muestra el FAIL; fichero que solo editan personas). Commit `docs: reglas de agentes y runbook` (quita en él la línea `Bloqueada` de la tarea que esperaba un comando, si la hay).
8. `Siguiente paso: sdd-spec` (o `sdd-orchestrator` si ya existen specs). DETENTE.

## Plantilla de `AGENTS.md`

En `assets/AGENTS.template.md`. Se copia y se rellena (comandos, ramas, directorio de skills); el marcador `<!-- sdd-conventions: 3 -->` se conserva. Al actualizar un `AGENTS.md` existente, se fusiona con la plantilla preservando el contenido propio del proyecto. Desde el marcador 2: las secciones de convenciones que ya no están en la plantilla se eliminan de `AGENTS.md` (viven en `docs/sdd-conventions.md`), la sección Delegación larga se sustituye por la línea de la plantilla (las reglas viven en `sdd-orchestrator`) y se añaden las reglas 14-16; la tabla de comandos, las excepciones aceptadas y las ramas se conservan.

## Validación

- `AGENTS.md` contiene reglas, delegación, niveles de test, interacción, commits y tabla de comandos con «Cuándo»; `docs/sdd-conventions.md` es idéntico al del paquete.
- Ningún comando inventado ni requisito de producto; runbook sin secretos.
- Verificador instalado y ejecutado, o fila SDD `no disponible` con motivo.
- El usuario confirmó antes de escribir.

## Prohibido

Incluir requisitos o decisiones técnicas; sobrescribir sin preservar el contenido no conflictivo; dejar conocimiento operativo fuera del repositorio; escribir código de producto, tests o specs.
