---
name: sdd-refactor
description: >-
  Mejora interna sin cambio observable, protegida por tests; consume la deuda registrada en
  reviews/backlog.md y consolida lógica duplicada en módulos canónicos. Úsala para deuda técnica,
  limpieza, reestructuración o actualizaciones menores de dependencias.
---

# sdd-refactor — Mejora interna sin cambio funcional

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

Un refactor cambia **cómo** está construido el código, no **qué** hace ni cómo se ve la interfaz.

## Precondiciones

Constitución `APROBADA` y `AGENTS.md` existente; árbol limpio; línea base de tests en verde.

## Procedimiento

1. **Objetivo y alcance mínimo.** Fuentes: filas `ABIERTO` del backlog (Convenciones › Backlog) con Ruta `sdd-refactor` (se agrupan las del mismo módulo) o el pedido del usuario.
2. **Línea base** en verde con los comandos del área.
3. Si falta protección, añade primero tests de caracterización mínimos.
4. Cambios pequeños, sin capacidades nuevas, con tests tras cada cambio relevante. Si consolidas lógica duplicada en un módulo canónico nuevo, añade una fila MEDIO al backlog, con la Spec cuyo plan es dueño del módulo y Ruta `sdd-plan`, para registrarlo en su §4b (si ninguna lo es, no hace falta fila).
5. **Verificación** según la columna «Cuándo» (si el refactor aplica el parche de una «Excepción aceptada», retira la excepción y su ID de los ignorados del comando de seguridad); si tocas módulos compartidos, la suite del paquete o componente y los E2E. En dependencias, también el check de seguridad (Convenciones › Riesgos y vulnerabilidades); un salto de versión mayor solo con aprobación explícita; sin ella, la fila queda abierta y DETENTE.
6. Revisa el diff: ningún cambio funcional ni visual accidental.
7. Commit según `AGENTS.md` › Commits (`refactor: …`; si resuelve el `Siguiente paso` de una validación o release de una spec, `refactor(NNN-slug): …`); las filas resueltas del backlog pasan a `HECHO` y se quita la línea `Bloqueada` de la tarea que esperaba este refactor, si la hay.

## Desvíos

Cambia comportamiento o interfaz → `sdd-change` · aparece un defecto → `sdd-bug` (o una fila en el backlog) · requiere una decisión de arquitectura o un contrato nuevo → `sdd-plan` o `sdd-change`.

## Salida

```text
REFACTOR: <objetivo> · FICHEROS: <resumen> · BACKLOG: <R-NNN cerrados>
TESTS: <comando> → PASS/FAIL · VERIFICACIONES: <resumen>
RESULTADO: COMPLETADO | BLOQUEADO — Motivo: … — Falta: … — Siguiente paso: <skill>
```

## Prohibido

Cambiar comportamiento o interfaz; añadir capacidades; mezclar el refactor con una funcionalidad o un arreglo; avanzar sin línea base en verde.
