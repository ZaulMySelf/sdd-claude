---
name: sdd-spec
description: >-
  Escribe specs/NNN-slug/spec.md por entrevista: QUÉ y POR QUÉ en EARS, estados y transiciones,
  sistemas externos, permisos, errores e interfaz declarada por el usuario con sus referencias
  visuales, sin tecnología. Úsala para una funcionalidad nueva.
---

# sdd-spec — Especificación funcional

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

## Precondiciones

- Constitución `APROBADA` y `AGENTS.md` existente. Si no: `SPEC BLOQUEADA — Motivo: … — Falta: constitución aprobada o AGENTS.md — Siguiente paso: sdd-constitution | sdd-agents`.
- Si hay otra spec no completada (según `sdd-orchestrator`), recomienda cerrarla antes. `Depende de: NNN-slug` se declara solo si la nueva necesita la otra terminada; si el usuario quiere avanzar en paralelo sin dependencia real, se omite y el orquestador desempata.

## Procedimiento

1. **Contexto.** Lee constitución, brief y specs relacionadas (para no duplicar requisitos). Si otra spec ya cita la nueva (`movido a NNN-slug`, `espera a NNN-slug`), usa ese número y slug exactos; si no, número = máximo `NNN` existente en todas las ramas + 1; slug corto en kebab-case, preferiblemente ASCII. Nunca reutilices números.
2. **Entrevista por bloques** de 3 a 5 preguntas: problema · actores · comportamiento · permisos · estados · datos (semántica) · límites y volúmenes · errores · seguridad funcional · casos límite · fuera de alcance · criterios de aceptación. Puedes proponer un valor; solo se registra si el usuario lo confirma. Lo no decidido queda como `[NECESITA ACLARACIÓN: …]`.
3. **Bloques obligatorios cuando aplican** (son los huecos que más defectos producen):
   - **Estados:** tabla estado × evento → siguiente estado, incluidos cancelar, reintentar, revertir, fallo parcial, reinicio del sistema y dos actores simultáneos. Solo las combinaciones posibles; las imposibles se agrupan en una línea («resto: rechazado con <error>»). Sin estados: `No aplica`.
   - **Sistemas externos:** por sistema, plataformas o versiones en alcance, datos de conexión que se piden al usuario (incluidos ámbitos como dominio, proyecto, zona o región), operaciones esperadas, qué ocurre si una operación no está soportada y **si hay un entorno real para verificarlo**. Sin entorno de verificación: riesgo declarado o fuera de alcance, según decida el usuario.
   - **Permisos:** tabla Rol × Acción × Permitido, y la semántica de propiedad («propio») y a qué acciones aplica.
   - **Errores:** catálogo condición → comportamiento observable (código o mensaje visible), sin éxitos silenciosos.
4. **Interfaz.** Pregunta si la funcionalidad tiene interfaz. Si la tiene, registra tal cual las decisiones del usuario como `UI-NNN` (vistas, componentes, estados visibles, textos, idioma y tono, adaptación a dispositivos). Las maquetas de referencia se guardan en `specs/NNN-slug/assets/` y cada UI-NNN cita su referencia y viewport. No propongas diseño; lo que falte queda marcado. No crees documentos de interfaz fuera de la spec.
5. **Herencia por partición.** Si la spec nace de partir otra (`sdd-change`), los RF movidos ya implementados se copian con su ID nuevo y la referencia `(antes NNN RF-XXX · Test: <test existente>)` y no se reimplementan (`AGENTS.md` › Niveles de test); los no implementados entran como RF normales.
6. **Verificabilidad.** Para cada RF y UI: «¿se puede escribir un test o una comprobación objetiva que lo demuestre?». Si no, reescríbelo o márcalo.
7. **Tamaño.** Propón `S`, `M` o `L` según Convenciones › Tamaño de spec. Con más de unos 25 RF, propone partir la funcionalidad en varias specs.
8. Escribe la spec, muéstrala y commitea `docs(NNN-slug): spec v1`. `Siguiente paso: sdd-clarify`. DETENTE.

## EARS

`EL SISTEMA <respuesta>.` · `CUANDO <evento>, EL SISTEMA <respuesta>.` · `MIENTRAS <estado>, EL SISTEMA <respuesta>.` · `DONDE <condición>, EL SISTEMA <respuesta>.` · `SI <evento no deseado>, ENTONCES EL SISTEMA <respuesta>.`

## Plantilla de `spec.md`

```markdown
# <Título>

| Campo | Valor |
|---|---|
| Spec-ID | NNN-slug |
| Versión | 1 |
| Estado | BORRADOR |
| Aprobación | PENDIENTE |
| Tamaño | S / M / L |
| Interfaz | SÍ / NO |
| Origen | NUEVA / RETRO |
| Depende de | — / NNN-slug |

## Contexto y problema
## Objetivo
## Actores
## Historias de usuario
## Requisitos funcionales
- RF-001: …
## Requisitos no funcionales
- RNF-001: …
## Estados y transiciones
| Estado | Evento | Siguiente | Condición / efecto |
## Sistemas externos
| Sistema | Alcance | Datos de conexión | Operaciones | No soportado → | Entorno de verificación |
## Permisos
| Rol | Acción | Permitido |
Semántica de propiedad: …
## Errores
| Condición | Comportamiento observable |
## Casos límite
## Seguridad funcional
## Interfaz (omitir si Interfaz = NO)
- UI-001: <decisión tal como la declaró el usuario> (RF relacionados) · Ref: assets/<fichero> @ <viewport>
## Fuera de alcance
## Criterios de finalización
- [ ] …
## Decisiones pendientes

## Registro de cambios
| Versión | Fecha | Clasificación | Cambio |
| 1 | AAAA-MM-DD | — | Creación |
```

## Validación

- IDs únicos; cada RF y UI verificable o marcado.
- Tabla de estados sin celdas indefinidas; sistemas externos con datos de conexión y entorno de verificación declarados.
- Sin tecnología, arquitectura ni modelo físico salvo restricción explícita del usuario.
- Sin decisiones de interfaz que el usuario no haya declarado.
- `Fuera de alcance` y `Criterios de finalización` presentes.

## Prohibido

Diseñar arquitectura, elegir tecnologías, escribir código, resolver ambigüedades por cuenta propia, aprobar la spec, crear artefactos de interfaz fuera de la spec y de `assets/`.
