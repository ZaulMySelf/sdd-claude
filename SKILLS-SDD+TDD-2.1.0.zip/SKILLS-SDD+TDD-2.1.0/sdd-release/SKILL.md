---
name: sdd-release
description: >-
  Gate READY/BLOCKED antes de merge o despliegue: evidencia vigente, alcance del diff, secretos,
  migración, backlog, documentación y resumen de PR; archiva el ciclo cerrado. No hace merge ni
  despliegue. Úsala con SPEC CUMPLIDA: SÍ.
---

# sdd-release — Gate de release

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

## Precondiciones

`validation.md` vigente con `SPEC CUMPLIDA: SÍ`; si el plan exige migración, `MIGRACIÓN: SUFICIENTE`; `sdd-check --spec NNN-slug` sin `PROBLEMA`; árbol limpio (`AGENTS.md` › Commits). Si no: `RELEASE BLOQUEADO — Motivo: … — Falta: … — Siguiente paso: <skill según la causa (sdd-validate, sdd-migration…)>`.

## Re-sellado

Si `release.md` está caducado o sin versión, con `RELEASE: READY`, y desde su último commit no han cambiado la spec, el plan ni el código (Convenciones › Versiones), actualiza la cabecera y conserva el veredicto. En cualquier otro caso, gate completo.

## Adopción (specs ya terminadas antes de usar el flujo)

Si el usuario confirma explícitamente que una spec heredada ya está terminada y en producción, normaliza antes la cabecera de `spec.md` (Spec-ID y Versión reales) y escribe `release.md` con `Evidencia: ADOPCIÓN (confirmada por el usuario AAAA-MM-DD, sin re-validar)`, las versiones vigentes y `RELEASE: READY`, sin pasar por validate ni re-sellar los demás artefactos; las tareas `[x]` heredadas pasan a `tasks-archive.md` (bloque `## Ciclo <fecha> (adopción)`). Si la carpeta de la spec tiene ficheros ajenos al flujo, pregunta una vez por cada uno «¿integrar en la spec (sdd-change) o archivar?» y archiva en el mismo commit los que el usuario indique. Commit y DETENTE.

Tras un bug corregido en una spec adoptada (el verificador lo indica), se repite este modo reutilizando la confirmación original, con la fila «Todo» ejecutada y su resultado en el release, sin pasar por clarify, plan ni tasks. Si la fila Todo falla: `RELEASE: BLOCKED` de adopción (se conserva `Evidencia: ADOPCIÓN …`) con `Siguiente paso: sdd-bug`.

## Procedimiento

1. **Reutilización.** Un resultado de CI verde sobre el mismo commit cuenta como evidencia si ejecutó todos los comandos de la fila «Todo» (lo que no cubra se ejecuta aquí). Si desde el commit de `validation.md` solo han cambiado `specs/`, `docs/`, `reviews/` o `AGENTS.md` y el árbol está limpio, reutiliza sus resultados; si cambió código, vuelve a ejecutar la fila «Todo».
2. **Diff y alcance.** Revisa el diff del ciclo y marca los cambios fuera de alcance no justificados.
3. **Seguridad y configuración.** Secretos accidentales (incluidos los AVISO de «posible secreto» de `sdd-check`), variables, flags y configuración nueva documentada. Un proyecto entregado a clientes sin escáner de secretos dedicado en CI (o con la anotación «rechazado por el usuario» en la fila Seguridad) lo lista en «Riesgos aceptados»; no bloquea. Check de seguridad según Convenciones › Riesgos y vulnerabilidades; lo no bloqueante va a Riesgos. Revisa cada «Excepción aceptada»: si ya hay parche, deja de ser excepción y la release queda `BLOCKED` hacia `sdd-refactor`.
4. **Migración y rollback.** Lo previsto en el plan está implementado y es reversible.
5. **Backlog.** Ninguna fila CRÍTICO o ALTO `ABIERTO` de esta spec ni global (Spec `—`); las MEDIO abiertas se listan en Riesgos.
6. **Documentación.** No crea documentos nuevos salvo que la spec los exija (la configuración nueva se documenta en los existentes: README, runbook o el fichero de ejemplo de configuración); actualiza solo lo directamente afectado y desactualizado (README, documentación de API, runbooks, configuración, `docs/agent-runbook.md`); los comandos y ejemplos nuevos o cambiados se ejecutan (o se marcan «no verificado» con el motivo); ejecuta los validadores de documentación si existen.
7. Escribe `release.md` con el veredicto. **READY** solo si: verificaciones con evidencia vigente, ningún gate pendiente, ningún cambio fuera de alcance sin justificar, migración y rollback resueltos, backlog sin bloqueantes y documentación sincronizada o N/A.
8. **Archivado (único dueño).** Con READY: mueve las tareas `[x]` del ciclo a `tasks-archive.md` (IDs intactos; en `tasks.md` queda la trazabilidad vigente) y, con la conformidad del usuario, lleva a `specs/NNN-slug/archive/` los ficheros ajenos al flujo que señale `sdd-check` (los que contengan requisitos se integran antes en la spec con `sdd-change`). `tasks-archive.md`: título `# Tareas archivadas — NNN-slug` y un bloque `## Ciclo <fecha> (spec vS)` por release (si el ciclo no tiene tareas que archivar, no se añade bloque).
9. Commit `docs(NNN-slug): release` (con `sdd-check pre-commit` genérico). DETENTE.

## Plantilla de `release.md`

```markdown
# Release — NNN-slug

| Campo | Valor |
|---|---|
| Spec-Version | N |
| Plan-Version | M |
| Commit | <sha del commit sobre el que se evalúa, anterior al commit de release> |
| Evidencia | reutilizada de validation / re-ejecutada |

| Control | Evidencia | Resultado |
|---|---|---|
| Tests y verificaciones | | |
| Diff y alcance | | |
| Secretos y configuración | | |
| Migración y rollback | | |
| Backlog | | |
| Excepciones aceptadas (revisión) | | |
| Documentación | <ficheros actualizados o N/A> | |

## Riesgos
## Riesgos aceptados (qué · fecha · motivo)

## Resumen para PR
Qué cambia · RF cubiertos · riesgos · cómo probar.

Siguiente paso: <— si READY | skill concreta si BLOCKED>

RELEASE: READY | BLOCKED
```

## Prohibido

Merge, despliegue o publicación; corregir código o tests; marcar READY con fallos relevantes o backlog bloqueante; reescribir documentación ajena al cambio.
