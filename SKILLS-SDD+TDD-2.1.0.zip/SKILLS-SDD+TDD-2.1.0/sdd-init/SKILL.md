---
name: sdd-init
description: >-
  Crea docs/brief.md (problema, usuarios, objetivos, restricciones) por entrevista e inspección del
  repositorio. Primer paso de un proyecto SDD, nuevo o existente.
---

# sdd-init — Inicialización del proyecto

Deja en `docs/brief.md` el entendimiento del proyecto antes de cualquier otro artefacto SDD.

## Precondiciones

Si ya existe `docs/brief.md`: `INICIALIZACIÓN BLOQUEADA — Motivo: ya existe un brief — Falta: nada (el brief ya existe) — Siguiente paso: sdd-constitution` (o `sdd-orchestrator` si también hay constitución). Nunca lo sobrescribas.

## Procedimiento

1. **Repositorio existente.** Si hay código, inspecciona manifiestos, estructura y documentación antes de preguntar. Resume stack, módulos y convenciones detectadas; el stack existente se registra como *restricción existente* cuando el usuario lo confirma. No preguntes lo que el repositorio ya responde.
2. **Entrevista por bloques** de 3 a 5 preguntas relacionadas: problema · usuarios y actores · objetivos y cómo se sabrá que funcionó · funcionalidades imaginadas · restricciones (regulatorias, de integración, de plataforma, técnicas impuestas) · fuera de alcance.
3. **Clasifica** cada respuesta como requisito de producto o decisión de implementación. Una decisión técnica que no sea una restricción impuesta va a «Decisiones abiertas», nunca a requisitos.
4. Cuando puedas explicar problema, usuarios, objetivo y restricciones sin inventar nada, muestra el brief y pide confirmación. Con un sí, escríbelo con `Estado: CONFIRMADO (AAAA-MM-DD, por el usuario)` y commitea `docs: brief`; con correcciones, aplícalas y vuelve a mostrarlo.
5. `Siguiente paso: sdd-constitution`. DETENTE.

## Plantilla de `docs/brief.md`

```markdown
# Brief del proyecto

> Estado: CONFIRMADO (AAAA-MM-DD, por el usuario) — contexto de partida; no es una especificación

## Problema
## Usuarios y actores
## Objetivos y resultado esperado
## Funcionalidades imaginadas (tentativas)
## Restricciones (impuestas o existentes en el repositorio)
## Estado actual del repositorio (solo si ya hay código)
## Decisiones abiertas
## Fuera de alcance (preliminar)
```

## Validación

- Nada inventado: todo procede del usuario o del repositorio, o figura en «Decisiones abiertas».
- Ninguna elección de stack salvo restricción impuesta o existente confirmada.
- El usuario confirmó el brief.

## Prohibido

Elegir o sugerir tecnologías; escribir código o tests; crear specs, constitución o `AGENTS.md`; inventar requisitos.
