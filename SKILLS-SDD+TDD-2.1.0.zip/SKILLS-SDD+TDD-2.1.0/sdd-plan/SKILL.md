---
name: sdd-plan
description: >-
  Diseño técnico (plan.md) de una spec aprobada, en modo completo, breve o delta: contratos externos
  verificados, módulos canónicos, concurrencia, nivel de test por requisito y autocomprobación de
  migración; una sola aprobación si hay decisiones D-NNN o migración. Úsala tras sdd-clarify, tras un
  cambio de spec o cuando una revisión de migración o de trazabilidad lo pide.
---

# sdd-plan — Diseño técnico (CÓMO)

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

## Precondiciones

`docs/constitution.md` leída; spec `APROBADA` con aprobación registrada, `clarify.md` vigente con `SPEC CLARIFICADA: SÍ` y ningún `[NECESITA ACLARACIÓN:`. Si falta algo: `PLAN BLOQUEADO — Motivo: … — Falta: … — Siguiente paso: sdd-clarify`.

## Modos

| Modo | Cuándo |
|---|---|
| Delta | Existe plan, o spec RETRO/adoptada sin plan (ver abajo). Conserva el diseño y edita solo lo afectado. |
| Breve | `Tamaño: S`: solo las secciones que aplican (§5 y §9 siempre). |
| Completo | No existe plan (salvo RETRO o spec adoptada, que van por Delta). Las secciones obligatorias se aplican a `M` y `L`. |

Casos del modo Delta:
- Cambio de spec `[LOCAL]` o `[ESTRUCTURAL]`: se edita en sitio conservando IDs y secciones; un `[ESTRUCTURAL]` añade D-NNN o §10 solo si hay decisión técnica o migración, y siempre pasa el gate.
- Spec RETRO o adoptada sin plan: describe lo existente afectado como restricción, con §4b y §9, y solo diseña el cambio.
- Dependencia nueva o actualización mayor: nueva D-NNN, misma Spec-Version.
- Llamada desde `MIGRACIÓN: INCOMPLETA`, `TRAZABILIDAD: FAIL`, una tarea `Bloqueada: … → sdd-plan` (nivel de test inalcanzable, dependencia o decisión técnica no prevista) o filas del backlog con Ruta `sdd-plan`.

Un plan `PENDIENTE` sin cambios desde su último gate solo repite el gate, sin redactar de nuevo.

## Re-sellado

Si `plan.md` está caducado o sin versión pero la spec no ha cambiado de contenido desde su último commit, o el cambio es `[LOCAL]` y no afecta a ninguna decisión ni sección del plan (Convenciones › Versiones), actualiza la Spec-Version de la cabecera sin subir `Plan-Version`, conserva la aprobación y añade «Re-sellado vN: sin cambios». Si la migración de §10 ya tuvo su release READY, este re-sellado pone `Migración requerida: NO`. Commit y DETENTE.

## Procedimiento

1. Inspecciona el repositorio (stack, estructura, convenciones, módulos reutilizables) para diseñar dentro de lo existente o justificar la desviación.
2. Redacta `plan.md`; cada sección lleva contenido o `No aplica (motivo)`. Obligatorio en M y L:
   - **§4a Contratos externos.** Por sistema: autenticación real, parámetros obligatorios, operaciones usadas y **fuente oficial** (o fuente verificada). Un contrato que no se puede verificar (sin documentación ni entorno) es un riesgo que decide el usuario: fuera de alcance, spike previo o riesgo aceptado. Nunca se planifica como si estuviera verificado.
   - **§4b Módulos canónicos.** La única fuente de cada concepto transversal (catálogos, estados y su máquina de transiciones, entidades y permisos, formatos y textos, clientes externos, errores) y sus consumidores.
   - **§5 Seguridad y límites** (obligatoria en todos los tamaños si hay entradas nuevas: usuario, red, ficheros, sistema externo). Por entrada: amenaza y mitigación verificable (validación y tamaño máximo, autorización en el servidor, inyección, rutas de fichero, SSRF), timeouts de toda llamada saliente, idempotencia y manejo de secretos. Cada mitigación tendrá un test negativo (sdd-tasks).
   - **§6 Concurrencia, estados y errores.** Cómo se garantiza cada transición de la spec frente a escrituras concurrentes, reinicios y fallos parciales; qué se registra en logs y métricas para diagnosticar fallos, sin secretos ni datos personales.
   - **§9 Estrategia de tests** (obligatoria en todos los tamaños, también S). Tabla `Requisito → Nivel → qué demuestra / fuente de fixtures`, con los mínimos de `AGENTS.md` › Niveles de test. Si un mínimo no es alcanzable, pregunta al usuario y registra «nivel reducido aceptado (motivo, fecha)». En RETRO, los RF no tocados: nivel `CARACTERIZACIÓN` (lo existente más su test).
3. **Decisiones** difíciles de revertir, que afectan a varios RF o que añaden una dependencia → D-NNN, elegidas por requisitos, simplicidad, mantenibilidad, seguridad, madurez, operación y facilidad de trabajo con agentes. Cada D-NNN se contrasta con los principios de la constitución: si contradice alguno, `PLAN BLOQUEADO — Motivo: D-NNN contradice P-XX — Falta: enmienda o alternativa — Siguiente paso: sdd-constitution` (o se elige otra opción). Para dependencias: nombre exacto comprobado en el registro oficial (los paquetes con nombre parecido o inexistentes son un riesgo de suplantación), versión estable, licencia y mantenimiento revisados, y sin vulnerabilidades altas o críticas; si la única opción tiene una sin parche, el gate la presenta y, con un sí del usuario, se registra en «Excepciones aceptadas» de `AGENTS.md` (Convenciones › Riesgos y vulnerabilidades).
4. Un requisito no visual que falte o sea ambiguo en la spec: DETENTE y propone `sdd-change` (el plan no lo inventa).
4b. **Interfaz:** cómo se implementan los UI-NNN (componentes, design system, rutas) y cómo se verifican sus referencias visuales. Sin decisiones visuales nuevas: si falta una, DETENTE y propone `sdd-change`.
5. **Cobertura:** cada RF, RNF y UI con las secciones o D-NNN que lo cubren.
6. **Autocomprobación de migración** (si `Migración requerida: SÍ`): antes de mostrar el plan, §10 cubre estado inicial y final, datos existentes, coexistencia de versiones, backfill, validación e idempotencia, rollback y fallo parcial, y tests de compatibilidad y rollback (INTEG). `sdd-migration` debe confirmar, no descubrir.
7. Muestra el plan (o el diff en modo delta).
8. **Gate único.** Al presentar una vulnerabilidad sin parche, contrástala con los RNF de seguridad de la spec; si contradice alguno, el usuario debe decidir entre cambiar la dependencia o el RNF (`sdd-change`), no basta con aceptarla. Si se añade o modifica alguna D-NNN, cambia la §10 de migración, se registra un nivel reducido o quedan huecos sin resolver (paso 9), pregunta una sola vez: «¿Apruebas este plan técnico? (sí/no)». Con un sí: `Aprobación: APROBADO (AAAA-MM-DD, por el usuario)`. Con un no: pide qué cambiar, regístralo en el registro de cambios, aplícalo y vuelve a preguntar solo tras editar; sin indicaciones, `PLAN BLOQUEADO — Motivo: rechazado sin cambios concretos — Falta: decisión del usuario — Siguiente paso: sdd-plan`. Si no aplica: `Aprobación: NO REQUERIDA`; en modo delta sobre un plan ya aprobado, conserva la aprobación anterior y añade `· vM: NO REQUERIDA`.
9. **Versión** (Convenciones › Versiones). Toda edición de contenido de un plan aprobado o `NO REQUERIDA` sube `Plan-Version`; un plan `PENDIENTE` se edita sin subirla. Si se llegó por `INCOMPLETA` o `FAIL`: resuelve cada hueco listado; si concluyes que alguno no requiere cambios, o no puedes resolverlo, el plan queda `Aprobación: PENDIENTE` y el gate presenta al usuario esos huecos con tu propuesta. Los que el usuario acepte se registran en «Huecos aceptados» (hueco, motivo, fecha), y `sdd-migration` y `sdd-tasks` ya no los cuentan. Las filas del backlog con Ruta `sdd-plan` que esta versión resuelve pasan a `HECHO` (Convenciones › Backlog). Una ronda que llega por `INCOMPLETA` o `FAIL` termina siempre subiendo `Plan-Version` (aunque solo registre huecos aceptados o un nivel reducido), para que migración y tasks se rehagan sobre ella. Así ningún ciclo plan ↔ tasks ↔ migración se repite sin una decisión humana.
10. Commit `docs(NNN-slug): plan vM`. `Siguiente paso: sdd-migration` si hay migración; si no, `sdd-tasks`. DETENTE.

## Plantilla de `plan.md`

```markdown
# Plan técnico — NNN-slug

| Campo | Valor |
|---|---|
| Spec-Version | N |
| Plan-Version | M |
| Modo | COMPLETO / BREVE / DELTA |
| Migración requerida | SÍ / NO (SÍ mientras §10 tenga una migración aún sin release READY; pasa a NO en la primera versión del plan posterior a ese release, salvo que el usuario indique que no se ha desplegado) |
| Aprobación | PENDIENTE / APROBADO / NO REQUERIDA |

## 1. Arquitectura y componentes
## 2. Stack y dependencias (D-NNN)
## 3. Modelo de datos (incluidas restricciones de integridad)
## 4. APIs y contratos
### 4a. Contratos externos
| Sistema | Autenticación | Parámetros | Operaciones | Fuente | Verificado |
### 4b. Módulos canónicos
| Concepto | Módulo | Consumidores |
## 5. Seguridad y límites
## 6. Concurrencia, estados y errores
## 7. Configuración
## 8. Interfaz
## 9. Estrategia de tests
| Requisito | Nivel | Qué demuestra / fuente de fixtures |
## 10. Migración y compatibilidad (COMPATIBLE / POR FASES / BREAKING · estrategia · rollback)
## 11. Despliegue y rollback
## 12. Rendimiento

## Cobertura
| Requisito | Cubierto en |
|---|---|

## Huecos aceptados (hueco · motivo · fecha · por el usuario)

## Decisiones
### D-001 — <título>
- Decisión · Motivo · Alternativas descartadas · Cubre: RF-…

## Registro de cambios
| Plan-Version | Fecha | Cambio |
```

## Sin cambio necesario

Si el motivo de la llamada (tarea `Bloqueada: … → sdd-plan`, fila del backlog, veredicto NO de validate o BLOCKED de release) no requiere cambiar el plan —p. ej. el usuario no acepta rebajar un nivel porque tendrá el entorno—, no edites el plan: quita la línea `Bloqueada` (o conviértela en `Requiere usuario: SÍ — <qué>` si se espera al usuario; conserva la referencia `Aparcado: WIP …` si la había), cierra o reencamina la fila del backlog y commitea `docs(NNN-slug): …`. Si venía de un veredicto NO o BLOCKED y no hay nada que commitear, informa «requiere acción» con lo que falta (p. ej. el entorno para el nivel exigido): el orquestador no la relanza. DETENTE.

## Prohibido

Escribir código o tests; modificar la spec (si es incorrecta → `sdd-change`); añadir comportamiento o diseño visual no presente en la spec; dejar decisiones importantes sin justificar, contratos externos sin fuente, lógica transversal sin módulo canónico o requisitos sin nivel de test; pedir aprobación con huecos de migración conocidos.
