---
name: sdd-tasks
description: >-
  Verifica la trazabilidad spec↔plan (incluido el nivel de test de cada requisito) y descompone el
  plan en tareas pequeñas con tests, nivel, verificaciones, puntos de contacto y criterio objetivo
  (tasks.md). Úsala tras sdd-plan o sdd-migration, o cuando sdd-validate detecta un hueco.
---

# sdd-tasks — Trazabilidad y descomposición

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

## Precondiciones

Spec `APROBADA`; `plan.md` con la Spec-Version vigente y `Aprobación` distinta de `PENDIENTE`; si el plan exige migración, `MIGRACIÓN: SUFICIENTE`. Si falta algo: `TAREAS BLOQUEADAS — Motivo: … — Falta: … — Siguiente paso: sdd-plan | sdd-migration`.

## Modos

| Modo | Cuándo | Qué hace |
|---|---|---|
| Completo | No existe `tasks.md` | Trazabilidad + descomposición completas. |
| Re-edición | `tasks.md` existe pero está caducado (spec o plan con versión nueva) y el cambio le afecta | Rehace la trazabilidad, reabre solo las tareas afectadas (si una está archivada, crea su sustituta, limitada al delta del cambio), cierra como `N/A` las de RF eliminados o movidos (Convenciones › Tareas y evidencia), añade las nuevas al final sin renumerar y actualiza la cabecera. Nunca regenera desde cero. |
| Hueco de validación | `validation.md` declara `Siguiente paso: sdd-tasks` | Añade al final las tareas que cubren los huecos listados, sin tocar las demás. |
| Reparación | Tarea `Requiere usuario` o REAL cuyo nivel el usuario rebajó en plan §9: se cierra N/A (Convenciones › Tareas y evidencia). También: `tasks.md` vigente con un `PROBLEMA` del verificador (IDs duplicados, archivada reabierta, dependencias irresolubles), una tarea `Bloqueada: … → sdd-tasks` o una fila del backlog con Ruta `sdd-tasks` | Corrige solo lo afectado (renumera duplicados nuevos, crea la sustituta de una archivada con `Sustituye a:`, divide o rehace la tarea mal descompuesta, ajusta dependencias), quita la línea `Bloqueada` resuelta y, si venía del backlog, actualiza la fila (Ruta hacia la sustituta, o `HECHO`; Convenciones › Backlog). |

## Re-sellado

Si `tasks.md` está caducado o sin versión pero ni la spec ni el plan han cambiado de contenido desde su último commit (o el cambio `[LOCAL]` no afecta a sus tareas), actualiza solo la cabecera, quita las líneas `Bloqueada` cuya causa resolvió la nueva versión de spec o plan, y añade «Re-sellado vN: sin cambios» (Convenciones › Versiones). Commit y DETENTE.

## Procedimiento

1. **Trazabilidad.** Recorre todos los RF, RNF y UI contra la tabla de cobertura del plan y su §9. Es FAIL si algún requisito:
   - no tiene cobertura real;
   - no tiene nivel de test en §9, o lo tiene por debajo del mínimo (`AGENTS.md` › Niveles de test) sin que §9 lo registre como «nivel reducido aceptado»;
   - o si hay contradicciones spec↔plan o componentes sin requisito.
   En specs RETRO o adoptadas, los RF no tocados, y en cualquier spec los RF heredados por partición, se trazan a su test existente (nivel `CARACTERIZACIÓN`), sin tarea nueva. Los huecos que el plan registra como «aceptados por el usuario» no cuentan.
   **Con FAIL:** si los huecos son los mismos que los del FAIL anterior (sin cambios desde entonces), DETENTE y llévalos al usuario en lugar de devolverlos a sdd-plan. En otro caso, conserva intactas las tareas existentes y su evidencia; actualiza solo la sección de trazabilidad (marcando los huecos), añade `Siguiente paso: sdd-plan` (o `sdd-change` si el requisito está mal planteado) y cambia el veredicto a `TRAZABILIDAD: FAIL`. Commit y DETENTE.
2. **Descomposición.** Una tarea = un comportamiento + sus tests + un resultado verificable en una ejecución (orientativo: hasta 6 ficheros).
3. **Orden que evita re-trabajo.**
   - Por cada sistema externo: una tarea de contrato temprana (cliente y tests CONTRATO con fixtures documentadas) antes de las que lo usan; y, si hay entorno real, una verificación REAL temprana (`Requiere usuario: SÍ`) antes de construir encima. Nunca al final (en mantenimiento, en la primera tarea del ciclo que toque ese sistema).
   - Los módulos canónicos del plan antes que sus consumidores.
   - Una tarea con `Requiere usuario: SÍ` solo es dependencia de otra cuando de verdad lo es.
3b. **Filas de la tabla de comandos.** La primera tarea con tests de un nivel (integración, contrato, E2E), y la que introduce la primera dependencia de runtime (fila Seguridad), incluye en «Verificaciones» actualizar su fila `pendiente` de la tabla de comandos con el comando real, aunque el runner sea nativo.
4. **Puntos de contacto.** Por cada entidad, tipo, permiso, estado o ruta nuevos o modificados, enumera todos sus consumidores (según el plan y una búsqueda en el código): p. ej. datos iniciales, autorización, navegación, configuración de permisos, catálogos, validaciones, E2E, textos y documentación de API. Incluye los tests existentes cuyo comportamiento esperado cambia. Van en la tarea o en tareas propias.
5. **Numeración.** `T-NNN` continúa la existente (incluidas las archivadas); una tarea depende de tareas anteriores o de las añadidas en la misma re-edición o reparación (un prerrequisito nuevo puede quedar con número mayor que la tarea reabierta que lo necesita). `Sustituye a:` admite varias: `Sustituye a: T-003, T-007`. Las archivadas no se reabren: la nueva lleva `Sustituye a: T-XXX`.
6. **Comprobaciones.** Cada RF, RNF y UI aparece en al menos una tarea al nivel exigido (salvo los trazados a `CARACTERIZACIÓN`); cada fila de Permisos con `Permitido: NO` tiene un test negativo; cada transición de la tabla de estados tiene un test (incluidas concurrencia, cancelación y fallo parcial si la spec las define); cada fila del catálogo de Errores tiene un test de su comportamiento observable; cada mitigación verificable de plan §5 (validación y tamaño de entradas, autorización, timeouts, idempotencia) tiene un test negativo.
7. **Re-edición:** en las tareas reabiertas, `- [ ]`, marcador `pendiente` y `- Reabierta: <motivo>`; quita las líneas `Bloqueada` cuya causa resolvió el cambio o el plan.
8. **Tamaño.** Con más de 40 tareas abiertas, avisa y propone partir la spec antes de implementar.
9. Escribe `tasks.md` con `TRAZABILIDAD: PASS`; `sdd-check --spec NNN-slug` sin `PROBLEMA`; commit `docs(NNN-slug): tasks`. `Siguiente paso: sdd-implement`. DETENTE.

## Plantilla de `tasks.md`

```markdown
# Tareas — NNN-slug

| Campo | Valor |
|---|---|
| Spec-Version | N |
| Plan-Version | M |

## Trazabilidad
| Requisito | Plan | Nivel | Tareas |
|---|---|---|---|
| RF-001 | §4, D-002 | INTEG | T-001, T-003 |
Sobre-diseño / contradicciones: ninguno | <lista>

## Tareas
- [ ] T-001 — <objetivo indivisible>
  - Cubre: RF-003, UI-002
  - Depende de: — | T-00X (si espera a otra spec: `Bloqueada: espera a NNN-slug` desde la creación)
  - Archivos esperados: <rutas o áreas>
  - Puntos de contacto: <consumidores a actualizar | —>
  - Tests requeridos: <qué demuestran> (nivel: INTEG) | N/A — <motivo, solo configuración o documentación>
  - Verificaciones: <filas de la tabla de comandos que aplican>
  - Requiere usuario: NO | SÍ — <credenciales de prueba, autorización REAL, confirmación visual>
  - Hecho cuando: <condiciones objetivas; con referencia visual: «captura a <viewport> conforme con <ref>»>
  - Evidencia (T-001): pendiente

TRAZABILIDAD: PASS | FAIL
```

La evidencia al cerrar la escribe `sdd-implement` (Convenciones › Tareas y evidencia).

## Prohibido

Escribir código o tests; modificar la spec o el plan; crear tareas sin requisito o sin criterio objetivo; rebajar niveles de test; marcadores de evidencia sin ID; dejar la verificación de contrato o REAL para el final; borrar tareas o evidencia existentes; archivar tareas (lo hace `sdd-release`); empezar la implementación.
