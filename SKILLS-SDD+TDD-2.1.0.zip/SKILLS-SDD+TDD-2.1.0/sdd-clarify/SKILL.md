---
name: sdd-clarify
description: >-
  Audita la spec como QA senior (estados, concurrencia, sistemas externos, permisos, errores,
  interfaz), resuelve los hallazgos con el usuario en un solo lote y conduce su aprobación humana; o
  re-sella la cabecera si solo falta actualizarla. Úsala con una spec en BORRADOR, modificada por
  sdd-change o creada por sdd-retro.
---

# sdd-clarify — Clarificación y aprobación de la spec

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

## Precondiciones

Existe `spec.md`. Si no: `CLARIFICACIÓN BLOQUEADA — Motivo: no hay spec — Falta: spec.md — Siguiente paso: sdd-spec`.

## Re-sellado (sin auditoría)

Si la spec está `APROBADA` y no ha cambiado de versión desde la última ronda, y lo único que falla es la forma (cabecera ausente o mal formada en `clarify.md` o `spec.md`, p. ej. `Versión` ausente o una `Aprobación` antigua como «sí, fecha»; o `clarify.md` inexistente en una spec heredada), normaliza la cabecera con los valores reales (Versión = la última del registro de cambios, o 1; `Aprobación: APROBADA (fecha original, por el usuario)`; un `clarify.md` mínimo «Ronda 0 (heredada)» con `SPEC CLARIFICADA: SÍ` si la spec ya estaba aprobada; si no consta, pregunta al usuario), añade «Re-sellado vN: sin cambios» y conserva veredicto y aprobación. Si hay en la carpeta de la spec documentos con requisitos fuera de ella (p. ej. de interfaz), avisa al usuario de que deben integrarse con `sdd-change` antes del release. Commit `docs(NNN-slug): clarify re-sellado`. DETENTE.

## Procedimiento

1. Lee `spec.md` y `docs/constitution.md`. Si la spec viene de `sdd-change`, audita solo las secciones tocadas según el último registro de cambios, más su coherencia con el resto.
2. **Auditoría.** Registra hallazgos `H-NN` en `clarify.md`:
   - ambigüedades, contradicciones (internas y con la constitución), duplicados, RF no verificables, suposiciones implícitas, tecnología o diseño interno colados;
   - **estados:** cada estado × evento definido, incluidos cancelar, reintentar (¿qué pasa con lo ya creado?), revertir, fallo parcial, reinicio a mitad de una operación y dos actores o procesos simultáneos;
   - **sistemas externos:** datos de conexión completos por plataforma (ámbitos incluidos), operaciones no soportadas, respuestas incompletas (nunca un éxito inventado), timeouts visibles y entorno real de verificación; sin él, el usuario decide entre fuera de alcance y riesgo declarado;
   - **permisos:** cada acción con permitido o denegado, también según el estado del actor (qué puede hacer una cuenta bloqueada, suspendida…), cómo se autentica cada interfaz, semántica de «propio» y coherencia entre lo que ofrece la interfaz (si existe) y lo que se autoriza;
   - **arranque:** estado inicial y datos semilla (p. ej. el primer administrador);
   - **errores y límites:** catálogo de errores visibles; tamaños, volúmenes y tiempos; idioma y tono de los textos;
   - **interfaz:** UI-NNN que contradicen RF, decisiones visuales necesarias no declaradas, referencias sin fichero o sin viewport, documentos de interfaz fuera de la spec (se integran como UI-NNN y `assets/`); en una GUI, el nivel de accesibilidad exigido (teclado, contraste, lectores de pantalla), que decide el usuario;
   - **tamaño:** mal clasificado (S/M/L), o la spec ya abarca más de una funcionalidad (Convenciones › Tamaño de spec) → recomienda partirla.
3. **Resolución en un solo lote.** Presenta todos los hallazgos en un mensaje, agrupados por tema y ordenados por impacto (alcance, datos y seguridad primero). Para cada uno: opción recomendada y alternativas breves. El usuario puede aceptar las recomendaciones en bloque si lo dice explícitamente; con más de unos 15 hallazgos, indica cuáles bastan para avanzar. En Interfaz no se propone diseño: se pide la decisión. En RETRO, cada anomalía se decide: intencional (se queda) o defecto (el RF se reescribe con lo esperado y se marca `(defecto)`). Se aplica solo lo decidido; lo demás sigue marcado.
4. **Re-auditoría incremental** de lo editado, hasta que no aparezcan hallazgos nuevos.
5. **Resultado.** Con cero `[NECESITA ACLARACIÓN:`, cero contradicciones, todo RF y UI verificable, tabla de estados completa y `Fuera de alcance` no vacío: `SPEC CLARIFICADA: SÍ` y `Estado: CLARIFICADA`. Si no: `SPEC CLARIFICADA: NO` con los pendientes, y DETENTE.
6. **Gate de aprobación.** Pregunta literalmente: «¿Esta especificación representa realmente la funcionalidad que quieres construir? (sí/no)». En RETRO v1: «¿Esta spec describe correctamente el comportamiento actual y los defectos marcados? (sí/no)». Solo un sí inequívoco cuenta; ante una respuesta ambigua, repite.
   - Sí → `Estado: APROBADA`, `Aprobación: APROBADA (AAAA-MM-DD, por el usuario)`. Commit `docs(NNN-slug): spec vN aprobada`. Siguiente paso: `sdd-plan`. En RETRO v1, antes de aprobar, si hay anomalías declaradas intencionales sin test, añade, encima de cualquier otra línea `Pendiente:`, `Pendiente: sdd-retro — caracterizar RF-…`; después el verificador enruta por `(defecto)` y por las líneas `Pendiente:`.
   - No → pide qué no representa la funcionalidad, regístralo como hallazgos nuevos (`Siguiente paso: sdd-clarify` y `SPEC CLARIFICADA: NO`, `Estado: BORRADOR`), commitea `docs(NNN-slug): clarify ronda R` y continúa en el paso 3. No repitas la pregunta sin haber editado la spec.
7. DETENTE.

## Plantilla de `clarify.md`

```markdown
# Clarificación — NNN-slug

| Campo | Valor |
|---|---|
| Spec-Version | N |
| Ronda | R |

| ID | Tipo | Hallazgo | Sección / RF | Decisión del usuario |
|---|---|---|---|---|

Siguiente paso: <sdd-plan | sdd-clarify | en RETRO, lo que indique sdd-orchestrator>

SPEC CLARIFICADA: SÍ | NO
```

Las ediciones de clarify sobre una spec no aprobada no suben su versión (Convenciones › Versiones). Cada ronda se numera; las anteriores se resumen en una línea (el detalle queda en el historial).

## Prohibido

Corregir sin decisión del usuario; inventar requisitos o diseño para cerrar hallazgos; interpretar respuestas ambiguas como aprobación; diseñar o implementar.
