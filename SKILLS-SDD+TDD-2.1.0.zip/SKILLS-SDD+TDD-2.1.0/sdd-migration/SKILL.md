---
name: sdd-migration
description: >-
  Gate de confirmación de compatibilidad (datos, contratos, coexistencia, rollback) cuando el plan
  exige migración: contrasta la §10 del plan con el código real y escribe migration-review.md. Úsala
  tras sdd-plan con «Migración requerida: SÍ».
---

# sdd-migration — Gate de migración y compatibilidad

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

## Precondiciones

`spec.md` y `plan.md` vigentes, plan aprobado y `Migración requerida: SÍ`. Si no: `MIGRACIÓN BLOQUEADA — Motivo: … — Falta: … — Siguiente paso: sdd-plan`. `sdd-plan` ya hizo la autocomprobación de §10: este gate **confirma** con evidencia del código; no rediseña.

## Re-sellado

Si `migration-review.md` está caducado o sin versión pero la §10 del plan y lo que cita no han cambiado desde su último commit (`git diff <commit> -- plan.md` sin cambios en §10, §3 ni §4), actualiza la cabecera y conserva el veredicto. Commit y DETENTE.

## Procedimiento

1. Lee la §10 del plan (y §3 o §4 solo si §10 los cita) y el código afectado: migraciones, modelos, contratos públicos y despliegue.
2. Identifica productores, consumidores, datos existentes y coexistencia de versiones. Pregunta al usuario solo lo que el repositorio no responde (p. ej. si hay instalaciones con datos reales). Confirma la clasificación: `COMPATIBLE` (la versión anterior y la nueva conviven con los mismos datos), `POR FASES` (pasos ordenados: expandir → migrar → contraer) o `BREAKING` (exige parada o rompe a consumidores existentes). Si el código muestra una clasificación distinta de la del plan, el resultado es `INCOMPLETA` con la clasificación correcta como primer hueco.
3. Contrasta cada aspecto con el plan **y con el código real** (en una spec nueva sin código previo, solo con el diseño) (los «Huecos aceptados» del plan no cuentan como faltas): estado inicial y final · coexistencia · backfill · validación e idempotencia · rollback y fallo parcial · tests de compatibilidad y rollback (INTEG).
4. Escribe `migration-review.md`.
5. Con `INCOMPLETA`: lista completa de lo que falta (para que `sdd-plan` lo resuelva en una sola pasada) y `Siguiente paso: sdd-plan`. Con `SUFICIENTE`: `Siguiente paso: sdd-tasks`. Commit `docs(NNN-slug): migration-review` (con `SUFICIENTE`, quita la línea `Bloqueada` de la tarea que esperaba esta revisión, si la hay). DETENTE.

## Plantilla de `migration-review.md`

```markdown
# Revisión de migración — NNN-slug

| Campo | Valor |
|---|---|
| Spec-Version | N |
| Plan-Version | M |
| Clasificación | COMPATIBLE / POR FASES / BREAKING |

| Aspecto | Cubierto en el plan | Contrastado en el código | Falta |
|---|---|---|---|

Siguiente paso: <sdd-tasks | sdd-plan>

MIGRACIÓN: SUFICIENTE | INCOMPLETA
```

## Prohibido

Ejecutar migraciones sobre datos reales; modificar el plan, el código o los requisitos; ocultar cambios incompatibles; devolver `INCOMPLETA` sin la lista completa de lo que falta.
