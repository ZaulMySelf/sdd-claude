---
name: sdd-retro
description: >-
  Documenta código existente sin spec como spec RETRO (comportamiento observable y tests de
  caracterización) sin tocar producción. Úsala antes de sdd-bug o sdd-change sobre código que
  ninguna spec cubre.
---

# sdd-retro — Spec retroactiva de código existente

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

## Precondiciones

Constitución `APROBADA` y `AGENTS.md` existente. Si una spec ya cubre el código: `RETRO BLOQUEADA — Motivo: ya existe NNN-slug — Falta: nada (usar esa spec) — Siguiente paso: sdd-bug | sdd-change`; si venía de una fila global del backlog, reescribe antes su Spec con `NNN` y su Ruta hacia esa skill, y commitea `docs: backlog` (Convenciones › Backlog).

## Procedimiento

1. **Alcance mínimo:** el módulo o flujo que necesita el bug o el cambio, no el repositorio entero.
2. **Comportamiento observable.** Lee el código y los tests y extrae entradas, salidas, estados y transiciones, errores, permisos, sistemas externos usados e interfaz existente, en EARS y con las tablas de la plantilla de `sdd-spec`. Sin diseño interno.
3. **Anomalías** (lo que parece un defecto, incluidos éxitos falsos y transiciones sin control de concurrencia): se registran como RF del comportamiento actual con `[NECESITA ACLARACIÓN: ¿defecto o intencional?]` y sin test de caracterización. Nunca se corrigen.
4. **Caracterización.** Por cada RF o UI sin un test que lo demuestre, el test mínimo que fija el comportamiento actual, al nivel que de verdad lo demuestra (persistencia con almacenamiento real si existe la infraestructura). Debe pasar sin tocar producción. Se cita en el RF: `(Test: <fichero> — <nombre del caso>)`.
5. Escribe `spec.md` con la plantilla, numeración y slug de `sdd-spec`: `Origen: RETRO`, `Versión: 1`; `Tamaño` y `Criterios de finalización`: `N/A (RETRO)`. En el Contexto, la línea `Pendiente: sdd-bug | sdd-change — <pedido que motivó la retro> | ninguno`. La interfaz existente se documenta como UI-NNN, con capturas en `assets/` si hay herramienta para tomarlas o con una descripción confirmada por el usuario si no.
6. Si la retro viene de una fila global del backlog (Spec `—`), reescribe su columna Spec con `NNN` y su Ruta hacia la skill que la resolverá (`sdd-bug` o `sdd-change`) (Convenciones › Backlog). Commit de spec, tests y backlog: `test(NNN-slug): retro-spec`. `Siguiente paso: sdd-clarify`. DETENTE.

## Modo completar caracterización

Se ejecuta cuando la spec RETRO aprobada tiene la línea `Pendiente: sdd-retro`: escribe los tests de caracterización de los RF que cita (sin tocar producción), cítalos en los RF con `(Test: …)`, elimina esa línea `Pendiente:` y commitea `test(NNN-slug): caracterización`. No cambia la versión de la spec (Convenciones › Versiones). Siguiente paso: el que indique `sdd-orchestrator`.

## Prohibido

Modificar código de producción; documentar intenciones en lugar del comportamiento real; ampliar el alcance más allá de lo necesario; resolver anomalías sin el usuario.
