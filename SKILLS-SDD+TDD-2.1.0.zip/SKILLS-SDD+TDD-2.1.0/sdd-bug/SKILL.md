---
name: sdd-bug
description: >-
  Diagnostica y corrige defectos (código ≠ spec) por causa raíz, con test de regresión al nivel que
  lo habría detectado, búsqueda de casos hermanos del mismo patrón y clase de causa registrada.
  Úsala ante un bug, un fallo de causa incierta o una fila del backlog con Ruta sdd-bug.
---

# sdd-bug — Diagnóstico y corrección de defectos

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill) y el entorno de `docs/agent-runbook.md`. Usa también la skill `tdd`.

## Precondiciones

Constitución `APROBADA` y `AGENTS.md` existente; un defecto descrito o una fila del backlog con Ruta `sdd-bug`.

## Regla clave

- Código ≠ spec → **bug**: se corrigen código y tests.
- El usuario quiere otro comportamiento, o la spec no define qué debe pasar → `sdd-change`. El comportamiento esperado nunca se inventa (salvo textos menores no declarados: Convenciones › Interfaz).

## Fase 0 — Diagnóstico (solo si la causa es incierta)

1. Síntoma, comportamiento esperado y alcance; evidencia mínima (logs, errores, entradas, entorno).
2. Pocas hipótesis, ordenadas por evidencia, y el experimento más barato que las discrimine. Sin cambios especulativos en producción.
3. Con la causa confirmada: defecto → Fase 1 · cambio de requisito → `sdd-change` · configuración, datos o entorno → `BUG BLOQUEADO — Motivo: entorno (<qué>) — Falta: acción del usuario (<cuál>) — Siguiente paso: sdd-bug`, sin quitar la línea `Bloqueada` hasta que el usuario confirme la acción · sin evidencia suficiente → `DEBUG: INCONCLUSO` con los próximos experimentos, y DETENTE. Si no hay nada que corregir aquí, quita también la línea `Bloqueada: … → sdd-bug` o `Pendiente: sdd-bug` que la trajo (o reescríbela hacia la skill correcta) y, si venía de una fila del backlog, la fila pasa a `DESCARTADO (motivo)` o su Ruta se reescribe; commitea esas ediciones (`docs(NNN-slug): …`).

## Fase 1 — Corrección

1. **Requisito.** Spec y RF o UI afectados. Si viene de una fila global (Spec `—`) y una spec existente usa ese código, el bug se registra en ella y la columna Spec de la fila se reescribe con su `NNN RF-XXX` en el mismo commit. Sin spec que cubra el código: `BUG BLOQUEADO — Motivo: ninguna spec cubre el código — Falta: spec RETRO — Siguiente paso: sdd-retro`; si venía de una fila global del backlog, reescribe antes su Ruta a `sdd-retro` y commitea `docs: backlog` (si no, el flujo volvería aquí). Sin forma de saber lo esperado: `BUG BLOQUEADO — Motivo: comportamiento esperado no definido — Falta: decisión en la spec — Siguiente paso: sdd-change`; antes, reescribe hacia `sdd-change` lo que trajo el bug (la Ruta de la fila del backlog, la línea `Pendiente: sdd-bug` de una spec RETRO o la `Bloqueada: … → sdd-bug` de una tarea) y commitea `docs(NNN-slug): …` (si no, el flujo volvería aquí). Un RF marcado `(defecto)` sin comportamiento esperado definido pasa a `[NECESITA ACLARACIÓN: …]` en ese mismo commit.
2. **Árbol de trabajo:** como en `sdd-implement` (continúa un intento previo del mismo bug; ante cambios ajenos, DETENTE; el trabajo aparcado de otras tareas no se toca).
3. **RED.** Si un test existente ya falla por el bug, se cita como test de regresión y no se duplica; si no, test de regresión mínimo que falla por el bug, al nivel que lo habría detectado: si un doble permisivo lo ocultó, el test es INTEG o CONTRATO, o el doble se vuelve estricto. En fallos visuales, test de interfaz o captura; si no es posible, pasos de reproducción y confirmación del usuario.
3b. Los tests existentes que dependían del comportamiento defectuoso se corrigen en este mismo bug; si el requisito deja de poder probarse al nivel exigido, regístralo en el backlog con Ruta `sdd-plan` (nivel reducido) o `sdd-change`.
4. **GREEN.** Corrige la causa raíz con el cambio mínimo; si la causa es lógica duplicada, usa el módulo canónico del plan. REFACTOR solo si mejora claramente. Si el test de regresión sigue fallando tras 3 intentos con hipótesis distintas, la causa no estaba confirmada: aparca y vuelve **una sola vez** a la Fase 0 con esas hipótesis descartadas; si la segunda ronda de 3 intentos también falla (o no queda experimento barato), `DEBUG: INCONCLUSO`, trabajo aparcado y DETENTE.
5. **Casos hermanos.** Busca el mismo patrón en el resto del código. Los del mismo RF y causa, dentro del mismo módulo, se corrigen aquí con su test; los demás se registran en el backlog sin duplicar filas (Convenciones › Backlog). No se corrigen fuera de alcance.
6. **Verificación** según la columna «Cuándo»; si la causa está en código compartido, también la suite del paquete o componente y los E2E afectados (actualizándolos si el arreglo cambia textos o rutas).
7. **Registro.** `specs/NNN-slug/bugs/BUG-NNN.md` (numeración global: Convenciones › Fuentes y artefactos), cerrado solo con evidencia. Si el RF estaba marcado `(defecto)`, pasa a `(BUG-NNN · Test: <test de regresión>)`; si la spec es RETRO con `Pendiente: sdd-bug`, pasa a `Pendiente: ninguno`. Son las únicas ediciones permitidas de la spec (Convenciones › Versiones). Si el bug resolvía una tarea `Bloqueada: … → sdd-bug`, quita esa línea en el mismo commit. Si el bug viene del backlog, su fila pasa a `BUG-NNN`.
8. **Ciclo de la spec.** Si la spec ya tenía validación o release, el verificador enrutará después a `sdd-validate` y `sdd-release` para cerrar un nuevo ciclo (en una spec adoptada, directamente a `sdd-release` en modo adopción); inclúyelo en el siguiente paso de la salida.
9. **Commit:** arreglo, test, `BUG-NNN.md` y, si se tocaron, `spec.md`, `tasks.md` y el backlog; `sdd-check pre-commit --bug BUG-NNN` en verde.

Si te detienes sin terminar, aparca el trabajo (Convenciones › Trabajo parcial).

## Plantilla de `BUG-NNN.md`

```markdown
# BUG-NNN — <título>
- Spec/Req: RF-XXX | UI-XXX · Origen: <R-NNN | usuario | test>
- Clase: <una de: ÉXITO-FALSO · DOBLE-PERMISIVO · FUENTE-DUPLICADA · CONCURRENCIA · ESTADO-NO-CUBIERTO · CONTRATO-EXTERNO · INTERFAZ · INTEGRACIÓN-ENTRE-TAREAS · SEGURIDAD · OTRO>
- Síntoma / reproducción:
- Causa raíz:
- Por qué no lo detectó el flujo: <gate o nivel de test que faltó>
- Test de regresión (nivel):
- Arreglo (ficheros):
- Casos hermanos: <corregidos aquí | R-NNN | ninguno>
- Verificación (comando → resultado):
- Estado: ABIERTO | CERRADO
```

## Salida (máximo 6 líneas)

```text
BUG: BUG-NNN — <título> · REQ: RF-XXX · CLASE: …
CAUSA: … · ARREGLO: …
TESTS: <comando> → PASS/FAIL · HERMANOS: …
RESULTADO: CORREGIDO | BLOQUEADO — Motivo: … — Falta: … — Siguiente paso: <skill>
```

## Prohibido

Cambiar la spec para que coincida con código defectuoso; inventar el comportamiento esperado; añadir comportamiento; refactorizar áreas ajenas; cerrar sin test de regresión cuando sea razonablemente posible; dejar casos hermanos sin registrar.
