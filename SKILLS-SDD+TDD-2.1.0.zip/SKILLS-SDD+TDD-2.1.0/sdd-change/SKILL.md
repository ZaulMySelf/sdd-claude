---
name: sdd-change
description: >-
  Cambia el comportamiento o la interfaz de una spec existente dentro de su funcionalidad: edita y
  versiona la spec (LOCAL o ESTRUCTURAL) antes de tocar código y desvía a sdd-spec lo que sea una
  funcionalidad nueva. Úsala para cualquier cambio funcional.
---

# sdd-change — Cambio desde la spec

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill).

Ningún cambio funcional empieza por el código. Si el usuario insiste: `CAMBIO BLOQUEADO — Motivo: la spec debe cambiar y aprobarse antes que el código — Falta: spec vN aprobada — Siguiente paso: sdd-change`.

## Precondiciones

- Existe la spec afectada. Si el código existe pero ninguna spec lo cubre: `CAMBIO BLOQUEADO — Motivo: ninguna spec cubre el código — Falta: spec RETRO — Siguiente paso: sdd-retro`; si venía de una fila global del backlog, reescribe antes su Ruta a `sdd-retro` y commitea `docs: backlog` (Convenciones › Backlog).
- **Filtro de funcionalidad nueva** (Convenciones › Tamaño de spec): `CAMBIO BLOQUEADO — Motivo: es una funcionalidad nueva — Falta: spec propia — Siguiente paso: sdd-spec`. Solo el usuario puede forzar lo contrario, de forma explícita. Si llegó por una tarea `Bloqueada: … → sdd-change`, reescribe esa línea como `Bloqueada: espera a <nueva NNN-slug>` (o cierra la tarea N/A vía `sdd-tasks` si sobra) en un commit `docs(NNN-slug): …`.
- Con más de 40 tareas abiertas, o tres cambios `[ESTRUCTURAL]` sin un release intermedio, avisa y propone cerrar el ciclo (validate y release) antes de cambiar la spec otra vez.
- **Partir una spec:** los RF que salen se marcan `RF-XXX: (movido a NNN-slug en vN)` en esta spec (cambio `[ESTRUCTURAL]`) y se especifican en una spec nueva con `sdd-spec`, que los hereda con su ID original como referencia (`RF-001 (antes NNN RF-XXX · Test: …)`), trazados a sus tests existentes con nivel `CARACTERIZACIÓN`, sin reimplementarlos. Solo se heredan así los RF ya implementados con un test que pasa; los que aún no lo están pasan a la spec nueva como RF normales, con sus tareas. Sus tareas pendientes en esta spec las cierra `sdd-tasks` como `N/A`.
- **Sin cambio necesario:** si el análisis concluye que no hay nada que cambiar, quita la línea `Bloqueada: … → sdd-change` o `Pendiente: sdd-change` que lo trajo (o reescríbela hacia la skill correcta) y cierra o reencamina la fila del backlog; commit `docs(NNN-slug): …`.

## Procedimiento

1. Localiza la spec y los RF y UI afectados. Si el pedido agrupa varios hallazgos (auditoría, backlog), resuélvelos en **un solo** cambio, no en una versión por hallazgo.
2. **Clasifica:**
   - `LOCAL`: cambia comportamiento o interfaz dentro del diseño existente sin cambiar la **forma** de los contratos públicos (firmas, esquemas, endpoints, formatos de datos, códigos de error), la persistencia, los permisos, la seguridad, los RNF, la arquitectura ni otras specs. Un cambio de semántica dentro de la misma forma puede ser LOCAL.
   - Todo cambio del esquema persistido es `ESTRUCTURAL`; la etiqueta que proponga el usuario no prevalece sobre esta regla.
   - Ante la duda, `ESTRUCTURAL` (es el camino seguro) o pregunta al usuario y registra su decisión.
   - `ESTRUCTURAL`: toca alguna de esas áreas o cruza componentes o specs.
   Presenta un resumen breve del impacto (requisitos, tareas y tests afectados).
3. **Edita `spec.md`.** Los requisitos modificados conservan su ID, los nuevos continúan la numeración y los eliminados quedan como `RF-XXX: (eliminado en vN — motivo)`. Revisa la coherencia en estados, sistemas externos, errores, permisos, seguridad, casos límite, interfaz (y sus referencias en `assets/`), fuera de alcance y criterios. Las decisiones de interfaz las declara el usuario.
4. **Versiona.** Sube `Versión`, pon `Estado: BORRADOR` y `Aprobación: PENDIENTE`, y añade al registro `[LOCAL]` o `[ESTRUCTURAL]` con qué cambia, por qué y qué requisitos toca (una línea por requisito). Los derivados no se editan: caducan por versión. Si el cambio resuelve filas del backlog, su estado pasa a `vN` (única edición permitida fuera de la spec; Convenciones › Backlog). En una spec RETRO con `Pendiente: sdd-change`, la línea pasa a `Pendiente: ninguno`.
5. Lo que el usuario no decida queda como `[NECESITA ACLARACIÓN: …]`.
6. Muestra el diff resumido, commitea `docs(NNN-slug): spec vN` y DETENTE:

```text
CAMBIO REGISTRADO (spec vN, [LOCAL | ESTRUCTURAL])
Siguiente paso: sdd-clarify (si se partió la spec: antes sdd-spec para la nueva, con los RF heredados)
Después: plan [delta si LOCAL] → [migración] → tasks (reabre solo lo afectado) → implement → validate [incremental si LOCAL] → release
```

## Prohibido

Modificar código, tests u otros artefactos (salvo el estado de filas del backlog y las líneas `Bloqueada`/`Pendiente:` que resuelve); registrar la aprobación (corresponde a `sdd-clarify`); resolver ambigüedades sin el usuario; meter una funcionalidad nueva en una spec existente.
