---
name: sdd-implement
description: >-
  Implementa las tareas de tasks.md con TDD, una a la vez, al nivel de test que exige el plan, con
  evidencia compacta y un commit verificado por tarea; encadena todas, ejecuta solo T-XXX o re-sella
  una tarea. Úsala con TRAZABILIDAD: PASS.
---

# sdd-implement — Implementación con TDD

Aplica `AGENTS.md` y las Convenciones SDD (`docs/sdd-conventions.md`: solo las secciones que cite esta skill) y el entorno descrito en `docs/agent-runbook.md`. Usa también la skill `tdd`.

## Modos

| Modo | Invocación | Comportamiento |
|---|---|---|
| Continuo (por defecto) | `sdd-implement` | Todas las tareas pendientes, una tras otra, sin preguntar entre ellas. Si el harness permite subagentes, el orquestador lanza una tarea por subagente. |
| Tarea única | `sdd-implement T-XXX` | Solo esa tarea; después, informe final. |
| Re-sellado | `sdd-implement T-XXX re-sellado` | La tarea ya tiene código: ejecuta sus tests y verificaciones sin tocar código; si pasan, sella la evidencia (Convenciones › Tareas y evidencia) con `RED: N/A — re-sellado`; si fallan, la reabre y la implementa. |

Siempre **una tarea a la vez**: cada una se cierra por completo (tests, verificaciones, evidencia y commit) antes de la siguiente.

## Precondiciones

1. Con `sdd-check --spec NNN-slug` (o leyendo cabeceras y veredictos si no hay verificador): constitución y spec `APROBADA` sin `[NECESITA ACLARACIÓN:` y sin `Depende de` hacia una spec no completada, `tasks.md` vigente con `TRAZABILIDAD: PASS` y sin `PROBLEMA`, salvo el de la tarea que se va a re-sellar o reabrir.
2. Árbol de trabajo: limpio; o con cambios de un intento previo de **la misma tarea** (sus «Archivos esperados») o un trabajo aparcado suyo, que se recuperan y se continúan. Con cambios ajenos: `IMPLEMENTACIÓN BLOQUEADA — Motivo: cambios ajenos a T-XXX en el árbol — Falta: árbol limpio (decisión del usuario sobre esos cambios) — Siguiente paso: sdd-orchestrator`.
3. Con ramas por spec, en la rama de la spec.

## Bucle por tarea

1. **Selección.** La primera `- [ ]` cuyas dependencias estén hechas (en `tasks.md` o en `tasks-archive.md`), saltando las `Bloqueada` (salvo `espera a NNN-slug` con esa spec ya completada, según `sdd-check`: se toma y la línea se quita en su commit) y, si hay otras listas, las de `Requiere usuario: SÍ`; o la indicada (si sus dependencias no están hechas, bloquea).
   - Si la indicada está `- [x]` porque `sdd-validate` o `sdd-review` la señalan incompleta, reábrela (si validate falsó su test o review lo señaló como incapaz de fallar, la tarea consiste en reforzarlo hasta que la mutación citada lo haga fallar: `AGENTS.md` › regla 14 d) (Convenciones › Tareas y evidencia) y commitea la reapertura (`docs(NNN-slug): reabre T-XXX`, pre-commit genérico) antes de seguir.
   - Una tarea archivada no se reabre: `sdd-tasks` crea la sustituta.
2. **Contexto mínimo.** Busca por ID su entrada en `tasks.md`, los RF, RNF y UI que cubre en la spec, y las secciones del plan que cita: su fila de §9 (nivel de test) y los módulos canónicos de §4b. Luego, el código afectado. No leas `tasks.md` ni `plan.md` enteros salvo que el harness exija leer un fichero antes de editarlo; en ese caso, lee el rango que contiene la tarea.
3. **RED.** Escribe los tests de «Tests requeridos» al nivel exigido y confirma que fallan por la razón correcta: el comportamiento ausente. Si el símbolo que crea la tarea aún no existe, vale como RED el error de importación o de símbolo inexistente de ese símbolo (no de otros); no hacen falta esqueletos. Si la tarea solo añade cobertura a un comportamiento que ya existe, el RED es `N/A — comportamiento existente; verificado por mutación: <cambio temporal> → el test falla`. Si un test que debía fallar pasa sin tocar producción, o el comportamiento ya existe (trátalo como cobertura, con mutación) o el test no prueba lo que dice: corrígelo antes de seguir.
   - Los dobles de prueba reproducen la interfaz real: solo atributos y métodos que existen.
   - Con nivel INTEG o CONTRATO, ni el almacenamiento ni la API externa se sustituyen por un doble escrito a mano.
   - Las fixtures de un sistema externo salen de su documentación oficial o de respuestas grabadas, citando la fuente en el test.
4. **GREEN.** El mínimo código correcto, reutilizando los módulos canónicos sin duplicar su lógica. Lo que un sistema externo no devolvió es un error explícito, nunca un valor por defecto inventado.
5. **REFACTOR.** Solo con los tests en verde y sin cambiar comportamiento.
6. **Verificación.** Según la columna «Cuándo» de la tabla de comandos:
   - siempre: los tests de la tarea y la suite del paquete o componente tocado;
   - persistencia → integración; flujos de extremo a extremo (navegación, autenticación, textos visibles, contratos públicos) → E2E, actualizando en esta tarea los que cambien; código compilado o empaquetado → build; dependencias → auditoría (Convenciones › Riesgos y vulnerabilidades);
   - la fila «Todo» si el prompt lo pide, si `sdd-check` lo indica o si la tarea modifica un módulo de plan §4b que usan otros paquetes o componentes; esa viñeta de la evidencia se titula `Verificación completa:`.
   Los tests existentes cuyo comportamiento esperado cambió con la versión vigente de la spec forman parte de la tarea (se actualizan aquí y la evidencia cita el RF que lo justifica). Cualquier otro test existente que falle es una regresión de esta tarea (se corrige el código, no el test) o un fallo ajeno, que no se arregla aquí: es una condición de parada (`AGENTS.md` › regla 14). Usa los comandos del runbook y lee los logs donde se escribieron.
7. **Interfaz.** Los UI-NNN tal como están declarados; con referencia visual, compara una captura con ella (Convenciones › Interfaz). Una decisión visual o de UX no declarada que cambie lo que el usuario ve o hace es una condición de parada (`sdd-change`). Un texto menor no declarado (mensaje de salida o error de una CLI o API) que respeta los UI-NNN de formato se elige, se cita en la evidencia y no bloquea (Convenciones › Interfaz).
8. **Cierre.** Marca `- [x]` y sustituye el marcador por la evidencia, con este formato exacto (`sdd-check` comprueba que exista y que «Archivos:» cite cada fichero de código del commit: rutas exactas o carpetas terminadas en `/`, sin comodines ni llaves):
   ```
     - Evidencia (T-XXX):
       - RED: <comando> → <n fallos, motivo>
       - GREEN: <comando> → <n/n>
       - Verificación: <comando> → <totales, exit> · <comando> → …
       - Archivos: …
       - Observado: R-NNN
   ```
9. **Backlog** (Convenciones › Backlog) **y tabla de comandos.**
   - Cada hallazgo ajeno a la tarea va como fila `ABIERTO` al backlog y la evidencia cita su `R-NNN`; no se corrige aquí.
   - Si la tarea venía de una fila del backlog (Ruta `sdd-implement T-XXX`), esa fila pasa a `HECHO`.
   - Si la tarea crea o cambia herramientas (tests, build, lint, auditor), o es la primera con tests de un nivel cuya fila sigue `pendiente`, su fila de la tabla de comandos se actualiza en el mismo commit. Si una fila está `no disponible` o `no aplica`, no bloquea: se anota en la evidencia (salvo la fila Seguridad cuando la tarea introduce dependencias de runtime: se activa en esa tarea). Si está `pendiente` y ninguna tarea crea esa herramienta, la tarea queda `Bloqueada: falta la herramienta de <categoría> (requiere D-NNN) → sdd-plan`.
10. **Commit** (`AGENTS.md` › Commits). Al índice, solo los ficheros de la tarea (con el lockfile si cambió una dependencia), `tasks.md` y, si se tocaron, el backlog, la tabla de comandos y `docs/agent-runbook.md`; nunca todo el árbol de golpe. `sdd-check pre-commit --task T-XXX --spec NNN-slug` en verde y diff staged revisado.
11. **Reporte:** `✓ T-XXX — <objetivo> · <verificaciones> PASS · <n> ficheros · <commit>`. En modo continuo, vuelve al paso 1.

## Condiciones de parada

La tarea queda en `- [ ]` y su trabajo se aparca (Convenciones › Trabajo parcial). Si la causa la resuelve otra skill, la tarea se marca `Bloqueada: <motivo> → <skill>` y se commitea (Convenciones › Tareas y evidencia); en modo continuo se sigue con las demás tareas listas (regla única de `Bloqueada`), salvo un fallo de verificación compartida ajeno a la tarea: `Bloqueada: fallo compartido (<qué>) → sdd-bug`, que detiene la cadena hasta corregirlo. La ejecución termina en estos casos:

- un test o una verificación falla y no se resuelve dentro del alcance de la tarea, o sigue fallando tras 3 intentos con hipótesis distintas (`AGENTS.md` › regla 15; el informe lista las hipótesis descartadas);
- el nivel de test exigido no es alcanzable (falta entorno, fixture o autorización): se informa de qué falta y `sdd-plan` lo lleva al usuario; nunca se rebaja por cuenta propia;
- falta o es incorrecto un requisito (`sdd-change`), hace falta una decisión técnica o una dependencia no prevista (`sdd-plan`), la tarea está mal descompuesta (`sdd-tasks`) o falta una decisión visual (`sdd-change`);
- la tarea requiere al usuario y no hay confirmación explícita suya en la sesión: se devuelve la petición (al agente principal o al usuario), agrupada con las demás tareas que lo esperan, sin esperar indefinidamente;
- el commit o `sdd-check pre-commit` fallan sin solución dentro del alcance;
- el usuario pide parar.

## Informe final

```text
IMPLEMENTACIÓN: <n> tareas completadas (T-00A … T-00B) · commits <…>
PENDIENTES: <ninguna | T-XXX…>
DETENIDO EN: <— | T-XXX: motivo · trabajo aparcado: WIP T-XXX>
BACKLOG: <R-NNN añadidos | —>
Siguiente paso: sdd-validate | <skill según el motivo de parada>
```

Al terminar todas las tareas, DETENTE.

## Prohibido

Más de una tarea abierta; avanzar con verificaciones fallando; desactivar, saltar, enfocar o debilitar tests, o editar uno cuyo comportamiento esperado no cambió; rebajar el nivel de test; dobles permisivos o sustitutos donde el plan pide INTEG o CONTRATO; valores inventados ante respuestas externas incompletas; duplicar la lógica de un módulo canónico; comportamiento o diseño sin requisito; marcar `- [x]` sin evidencia de esta ejecución; commitear sin `sdd-check pre-commit` cuando el verificador existe; inventar comandos; editar la spec o el plan; push, cambios de rama fuera de la política, omitir hooks, reescribir commits o incluir ficheros ajenos.
