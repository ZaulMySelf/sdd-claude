---
name: sdd-constitution
description: >-
  Crea docs/constitution.md (8-12 principios innegociables y verificables) o tramita una enmienda,
  siempre con aprobación humana explícita. Úsala tras sdd-init o para enmendar la constitución.
---

# sdd-constitution — Constitución del proyecto

## Precondiciones

- Existe `docs/brief.md`. Si no: `CONSTITUCIÓN BLOQUEADA — Motivo: no hay brief — Falta: docs/brief.md — Siguiente paso: sdd-init`.
- Si ya hay una constitución `APROBADA`, el pedido es una **enmienda**: la vigente sigue `APROBADA` y en vigor mientras se tramita (el trabajo en curso no se detiene).

## Procedimiento — constitución nueva

1. Lee el brief.
2. Redacta 8-12 principios. Cada uno: enunciado de una frase y «Verificación» de una frase, comprobable en una revisión.
3. Cubre como mínimo: desarrollo guiado por specs · simplicidad y mantenibilidad · seguridad por diseño · tests · dependencias · errores y observabilidad · compatibilidad · cambios controlados. Incluye en esencia:
   - la spec manda sobre el código; ningún comportamiento existe sin requisito;
   - no se integra trabajo con tests fallando;
   - la evidencia demuestra el comportamiento real: persistencia e integraciones se prueban contra almacenamiento real o contratos verificados, no con dobles escritos a mano;
   - dependencias mínimas, justificadas y mantenidas, sin vulnerabilidades altas o críticas de runtime sin tratar;
   - seguridad por defecto; errores explícitos y observables, nunca un éxito inventado;
   - cambios pequeños y verificables; spec, plan, código y tests sincronizados; una spec por funcionalidad.
4. Escribe con `Estado: PROPUESTA · Revisión: 1` y muestra el documento.
5. **Gate:** «¿Apruebas esta constitución como reglas innegociables del proyecto? (sí/no)». Solo un sí inequívoco cuenta; ante ambigüedad, repite.
   - Sí → `Estado: APROBADA (AAAA-MM-DD, por el usuario) · Revisión: 1` y primera fila del registro (`1 · fecha · Constitución inicial · APROBADA · usuario`). Commit `docs: constitución`. `Siguiente paso: sdd-agents`.
   - Cambios pedidos → aplica solo esos y vuelve al gate.
   - No, sin cambios concretos → pregunta qué principio no representa al proyecto; no repitas el gate sin una edición.
6. DETENTE.

## Re-sellado de formato

Si la constitución está aprobada pero en un formato antiguo (p. ej. sin la línea `> Estado:`), normaliza la cabecera conservando texto, fecha y revisión, sin gate. Commit `docs: constitución (formato)`. DETENTE.

## Procedimiento — enmienda

1. Lee la constitución vigente y el pedido; cambia solo lo pedido.
2. No toques el estado ni el texto vigente: añade al registro una fila `PENDIENTE` con el diff propuesto y muéstralo.
3. **Gate:** «¿Apruebas esta enmienda de la constitución? (sí/no)».
   - Sí → aplica el texto, incrementa `Revisión` y pasa la fila a `APROBADA`.
   - No → la fila pasa a `RECHAZADA` (con el motivo que dé el usuario).
4. Commit `docs: enmienda de la constitución`. `Siguiente paso: sdd-orchestrator` (o `sdd-agents` si la enmienda afecta a las reglas de `AGENTS.md`). DETENTE.

## Plantilla

```markdown
# Constitución del proyecto

> Estado: PROPUESTA · Revisión: 1

## Principios
### P-01 — <Nombre>
<Enunciado.>
Verificación: <cómo se comprueba>

## Registro de enmiendas
| Revisión | Fecha | Cambio | Estado (PENDIENTE / APROBADA / RECHAZADA) | Decidida por |
```

## Prohibido

Aprobar implícitamente; imponer tecnologías no impuestas por el usuario; inventar principios no validados; escribir código, tests o specs.
