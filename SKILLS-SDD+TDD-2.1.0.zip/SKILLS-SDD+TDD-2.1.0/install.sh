#!/usr/bin/env bash
# Instala las skills SDD (+ tdd) en el directorio de skills de tu agente, con copia de seguridad previa.
#   ./install.sh <dir-skills> [--backup-dir D] instala (backup de las skills que reemplaza; por defecto junto a <dir-skills>)
#   ./install.sh <dir-skills> --dry-run       muestra qué cambiaría
#   ./install.sh <dir-skills> --rollback F    restaura desde el tar.gz F
# <dir-skills>: el directorio donde tu harness busca skills (cada skill = carpeta con SKILL.md).
# También puede indicarse con la variable SKILLS_DIR.
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
DST=""; MODE=install; BKF=""; BKDIR=""
while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run) MODE=dry ;;
    --rollback) MODE=rollback; BKF="${2:?indica el tar.gz de backup}"; shift ;;
    --backup-dir) BKDIR="${2:?indica el directorio de backup}"; shift ;;
    -h|--help) echo "uso: $0 <dir-skills> [--backup-dir D] [--dry-run | --rollback F]"; exit 0 ;;
    -*) echo "opción desconocida: $1"; exit 2 ;;
    *) DST="$1" ;;
  esac
  shift
done
DST="${DST:-${SKILLS_DIR:-}}"
[ -n "$DST" ] || { echo "uso: $0 <dir-skills> [--backup-dir D] [--dry-run | --rollback F]  (o SKILLS_DIR=<dir>)"; exit 2; }
SKILLS=(sdd-agents sdd-bug sdd-change sdd-clarify sdd-constitution sdd-implement sdd-init sdd-migration
        sdd-orchestrator sdd-plan sdd-refactor sdd-release sdd-retro sdd-review sdd-spec sdd-tasks sdd-validate tdd)

if [ "$MODE" = install ]; then mkdir -p "$DST"; fi
[ -d "$DST" ] || { [ "$MODE" = dry ] && { for s in "${SKILLS[@]}"; do echo "nueva: $s"; done; exit 0; }; echo "no existe $DST"; exit 1; }
DST="$(cd "$DST" && pwd)"
[ "$DST" != "$SRC" ] || { echo "el destino no puede ser el propio paquete ($SRC)"; exit 2; }

if [ "$MODE" = rollback ]; then
  F="$BKF"
  [ -f "$F" ] || { echo "no existe $F"; exit 1; }
  for s in "${SKILLS[@]}"; do rm -rf -- "${DST:?}/${s:?}"; done
  tar -xzf "$F" -C "$DST"
  echo "restaurado desde $F"; exit 0
fi

if [ "$MODE" = dry ]; then
  for s in "${SKILLS[@]}"; do
    if [ -d "$DST/$s" ]; then diff -rq -x __pycache__ "$DST/$s" "$SRC/$s" || true; else echo "nueva: $s"; fi
  done
  exit 0
fi

EXIST=(); for s in "${SKILLS[@]}"; do [ -d "$DST/$s" ] && EXIST+=("$s"); done
if [ ${#EXIST[@]} -gt 0 ]; then
  BKDIR="${BKDIR:-$(dirname "$DST")}"; mkdir -p "$BKDIR"
  BK="$(cd "$BKDIR" && pwd)/skills-sdd-backup-$(date +%Y%m%d-%H%M%S).tar.gz"
  tar -czf "$BK" -C "$DST" "${EXIST[@]}"
  echo "backup: $BK"
else
  BK=""
  echo "sin skills previas: no hace falta backup"
fi
for s in "${SKILLS[@]}"; do
  rm -rf -- "${DST:?}/${s:?}"
  cp -r "$SRC/$s" "$DST/$s"
  find "$DST/$s" -name '__pycache__' -type d -prune -exec rm -rf {} +
done
echo "instaladas ${#SKILLS[@]} skills en $DST"
[ -n "$BK" ] && printf 'vuelta atrás: %q %q --rollback %q\n' "$0" "$DST" "$BK"
echo "Nota: si tu harness recarga skills en caliente, no instales mientras haya una cadena de tareas en curso."
