# Changelog

## 2.1.0

Revisión de bucles, integridad de los tests, seguridad y coste, validada en varias rondas de auditorías
independientes (flujo; calidad, seguridad y coste) con escenarios reproducidos y un corpus de precisión medido.
Los artefactos de 2.0.0 siguen siendo válidos.

### Ningún bloqueante se pierde y ningún bucle queda sin salida
- **Backlog:** el verificador clasifica cada fila abierta contra las specs existentes. Una fila con columnas,
  Spec o Severidad ilegibles ya no deja de bloquear: es PROBLEMA (también con `--spec`) y bloquea validate y
  release de todas las specs hasta que `sdd-review` (modo formato) la corrige. Una Ruta no válida bloquea igual
  y se enruta a corregir su formato.
- **Hallazgos globales** (Spec `—`, código sin spec dueña): un CRÍTICO/ALTO bloquea el release de cualquier spec
  sin reabrir las completadas, y es el siguiente paso del proyecto si no hay specs activas. Rutas válidas:
  `sdd-bug`, `sdd-change`, `sdd-refactor` o `sdd-retro`; quien encuentra o crea la spec dueña reescribe la columna Spec.
- Una Ruta hacia una tarea archivada se enruta a `sdd-tasks` (sustituta); hacia una inexistente, es PROBLEMA si la
  fila es CRÍTICO/ALTO y AVISO si es MEDIO/BAJO (el backlog menor no interrumpe la cadena de tareas).
- El paso del proyecto (brief, constitución, `AGENTS.md`, convenciones) va antes que cualquier paso de una spec, también
  en el verificador. `sdd-bug` vuelve una sola vez a la Fase 0; la segunda ronda fallida es `DEBUG: INCONCLUSO`.
  `sdd-review` en modo formato pregunta al usuario las filas que no puede reasignar.
- Un `Siguiente paso` que no es una skill de paso (p. ej. `sdd-orchestrator`) ya no se sigue: «requiere acción».
- **Límite de intentos dentro de una tarea:** tres hipótesis distintas sin resolver el mismo fallo detienen el
  trabajo (implement, bug, tdd). El orquestador no relanza una skill que terminó sin commit (p. ej.
  `DEBUG: INCONCLUSO`) y sdd-plan informa «requiere acción» si un NO o BLOCKED no exige cambiar el plan. Una skill
  que se bloquea hacia otra reescribe antes lo que la trajo (fila del backlog, `Pendiente:` o `Bloqueada:`), para
  que el flujo no vuelva a ella.
- Código, `tasks.md` o `BUG-NNN.md` sin commitear antes de validate o release, o después de un veredicto NO o
  BLOCKED (p. ej. una mutación de falsación sin restaurar): «requiere acción»; el orquestador pregunta si commitear,
  aparcar o descartar, y nunca propone commitear una mutación.
- Comandos no interactivos y con límite de tiempo; servidores y contenedores con arranque y parada en el runbook.

### Calidad de los tests
- Regla 14: ningún test se desactiva, salta, enfoca o debilita para avanzar; un test existente solo se edita
  si cambió su comportamiento esperado en la spec, si codificaba el defecto que corrige sdd-bug, si solo cambia
  su forma o si se refuerza porque sdd-validate lo falsó o sdd-review lo señaló como incapaz de fallar. Un test intermitente es un fallo. Un RED que pasa a la primera se corrige.
- `sdd-check pre-commit`, en ficheros de test: enfocados (`.only`, `.only.each`, `fit`, `fdescribe`) → PROBLEMA;
  desactivados (`skip`, `xit`, `xfail`, `@Disabled`…) y eliminados → AVISO. Supresiones de lint, tipos o
  cobertura → AVISO. Un commit de tarea que solo toca `specs/` avisa.
- `sdd-tasks` exige un test por fila del catálogo de Errores y un test negativo por mitigación de plan §5.
- **Evidencia contrastada con el commit** (`pre-commit --task`): cada fichero de código staged debe figurar en
  «Archivos:» (PROBLEMA); código sin ningún fichero de test cuando «Tests requeridos» no es N/A, y tests nuevos sin
  ninguna aserción (AVISO). Cambios en cómo se ejecutan los tests o la CI (`passWithNoTests`, `|| true`, configs de
  runner, workflows) → AVISO de revisión humana.
- **Prueba de falsación en `sdd-validate`:** en 1-3 requisitos de mayor riesgo se introduce una mutación mínima en la
  línea que implementa la regla, se comprueba que el test citado falla y se restaura en el acto; si sobrevive,
  `SPEC CUMPLIDA: NO` → `sdd-implement`, que refuerza el test (regla 14 d). Un veredicto negativo que se repite con los
  mismos huecos o el mismo requisito tras su ciclo de arreglo se lleva al usuario (sin bucles validate ↔ implement).
- Detectores ampliados: Cypress/`*.e2e.*`/`*IT.java`/RSpec, `skipIf`/`fixme`, `fit '…'`/`focus: true`, `@ts-nocheck`,
  `pylint: disable`, `nosec`, `NOLINT`, `@SuppressWarnings`, `checkov:skip`… El parser del diff sigue el estado de
  cada hunk (una línea añadida que empieza por «++» ya no oculta el resto del fichero).

### Seguridad
- Plan §5 obligatoria en todos los tamaños cuando hay entradas nuevas, con mitigación verificable por entrada;
  §6 incluye observabilidad sin secretos ni datos personales. `sdd-review` añade una lista de comprobaciones.
- Dependencias: nombre exacto comprobado en el registro oficial, lockfile en el mismo commit e instalaciones
  congeladas en los comandos de verificación.
- **Política de secretos** (decisión explícita tras seis rondas de medición): `pre-commit` **bloquea** solo lo de
  alta confianza (formatos de proveedor como GitHub, AWS, Stripe, Slack, Discord, SendGrid, npm, Vault, Hugging Face,
  Telegram; claves privadas PEM/PGP, también en base64; credenciales con estructura: URLs con contraseña,
  `Authorization: Basic`, `curl -u`, `mysql -p`, `auth=(…)`, `NetworkCredential`, JWT; `.env` reales con valor) y
  **avisa** de las heurísticas por nombre (`password=`, `*_KEY=`, `fooKey=`, anotaciones de tipo, `define()`, SQL),
  que por regex no alcanzan la precisión necesaria para bloquear sin crear callejones sin salida. En tests, fixtures,
  documentación y `.env` de desarrollo todo es aviso salvo los formatos de proveedor. El escáner dedicado en CI
  (p. ej. gitleaks) pasa a ser obligatorio en proyectos entregados a clientes.
- **Precisión medida** con seis corpus realistas construidos por auditores independientes (código, IaC, configuración;
  18 ecosistemas). El último (ronda 8) se midió **sin ajustar nada**: 0/69 líneas benignas de código bloquean,
  27/27 secretos de alta confianza bloquean y 40/44 secretos dan señal. En los seis corpus: **0/329 líneas benignas
  de código bloquean un commit** y **189/203 secretos dan señal** (FAIL o aviso); 0/40 librerías minificadas. Los que
  faltan son inherentes a un escáner por regex (credenciales posicionales sin nombre como `Client('AC…', '…')` o
  `smtp.login(…)`, DSN de Go, `props.put(…)`, base64 de `docker/config.json`) o contrapartidas conocidas (valores con
  puntos, contraseñas de menos de 8 caracteres), y son lo que cubre el escáner dedicado en CI.
  Los avisos excedentes (más de 10 por commit) se resumen con su `fichero:línea`. La salida nunca muestra el secreto
  (`fichero:línea` y 4 caracteres; tampoco líneas de ficheros sensibles ni literales largos en otros avisos). Tiempo
  lineal: una línea minificada de 280 KB tarda 0,4-0,6 s y un diff de 50 MB, 3-5 s con Node (17-43 s con Python).
- El diff que se escanea no puede ocultarse con `diff.external`, `textconv`, `.gitattributes -diff`, prefijos de diff
  (`dstPrefix`, `mnemonicPrefix`), renombrados (un fichero movido de `tests/` a `src/` se escanea en su ruta nueva),
  retornos de carro sueltos (`\r`, que en ambas implementaciones partían la línea y ocultaban lo que seguía) ni
  bytes NUL, y admite rutas con espacios o comillas; ningún tope deja pasar un secreto (los mensajes sí se resumen).
- Las URLs con credenciales distinguen los valores de desarrollo conocidos (contraseña igual al usuario o de relleno:
  `postgres:postgres`, `guest:guest`, `user:password`) y los hosts locales (aviso), y los `.env` de ejemplo (`.env.example`, `.env.sample`…) son laxos —no cualquier
  `.template` o `.dist`—;
  así el consejo «pon los valores de ejemplo en `.env.example`» no acaba en un FAIL.
- `sdd-allow-secret` ya no oculta un hallazgo que bloquea: AVISO de revisión humana, y en CI solo pasa si el sha256 de
  **fichero y línea** está en `.sdd-allowed-secrets` **de la rama base** (un agente no puede autoaprobarse en su propio
  PR, y aprobar la cabecera PEM de un fixture no aprueba la misma línea en otro fichero; cambiar la lista avisa). En
  local se aplica la versión commiteada. Un secreto ya borrado del historial también se aprueba así, sin reescribir
  la historia. El hash nunca se imprime (en un log de CI, con un secreto de baja entropía sería reversible por
  diccionario): se calcula en local con `sdd-check allow-hash <fichero>:<línea>`.
- `sdd-check pre-commit --range <base>...HEAD` para CI (propuesto por defecto con el hook de pre-commit): mismos
  detectores sobre la rama, y los secretos sobre **todo el historial** del rango, merges incluidos. Para proyectos
  entregados a clientes, `sdd-agents` exige además en CI un escáner dedicado (p. ej. gitleaks) y CODEOWNERS para la lista
  de permitidos: `sdd-check` es una primera barrera rápida, no un sustituto.
- Ficheros de entorno o credenciales staged (`.env*`, `.npmrc`, `*.tfvars`, `*.pem`, `id_rsa`…) → AVISO (FAIL si
  contienen un secreto). Cambios en `AGENTS.md`, el runbook, la constitución o las convenciones (lo que leen todos
  los agentes) y en la tabla de comandos → AVISO de revisión humana.
- `remote-run.sh`: exige ruta remota absoluta, de 2+ niveles y sin segmentos `.`/`..` ni `//`, y una marca
  `.sdd-run-target` que crea `run init --confirm` después de mostrar cuántas entradas borraría la primera sincronización
  y de comprobar que el destino no es el `$HOME` remoto (sin marca nunca sincroniza con borrado); impide ejecuciones simultáneas desde
  la misma copia (flock) y no sincroniza `.env*`, `.npmrc`, `*.tfvars`, `*.tfstate`, claves, certificados ni kubeconfig.
- Validate y release exigen árbol limpio; un CI verde solo se reutiliza si ejecutó toda la fila Todo; los
  comandos y ejemplos de documentación cambiados se ejecutan. La fila Seguridad detecta manifiestos en monorepos.

### Ambigüedades resueltas
- Tamaños `S`/`M`/`L` con criterios objetivos en Convenciones › Tamaño de spec (antes `L` activaba la revisión
  de ciclo sin estar definido). Clarify pregunta el nivel de accesibilidad en interfaces gráficas. El modo
  Delta de `sdd-plan`, como lista de casos.
- Aceptar un riesgo ante un NO o un BLOCKED repite la skill que emitió el veredicto (no siempre validate).

### Coste
- `AGENTS.md`, que el harness carga en **todos** los agentes y subagentes, pasa de 19,7 KB a 9,0 KB (unos
  3.000 tokens menos por agente): las Convenciones SDD van a `docs/sdd-conventions.md`, que las skills citan
  como «Convenciones › Sección» y leen por secciones; la Delegación, a `sdd-orchestrator`, el único que la usa.

### Migración desde 2.0.0
- El orquestador detecta un proyecto 2.0.0 aunque su verificador sea el antiguo (marcador menor que 3, falta
  `docs/sdd-conventions.md` o verificador más antiguo que el del paquete; nunca rebaja uno más nuevo, así dos
  personas con paquetes distintos no se pisan) y propone `sdd-agents`, que instala
  `docs/sdd-conventions.md`, recorta `AGENTS.md` (conserva comandos, excepciones y ramas), añade las reglas
  14-16 y actualiza el verificador.
- Filas abiertas del backlog que el verificador marque como no válidas: `sdd-review` en modo formato.

## 2.0.0

Cada cambio responde a un problema observado en el uso real de la versión anterior.

### Calidad de la evidencia
- **Niveles de test** (UNIT, INTEG, CONTRATO, E2E, VISUAL, REAL, CARACTERIZACIÓN) con mínimos por tipo de
  requisito: el plan los fija (§9), tasks los traza y validate rechaza los insuficientes.
- Prohibidos los valores inventados ante respuestas externas incompletas y los dobles que «lo aceptan
  todo».
- **Contratos externos con fuente oficial** (plan §4a), sistemas externos con entorno de verificación en
  la spec y tareas de contrato y de verificación real **al principio**, no al final.
- **Tabla de estados y transiciones** obligatoria (cancelar, reintentar, fallo parcial, reinicio,
  concurrencia), auditada en clarify y con un test por transición.
- **Módulos canónicos** (plan §4b) y **puntos de contacto** por tarea contra la lógica duplicada y la
  propagación incompleta de conceptos nuevos.
- **Verificación visual** contra referencias guardadas en la carpeta de la spec.
- **Clase de causa raíz y casos hermanos** en cada bug.

### Flujo sin bucles ni bloqueos
- Todo veredicto negativo declara su `Siguiente paso`. Una skill se repite solo si hay trabajo
  commiteado posterior a su última ejecución; nunca se enruta a una skill ya satisfecha.
- La autocomprobación de migración en sdd-plan evita el vaivén plan ↔ migración; una sola aprobación por
  paso.
- **Trabajo parcial aparcado** con nombre y reaperturas commiteadas: la skill siguiente encuentra
  siempre el árbol limpio.
- Las tareas que **requieren al usuario** no bloquean la cadena: se saltan mientras haya otras y se
  piden todas juntas.
- **Backlog** (`reviews/backlog.md`) con formato fijo para hallazgos, casos hermanos y deuda observada;
  no interrumpe la implementación y CRÍTICO/ALTO bloquean la validación.
- Riesgos y vulnerabilidades sin parche con un procedimiento único de aceptación.

### Coste y trazabilidad
- **Verificador `sdd-check`** (Node o Python, salida idéntica): estado, caducidad, siguiente paso,
  problemas de formato, backlog y control de cada commit, sin leer artefactos completos.
- **Una spec por funcionalidad**, con criterios objetivos de spec nueva frente a cambio y aviso a partir
  de 40 tareas abiertas; archivado del ciclo en `tasks-archive.md` al hacer release.
- Formato de evidencia compacto (máximo 6 líneas) y editable por ID.
- Delegación en subagentes secuenciales con prompt mínimo cuando el harness lo permite; el estado vive
  en el repositorio.
- Conocimiento operativo versionado en `docs/agent-runbook.md`, con un contrato común para ejecutar en
  entornos remotos.

### Portabilidad
- Independiente del proyecto, del lenguaje y del harness: sin supuestos de stack, herramientas o
  ficheros de instrucciones concretos; capacidades del harness siempre opcionales.
- Instalador para cualquier directorio de skills, con copia de seguridad y vuelta atrás.
- Batería de 127 tests del verificador (paridad Node ↔ Python, CRLF, ficheros no UTF-8, rutas no ASCII y
  con espacios, ejecución desde subdirectorios).

### Migración desde la versión anterior
- Los artefactos existentes siguen siendo válidos. Los derivados sin `Spec-Version` dejan de considerarse
  vigentes; la skill dueña re-sella su cabecera sin repetir auditorías ni aprobaciones si aquello de lo que
  dependen no ha cambiado desde su último commit.
- Las tareas cerradas sin evidencia se re-sellan re-ejecutando sus tests. El verificador
  acepta también el marcador pendiente anterior `Evidencia: (la añade sdd-implement)`.
- Las nuevas exigencias se aplican desde el siguiente cambio o plan de cada spec.
- En cada proyecto, el primer `sdd-orchestrator` propondrá `sdd-agents` para generar `AGENTS.md`, el
  runbook y el verificador.

### Riesgos conocidos
- Más tiempo de verificación por tarea (suite del paquete y E2E cuando aplica); se ajusta en la columna
  «Cuándo» de cada proyecto (la frecuencia de la fila Todo, cada 5 tareas por orden del fichero, es fija en el verificador).
- Las skills son más largas; se compensa al no leer artefactos completos ni repetir fases.
